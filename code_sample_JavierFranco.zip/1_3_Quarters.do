/*==============================================================================
  1_3_Quarters.do
  Collapses the monthly CRC files to debtor-institution-quarter panels, in
  three blocks of years.
  Input : $crc/central_<year>.dta
  Output: $crc_q/2010a2015.dta, 2015a2020.dta, 2020a2024.dta
==============================================================================*/

foreach block in "2010 2015" "2015 2020" "2020 2024" {
	local y0 : word 1 of `block'
	local y1 : word 2 of `block'
	local out "$crc_q/`y0'a`y1'.dta"

	clear
	save "`out'", emptyok replace
	forvalues y = `y0'/`y1' {
		use "$crc/central_`y'.dta", clear
		keep if year==`y'                       // drops December of y-1

		gen month = periodo - year*100
		gen trim  = ceil(month/3)

		* Months with a record within the quarter
		egen meses = tag(deudor institucion year trim month)

		collapse (sum) tot* deuda* meses (max) ranking duracion_total duracion_consec ///
			(mean) linea* ipc tc, by(deudor institucion trim year)

		append using "`out'"
		save "`out'", replace
	}
}
