/*==============================================================================
  4_1_Matching.do
  Matches each treated worker to a control worker with a placebo shock date,
  separately for each shock month g and definition, and builds the
  estimation panels.
    1. Firm panel and exclusions
    2. Two-stage matching by shock month (firms, then workers)
    3. Matched samples and balance
    4. Estimation panels: pair x six-month window, and pair x month
  Matching, by shock month g:
    Stage 1. Each treated firm is compared with firms without a shock of the
             same type in [g-24, g+53] and without a real closure in
             [g, g+53]. Exact match on ISIC division (section if there are
             no candidates) and size; candidates ranked by a firm logit on
             log employment and firm age, measured at g-kref.
    Stage 2. Each treated worker takes the closest worker (worker logit,
             within a caliper) in the best-ranked control firm, with exact
             match on the ex_<spec> variables; without replacement within g
             unless rep_<spec>==1. Controls must be employed in the same
             firm at g-1 and g, have no exit at g and no own shock before
             g+53.
  Input : outputs of 3_2_Merge.do
  Output: $mov/matched_<def><spec>.dta, $mov/es_panel_<def>.dta,
          $mov/es_mpanel_<def>.dta, $mov/results/ (pre-matching
          descriptives, common support, balance, re-employment)
  With limpiar==1 this script erases the chars_m and y6 files of 3_2, so a
  rerun needs 3_2 first.
==============================================================================*/

clear
foreach d in "$mov/cand" "$mov/match" "$mov/results" {
	cap mkdir "`d'"
}

*------------------------------------------------------------------------------
* 1. Firm panel and exclusions
*------------------------------------------------------------------------------
use j mfecha CIIU4 avg_n_month firm_size full_closure fenix var_n_leq_33 layoffs_geq_33 ///
	using "$layoffs/cotizantes2010_2022_hhll.dta", clear
bysort j: egen int first_m = min(mfecha)
gen int CIIU2f = floor(CIIU4/100)
ciiu_section CIIU2f fsector
drop CIIU4
compress
save "$mov/cand/firm_tmp.dta", replace

* Months with a shock of each type, by firm
foreach d of global defs {
	use j mfecha ${flag_`d'} if ${flag_`d'}==1 using "$mov/cand/firm_tmp.dta", clear
	keep j mfecha
	save "$mov/cand/firm_flags_`d'.dta", replace emptyok
}

* Real (non-phoenix) closures
use j mfecha full_closure fenix if full_closure==1 & fenix==0 using "$mov/cand/firm_tmp.dta", clear
keep j mfecha
save "$mov/cand/firm_close.dta", replace emptyok

* Files filled in the loop: pre-matching descriptives and common support
set seed 20261020
foreach d of global defs {
	clear
	save "$mov/results/desc_pre_`d'.dta", replace emptyok
	save "$mov/results/ids_pre_`d'.dta", replace emptyok
	foreach s of global mspecs {
		local sfx = cond("`s'"=="base", "", "_`s'")
		save "$mov/results/cs_`d'`sfx'.dta", replace emptyok
	}
}

*------------------------------------------------------------------------------
* 2. Two-stage matching by shock month
*------------------------------------------------------------------------------
forvalues g = $gmin/$gmax {
	local gl   : display %tm `g'
	local gl1  : display %tm (`g' - 1)
	local gm24 : display %tm (`g' - 24)
	local gm18 : display %tm (`g' - 18)
	local gk   : display %tm (`g' - $kref)

	*--- Worker pool, common to all definitions -------------------------------

	* Firm at g
	use i j using "$mov/chars_m/chars_`gl'.dta", clear
	rename j j_g
	save "$mov/cand/tmp_g.dta", replace

	* Exits at g, any cause
	use i mfecha if mfecha==`g' using "$es/tmp/all_exits.dta", clear
	keep i
	duplicates drop
	gen byte exit_g = 1
	save "$mov/cand/tmp_exit.dta", replace emptyok

	* Covariates in k=-2: income percentile averaged over g-kref-5..g-kref
	* (months with a job), sector and firm size at g-kref
	clear
	forvalues s = $kref/$kref5 {
		local ts : display %tm (`g' - `s')
		append using "$mov/chars_m/chars_`ts'.dta", keep(pers_identificador pct_ing)
	}
	collapse (mean) pct_ing, by(pers_identificador)
	save "$mov/cand/tmp_inc.dta", replace
	use pers_identificador sector firm_size using "$mov/chars_m/chars_`gk'.dta", clear
	bysort pers_identificador (firm_size): keep if _n==1
	rename (sector firm_size) (sector_k2 fsz_k2)
	save "$mov/cand/tmp_k2.dta", replace

	* Base: employed at g-1 in a firm of the panel (5+ workers), single job
	use "$mov/chars_m/chars_`gl1'.dta", clear
	keep if !missing(firm_size)
	bysort pers_identificador (i): keep if _n==1
	merge 1:1 i using "$mov/cand/tmp_g.dta", keep(1 3) nogen
	gen byte stay = (j_g==j)
	drop j_g
	merge 1:1 i using "$mov/cand/tmp_exit.dta", keep(1 3) nogen
	recode exit_g (.=0)
	merge m:1 i using "$es/multijob_allyears.dta", keepusing(multi_job) keep(1 3) nogen
	drop if multi_job==1
	drop multi_job
	if $solo_crc merge m:1 pers_identificador using "$mov/personas_crc.dta", keep(3) nogen

	* Pre-shock credit in windows k=-4 (g-24..g-19) and k=-3 (g-18..g-13).
	* No record in the window: log debt 0 and crc_<w> = 0.
	foreach w in m4 m3 {
		if "`w'"=="m4" local tw "`gm24'"
		if "`w'"=="m3" local tw "`gm18'"
		merge 1:1 pers_identificador using "$mov/y6/y6_`tw'.dta", ///
			keepusing(totdeuda_B totdeuda_E totvencida_B totvencida_E ///
			ranking_max_B ranking_max_E) keep(1 3)
		gen byte crc_`w' = (_merge==3)
		drop _merge
		* Worst rating 3, 4 or 5 in the window, by institution type
		gen byte m345B_`w' = (ranking_max_B >= $cal_min3 & !missing(ranking_max_B))
		gen byte m345E_`w' = (ranking_max_E >= $cal_min3 & !missing(ranking_max_E))
		gen double ldB_`w' = ln(1 + max(totdeuda_B, 0))
		gen double ldE_`w' = ln(1 + max(totdeuda_E, 0))
		gen double lvB_`w' = ln(1 + max(totvencida_B, 0))
		gen double lvE_`w' = ln(1 + max(totvencida_E, 0))
		gen byte venc_`w'  = (totvencida_B>0 & !missing(totvencida_B)) | ///
		                     (totvencida_E>0 & !missing(totvencida_E))
		drop totdeuda_B totdeuda_E totvencida_B totvencida_E ranking_max_B ranking_max_E
	}

	* Income and firm in k=-2. No income in the window: pct_ing = 0,
	* noinc_k2 = 1, decile 0. Sector and size missing at g-kref (no job, or
	* a firm with 4 or fewer workers): taken from g-1 (k2_fill = 1).
	merge 1:1 pers_identificador using "$mov/cand/tmp_inc.dta", keep(1 3) nogen
	merge 1:1 pers_identificador using "$mov/cand/tmp_k2.dta",  keep(1 3) nogen
	gen byte noinc_k2 = missing(pct_ing)
	replace pct_ing   = 0 if noinc_k2
	gen byte dec_ing  = cond(noinc_k2, 0, ceil(pct_ing/10))
	gen byte vent_ing = cond(noinc_k2, 0, ceil(pct_ing/5))     // ventile, enters the score
	gen byte k2_fill  = missing(sector_k2) | missing(fsz_k2)
	replace sector_k2 = sector    if missing(sector_k2)
	replace fsz_k2    = firm_size if missing(fsz_k2)

	* Tenure brackets at g-1 (exact match): <1, 1-3, 3-5, 5+ years
	gen byte ten_bin = 1 + (tenure>=12) + (tenure>=36) + (tenure>=60) if !missing(tenure)

	gen int g = `g'
	format g %tm
	compress
	save "$mov/cand/cand_cur.dta", replace

	* Firms at g-kref: size, age and sector before the treated firm shrinks
	use j CIIU2f fsector avg_n_month firm_size first_m mfecha if mfecha==`g' - $kref ///
		using "$mov/cand/firm_tmp.dta", clear
	keep if !missing(firm_size) & avg_n_month > 0 & !missing(avg_n_month)
	gen double f_lnsize = ln(avg_n_month)
	gen double f_age    = (`g' - $kref) - first_m
	rename firm_size f_size
	keep j CIIU2f fsector f_size f_lnsize f_age
	bysort j: keep if _n==1
	save "$mov/cand/firm_cur.dta", replace

	*--- Matching, by definition ----------------------------------------------
	foreach d of global defs {

		* Treated at g and eligible controls
		use "$mov/cand/cand_cur.dta", clear
		merge m:1 pers_identificador using "$mov/first_event_m_`d'.dta", ///
			keepusing(mfecha_event multi_shock j_event) keep(1 3) nogen
		gen byte treated = (mfecha_event==`g') & multi_shock==0
		gen byte elig_c  = (stay==1) & (exit_g==0) & ///
			(missing(mfecha_event) | mfecha_event > `g' + 53)
		keep if treated | elig_c
		qui count if treated
		if r(N)==0 continue
		replace j_event = . if treated==0
		save "$mov/cand/w_cur.dta", replace

		* Pre-matching descriptives, all ages (1 = treated, 2 = control pool)
		merge m:1 j using "$mov/cand/firm_cur.dta", keepusing(f_size f_lnsize f_age) keep(1 3) nogen
		desc_prep
		gen byte grp = cond(treated==1, 1, 2)
		gen byte edad_ok = inrange(edad, $edad_lo, $edad_hi)
		capture frame drop fids
		frame put pers_identificador grp, into(fids)
		frame fids {
			append using "$mov/results/ids_pre_`d'.dta"
			duplicates drop
			save "$mov/results/ids_pre_`d'.dta", replace
		}
		frame drop fids
		desc_sums "(sum) n_age=edad_ok"
		gen int g = `g'
		append using "$mov/results/desc_pre_`d'.dta"
		save "$mov/results/desc_pre_`d'.dta", replace

		* Age filter: within edad_min..edad_max over the whole window
		use "$mov/cand/w_cur.dta", clear
		keep if inrange(edad, $edad_lo, $edad_hi)
		qui count if treated
		if r(N)==0 continue
		save "$mov/cand/w_cur.dta", replace

		*--- Stage 1: firms

		* Treated firms
		use j_event treated if treated==1 using "$mov/cand/w_cur.dta", clear
		keep j_event
		duplicates drop
		rename j_event j
		gen byte trf = 1
		save "$mov/cand/tf.dta", replace

		* Excluded: same-type shock in [g-24, g+53] or real closure in [g, g+53]
		use j mfecha if inrange(mfecha, `g' - 24, `g' + 53) using "$mov/cand/firm_flags_`d'.dta", clear
		keep j
		save "$mov/cand/excl.dta", replace emptyok
		use j mfecha if inrange(mfecha, `g', `g' + 53) using "$mov/cand/firm_close.dta", clear
		keep j
		append using "$mov/cand/excl.dta"
		duplicates drop
		gen byte excl = 1
		save "$mov/cand/excl.dta", replace emptyok

		* Firms with at least one eligible control worker
		use j elig_c treated if elig_c==1 & treated==0 using "$mov/cand/w_cur.dta", clear
		keep j
		duplicates drop
		gen byte haswc = 1
		save "$mov/cand/fw.dta", replace emptyok

		use "$mov/cand/firm_cur.dta", clear
		merge 1:1 j using "$mov/cand/tf.dta",   keep(1 3) nogen
		merge 1:1 j using "$mov/cand/excl.dta", keep(1 3) nogen
		merge 1:1 j using "$mov/cand/fw.dta",   keep(1 3) nogen
		recode trf excl haswc (.=0)
		keep if trf==1 | (excl==0 & haswc==1)
		* Common support: section x size cells with a treated firm
		bysort fsector f_size: egen byte anyT = max(trf)
		keep if anyT==1
		qui count if trf
		if r(N)==0 continue

		capture logit trf f_lnsize f_age i.f_size i.fsector, iterate(50)
		if _rc {
			di as error "`d' `gl': firm logit failed (rc=`=_rc'), month skipped"
			continue
		}
		predict double fxb if e(sample), xb
		keep if !missing(fxb)
		save "$mov/cand/f_cur.dta", replace

		use j CIIU2f fsector f_size fxb trf if trf==0 using "$mov/cand/f_cur.dta", clear
		drop trf
		rename (j fxb) (jc fxbc)
		save "$mov/cand/fc.dta", replace emptyok
		use j CIIU2f fsector f_size fxb trf if trf==1 using "$mov/cand/f_cur.dta", clear
		drop trf
		rename (j fxb) (jt fxbt)
		save "$mov/cand/ft.dta", replace

		* Level 1: same ISIC division and size
		joinby CIIU2f f_size using "$mov/cand/fc.dta"
		gen byte f_level = 1
		save "$mov/cand/fp.dta", replace emptyok
		* Level 2, for treated firms without candidates: same section and size
		use "$mov/cand/ft.dta", clear
		merge 1:m jt using "$mov/cand/fp.dta", keepusing(jt) keep(1) nogen
		if _N > 0 {
			joinby fsector f_size using "$mov/cand/fc.dta"
			gen byte f_level = 2
			append using "$mov/cand/fp.dta"
		}
		else use "$mov/cand/fp.dta", clear
		if _N==0 continue

		* Up to nfmax control firms per treated firm, ranked by level and
		* distance in the firm logit index (f_rank 1 = closest)
		gen double fdist = abs(fxbt - fxbc)
		bysort jt (f_level fdist jc): keep if _n <= $nfmax
		by jt: gen byte f_rank = _n
		keep jt jc f_rank f_level
		save "$mov/cand/fp.dta", replace

		*--- Stage 2: workers, once per matching specification
		foreach s of global mspecs {
			local sfx = cond("`s'"=="base", "", "_`s'")

			use if f_rank <= ${nf_`s'} using "$mov/cand/fp.dta", clear
			save "$mov/cand/fps.dta", replace

			use jc using "$mov/cand/fps.dta", clear
			duplicates drop
			rename jc j
			gen byte incf = 1
			save "$mov/cand/fcl.dta", replace
			use jt using "$mov/cand/fps.dta", clear
			duplicates drop
			rename jt j_event
			gen byte hasfc = 1
			save "$mov/cand/ftl.dta", replace

			use "$mov/cand/w_cur.dta", clear
			merge m:1 j using "$mov/cand/fcl.dta", keep(1 3) nogen
			merge m:1 j_event using "$mov/cand/ftl.dta", keep(1 3) nogen
			keep if (treated==1 & hasfc==1) | (treated==0 & incf==1)
			qui count if treated
			if r(N)==0 continue

			* Worker score, pooled within g. Sector and size are already fixed
			* by stage 1.
			capture logit treated c.edad##c.edad i.sexo i.ten_bin i.vent_ing noinc_k2 ///
				ldB_m4 ldE_m4 ldB_m3 ldE_m3 lvB_m4 lvE_m4 lvB_m3 lvE_m3 ///
				venc_m4 venc_m3 crc_m4 crc_m3 m345B_m4 m345E_m4 m345B_m3 m345E_m3, ///
				iterate(50)
			if _rc {
				di as error "`d' `s' `gl': worker logit failed (rc=`=_rc'), month skipped"
				continue
			}
			predict double xb if e(sample), xb
			keep if !missing(xb)
			qui sum xb
			local cal = ${cal_`s'} * r(sd)
			save "$mov/cand/w2.dta", replace

			* Common support: score index centered on the mean of the
			* candidate controls of g, for all treated and a cs_frac sample of
			* controls. offsup: treated outside the controls' range.
			qui sum xb if treated==0
			local mxc  = r(mean)
			local minc = r(min)
			local maxc = r(max)
			gen double xb_c = xb - `mxc'
			gen byte offsup = (xb < `minc' | xb > `maxc') if treated==1
			keep if treated==1 | runiform() < $cs_frac
			gen double w_cs = cond(treated==1, 1, 1/$cs_frac)
			keep treated xb_c offsup w_cs
			gen int g = `g'
			append using "$mov/results/cs_`d'`sfx'.dta"
			save "$mov/results/cs_`d'`sfx'.dta", replace

			use pers_identificador j xb sexo ten_bin treated if treated==0 using "$mov/cand/w2.dta", clear
			drop treated
			rename (pers_identificador j xb sexo ten_bin) (c jc xbc sexo_c ten_c)
			save "$mov/cand/wc.dta", replace
			use pers_identificador j_event xb sexo ten_bin treated if treated==1 using "$mov/cand/w2.dta", clear
			drop treated
			rename (pers_identificador j_event xb sexo ten_bin) (t jt xbt sexo_t ten_t)

			* Treated x control firms x their workers, exact match on ex_<s>
			joinby jt using "$mov/cand/fps.dta"
			joinby jc using "$mov/cand/wc.dta"
			local exc "1"
			if strpos(" ${ex_`s'} ", " sexo ")    local exc "`exc' & sexo_t==sexo_c"
			if strpos(" ${ex_`s'} ", " ten_bin ") local exc "`exc' & ten_t==ten_c & !missing(ten_t)"
			keep if `exc'
			drop sexo_t sexo_c ten_t ten_c
			if _N==0 continue
			gen double dist = abs(xbt - xbc)
			drop if dist > `cal'
			if _N==0 continue

			if ${rep_`s'} {
				* With replacement: each treated takes its best option
				bysort t (f_rank dist c): keep if _n==1
			}
			else {
				* Greedy assignment without replacement within g. Each treated
				* prefers its best-ranked control firm and, within it, the
				* closest worker. If two treated want the same control, the one
				* with the better (rank, distance) wins and the other moves on.
				gen byte final  = 0
				gen byte active = 1
				while 1 {
					qui count if active
					if r(N)==0 continue, break
					capture drop bt key wc_ tw cw
					bysort active t (f_rank dist c): gen byte bt = (_n==1) & active
					gen double key = cond(bt, f_rank*1e6 + dist, .)
					bysort active c (key t): gen byte wc_ = (_n==1) & bt
					replace final = 1 if wc_
					bysort t: egen byte tw = max(wc_)
					bysort c: egen byte cw = max(wc_)
					replace active = 0 if tw | cw
				}
				keep if final
			}
			keep t c jt jc f_rank f_level dist xbt xbc

			* Two rows per pair (treated and control)
			sort t
			gen double pair_id = `g'*100000 + _n
			expand 2
			bysort pair_id: gen byte treated = (_n==1)
			gen double pers_identificador = cond(treated==1, t, c)
			gen double j = cond(treated==1, jt, jc)
			rename (jt dist) (j_cluster w_dist)
			gen double xb_c = cond(treated==1, xbt, xbc) - `mxc'
			keep pair_id treated pers_identificador j j_cluster f_rank f_level w_dist xb_c
			merge m:1 pers_identificador using "$mov/cand/cand_cur.dta", ///
				keepusing(i g edad sexo sector firm_size pct_ing noinc_k2 dec_ing ///
				vent_ing sector_k2 fsz_k2 k2_fill tenure ten_bin ///
				ldB_m4 ldE_m4 ldB_m3 ldE_m3 lvB_m4 lvE_m4 lvB_m3 lvE_m3 ///
				venc_m4 venc_m3 crc_m4 crc_m3 m345B_m4 m345E_m4 m345B_m3 m345E_m3) ///
				keep(3) nogen
			merge m:1 j using "$mov/cand/firm_cur.dta", ///
				keepusing(f_lnsize f_age f_size) keep(1 3) nogen
			rename j j_firm
			gen byte mes_layoff = month(dofm(`g'))
			save "$mov/match/m_`d'`sfx'_`gl'.dta", replace
		}
	}

	* chars of g-kref-5 is not needed from g+1 on
	if $limpiar {
		local gold : display %tm (`g' - $kref5)
		capture erase "$mov/chars_m/chars_`gold'.dta"
	}
}
if $limpiar {
	forvalues t = `=$gmax - $kref5 + 1'/$gmax {
		local tl : display %tm `t'
		capture erase "$mov/chars_m/chars_`tl'.dta"
	}
}
foreach f in tmp_g tmp_exit tmp_inc tmp_k2 cand_cur firm_cur w_cur tf excl fw ///
	f_cur fc ft fp fps fcl ftl w2 wc firm_tmp firm_close {
	capture erase "$mov/cand/`f'.dta"
}
foreach d of global defs {
	capture erase "$mov/cand/firm_flags_`d'.dta"
}

*------------------------------------------------------------------------------
* 3. Matched samples and balance
*------------------------------------------------------------------------------
foreach d of global defs {
foreach s of global mspecs {
	local sfx = cond("`s'"=="base", "", "_`s'")
	clear
	forvalues g = $gmin/$gmax {
		local gl : display %tm `g'
		capture confirm file "$mov/match/m_`d'`sfx'_`gl'.dta"
		if !_rc {
			append using "$mov/match/m_`d'`sfx'_`gl'.dta"
			erase "$mov/match/m_`d'`sfx'_`gl'.dta"
		}
	}
	if _N==0 {
		di as error "`d' / `s': no matched pairs"
		continue
	}
	label var pair_id    "Treated-control pair (g*100000 + n)"
	label var treated    "1 = shock at g, 0 = control with placebo date g"
	label var g          "Shock month (placebo for controls)"
	label var mes_layoff "Calendar month of the shock (1-12)"
	label var sector     "ISIC rev. 4 section at g-1"
	label var firm_size  "Firm size at g-1"
	label var j_firm     "Worker's firm at g-1 (treated or control)"
	label var j_cluster  "Event firm of the pair (cluster)"
	label var f_rank     "Rank of the control firm used (1 = closest)"
	label var f_level    "Firm match level (1 = ISIC division, 2 = section)"
	label var w_dist     "Distance in the worker logit index"
	label var f_lnsize   "Log 12-month average employment of the firm, g-kref"
	label var f_age      "Months since the firm enters the panel (censored at 2010m1)"
	label var pct_ing    "Income percentile, average in k=-2 (0 = no income)"
	label var noinc_k2   "No labor income in k=-2"
	label var dec_ing    "Income decile in k=-2 (0 = no income)"
	label var sector_k2  "ISIC rev. 4 section at g-kref"
	label var fsz_k2     "Firm size at g-kref"
	label var k2_fill    "k=-2 sector/size imputed with g-1"
	label var tenure     "Tenure in the firm at g-1 (months, censored at 2010m1)"
	label var ten_bin    "Tenure bracket (1 <1 year, 2 1-3, 3 3-5, 4 5+)"
	label var xb_c       "Score index centered on the mean of the candidate controls of g"
	label var m345B_m4   "Worst rating 3-5 with banks in k=-4"
	label var m345E_m4   "Worst rating 3-5 with CMFs in k=-4"
	label var m345B_m3   "Worst rating 3-5 with banks in k=-3"
	label var m345E_m3   "Worst rating 3-5 with CMFs in k=-3"
	compress
	save "$mov/matched_`d'`sfx'.dta", replace

	qui count if treated
	local nm = r(N)
	preserve
	use "$mov/first_event_m_`d'.dta", clear
	qui count if inrange(mfecha_event, $gmin, $gmax) & multi_shock==0 & multi_job==0
	local ne = r(N)
	restore
	di as text "=== `d' / `s' (exact: ${ex_`s'}; firms: ${nf_`s'}; caliper: ${cal_`s'}; replacement: ${rep_`s'}) ==="
	di as text "    `ne' treated without multiple shocks or jobs; `nm' matched"
	tab f_rank f_level if treated==1

	* Standardized differences after matching (|d| < 0.1 is the usual target)
	qui tab f_size, gen(fsize_)
	tempname bal
	postfile `bal' str20 variable double(mean_treated mean_control std_diff) ///
		using "$mov/results/balance_`d'`sfx'.dta", replace
	foreach v of varlist edad sexo tenure pct_ing noinc_k2 k2_fill ///
		ldB_m4 ldE_m4 ldB_m3 ldE_m3 lvB_m4 lvE_m4 lvB_m3 lvE_m3 ///
		venc_m4 venc_m3 crc_m4 crc_m3 m345B_m4 m345E_m4 m345B_m3 m345E_m3 ///
		f_lnsize f_age fsize_* {
		qui sum `v' if treated==1
		local mt = r(mean)
		local vt = r(Var)
		qui sum `v' if treated==0
		local mc = r(mean)
		local vc = r(Var)
		post `bal' ("`v'") (`mt') (`mc') ((`mt' - `mc') / sqrt((`vt' + `vc')/2))
	}
	postclose `bal'
	preserve
	use "$mov/results/balance_`d'`sfx'.dta", clear
	list, noobs clean
	restore
}
}

*------------------------------------------------------------------------------
* 4. Estimation panels
*------------------------------------------------------------------------------
* (a) Person x window start needed by any definition
clear
foreach d of global defs {
	append using "$mov/matched_`d'${sfx_es}.dta", keep(pers_identificador g)
}
duplicates drop
expand 13
bysort pers_identificador g: gen byte rel_sem = _n - 5
gen int t = g + 6*rel_sem
keep if inrange(t, $tmin, $tmax)
keep pers_identificador t
duplicates drop
save "$mov/match/need.dta", replace

* (b) Credit outcomes of those windows
forvalues t = $tmin/$tmax {
	local tl : display %tm `t'
	use pers_identificador t if t==`t' using "$mov/match/need.dta", clear
	if _N==0 continue
	merge 1:1 pers_identificador using "$mov/y6/y6_`tl'.dta", keep(3) nogen
	save "$mov/match/out_`tl'.dta", replace
}
clear
forvalues t = $tmin/$tmax {
	local tl : display %tm `t'
	capture confirm file "$mov/match/out_`tl'.dta"
	if !_rc {
		append using "$mov/match/out_`tl'.dta"
		erase "$mov/match/out_`tl'.dta"
	}
}
save "$mov/match/outcomes.dta", replace

* (c) Real labor income. Monthly CPI from the CRC files (base = 1);
* missing months interpolated.
clear
save "$mov/match/ipc.dta", replace emptyok
forvalues y = 2012/2022 {
	use periodo ipc using "$crc/central_`y'.dta", clear
	collapse (mean) ipc, by(periodo)
	append using "$mov/match/ipc.dta"
	save "$mov/match/ipc.dta", replace
}
gen int mfecha = ym(floor(periodo/100), mod(periodo, 100))
collapse (mean) ipc, by(mfecha)
tsset mfecha
tsfill
ipolate ipc mfecha, gen(ipc_i) epolate
qui count if missing(ipc)
di as text "CPI: `r(N)' months interpolated"
replace ipc = ipc_i
drop ipc_i
tsset, clear
save "$mov/match/ipc.dta", replace

use pers_identificador using "$mov/match/need.dta", clear
duplicates drop
save "$mov/match/pers_m.dta", replace

* Monthly income (summed over jobs) and person-month-firm jobs, matched
* sample only
clear
save "$mov/match/ing_mes.dta", replace emptyok
save "$mov/match/jobs.dta", replace emptyok
forvalues anio = 2012/2022 {
	use id_pers_mtss j anio mescargo remC1 using "$mtss/cotizantes`anio'_hhll.dta", clear
	keep if remC1 > 0 & !missing(remC1)
	rename id_pers_mtss pers_identificador
	merge m:1 pers_identificador using "$mov/match/pers_m.dta", keep(3) nogen
	gen int mfecha = ym(anio, mescargo)
	capture frame drop fjobs
	frame put pers_identificador mfecha j, into(fjobs)
	frame fjobs {
		duplicates drop
		append using "$mov/match/jobs.dta"
		save "$mov/match/jobs.dta", replace
	}
	frame drop fjobs
	collapse (sum) ing=remC1, by(pers_identificador mfecha)
	append using "$mov/match/ing_mes.dta"
	save "$mov/match/ing_mes.dta", replace
}
merge m:1 mfecha using "$mov/match/ipc.dta", keep(1 3) nogen
qui count if missing(ipc)
if r(N) > 0 di as error "Warning: `r(N)' person-months without CPI"
gen double ing_r = ing / ipc
keep pers_identificador mfecha ing_r
save "$mov/match/ing_mes.dta", replace

* Six-month windows: monthly mean (zero in months without a job) and
* number of months with a job
forvalues t = $tmin/$ipc_tmax {
	local tl : display %tm `t'
	use pers_identificador mfecha ing_r if inrange(mfecha, `t', `t' + 5) ///
		using "$mov/match/ing_mes.dta", clear
	if _N==0 continue
	gen byte emp = 1
	collapse (sum) ing_r emp, by(pers_identificador)
	replace ing_r = ing_r / 6
	gen int t = `t'
	save "$mov/match/ing6_`tl'.dta", replace
}
clear
forvalues t = $tmin/$ipc_tmax {
	local tl : display %tm `t'
	capture confirm file "$mov/match/ing6_`tl'.dta"
	if !_rc {
		append using "$mov/match/ing6_`tl'.dta"
		erase "$mov/match/ing6_`tl'.dta"
	}
}
save "$mov/match/ing6.dta", replace

* (d) Monthly credit of the matched sample, gmin-12 to gmax+12 (same
* definitions as the windows in 3_2)
forvalues t = `=$gmin - 12'/`=$gmax + 12' {
	local tl : display %tm `t'
	capture confirm file "$crcmes/mes_merge3_`tl'.dta"
	if _rc continue
	use "$crcmes/mes_merge3_`tl'.dta", clear
	merge m:1 pers_identificador using "$mov/match/pers_m.dta", keep(3) nogen
	if _N==0 continue
	foreach i in B E {
		egen double td2_`i' = rowtotal(totdeuda_`i' totcast_`i'), missing
		replace totdeuda2_`i' = td2_`i'
		drop td2_`i'
	}
	foreach v of varlist tot* {
		replace `v' = 0 if missing(`v')
	}
	collapse (sum) tot* (max) ranking_max_B ranking_max_E, by(pers_identificador mfecha)
	gen byte pos_B = totdeuda_B > 0
	gen byte pos_E = totdeuda_E > 0
	gen byte pos   = pos_B | pos_E
	save "$mov/match/crcm_`tl'.dta", replace
}
clear
forvalues t = `=$gmin - 12'/`=$gmax + 12' {
	local tl : display %tm `t'
	capture confirm file "$mov/match/crcm_`tl'.dta"
	if !_rc {
		append using "$mov/match/crcm_`tl'.dta"
		erase "$mov/match/crcm_`tl'.dta"
	}
}
save "$mov/match/crc_mes.dta", replace

* (e) Re-employment of the treated: first month after g with a formal job
* in a firm other than the layoff firm, censored at gmax. recall12: back
* at the layoff firm between g+2 and g+12 (g+1 may be a residual payment).
foreach d of global defs {
	use pers_identificador g j_cluster sexo edad tenure treated if treated==1 ///
		using "$mov/matched_`d'${sfx_es}.dta", clear
	drop treated
	rename j_cluster j_event
	merge 1:m pers_identificador using "$mov/match/jobs.dta", keep(1 3) nogen
	gen byte nueva  = (mfecha > g) & (j != j_event) & !missing(j, mfecha)
	gen byte vuelve = inrange(mfecha, g + 2, g + 12) & (j == j_event)
	bysort pers_identificador: egen int t_nueva = min(cond(nueva, mfecha, .))
	bysort pers_identificador: egen byte recall12 = max(vuelve)
	bysort pers_identificador: keep if _n==1
	gen byte reemp = !missing(t_nueva)
	gen int dur = cond(reemp, t_nueva - g, $gmax - g)
	format t_nueva %tm
	keep pers_identificador g sexo edad tenure t_nueva reemp dur recall12
	label var t_nueva  "First month with a formal job in another firm"
	label var dur      "Months to a job in another firm (or to censoring)"
	label var reemp    "1 = re-employed in another firm before censoring"
	label var recall12 "Back at the layoff firm between g+2 and g+12"
	compress
	save "$mov/results/reemp_`d'.dta", replace
}

* (f) Semi-annual panel: unit (pair x treated) x window k = -4..8
foreach d of global defs {
	use "$mov/matched_`d'${sfx_es}.dta", clear
	expand 13
	bysort pair_id treated: gen byte rel_sem = _n - 5
	gen int t = g + 6*rel_sem
	format t %tm
	merge m:1 pers_identificador t using "$mov/match/outcomes.dta", keep(1 3) nogen

	* Windows covered by the CRC without a record: no consumer debt with
	* banks or CMFs. Windows outside [tmin, tmax] stay missing.
	gen byte enr = inrange(t, $tmin, $tmax)
	foreach v of varlist pos pos_B pos_E {
		replace `v' = 0 if missing(`v') & enr
	}
	if $ceros {
		foreach v of varlist tot* {
			replace `v' = 0 if missing(`v') & enr
		}
	}
	egen double tdeuda = rowtotal(totdeuda_B totdeuda_E) if enr

	* Worst rating in the window by institution type, 0/100. Zero also for
	* people without debt with that type of institution.
	foreach i in B E {
		gen byte mal345_`i' = 100 * (ranking_max_`i' >= $cal_min3 & !missing(ranking_max_`i')) if enr
		gen byte mal5_`i'   = 100 * (ranking_max_`i' == $cal_5) if enr
	}
	drop enr

	* Income: zero in windows covered by the labor data without a job
	merge m:1 pers_identificador t using "$mov/match/ing6.dta", keep(1 3) nogen
	gen byte enr_i = inrange(t, $tmin, $ipc_tmax)
	replace ing_r = 0 if missing(ing_r) & enr_i
	replace emp   = 0 if missing(emp)   & enr_i
	gen double emp_f = 100 * emp / 6 if !missing(emp)
	drop enr_i emp

	label var mal345_B "Worst rating 3, 4 or 5 with banks in the window (0/100)"
	label var mal345_E "Worst rating 3, 4 or 5 with CMFs in the window (0/100)"
	label var mal5_B   "Worst rating 5 with banks in the window (0/100)"
	label var mal5_E   "Worst rating 5 with CMFs in the window (0/100)"
	label var ing_r    "Average real monthly labor income in the window (0 = no job)"
	label var emp_f    "Share of months in the window with a formal job"
	label var pos      "Consumer debt in the window (banks or CMFs)"
	label var pos_B    "Consumer debt with banks in the window"
	label var pos_E    "Consumer debt with CMFs in the window"
	label var tdeuda   "Total active consumer debt (banks + CMFs)"

	egen long unit  = group(pair_id treated)
	gen byte  ek    = rel_sem + 4                  // 0..12 (k=-2 -> 2)
	egen long pairk = group(pair_id ek)
	label var rel_sem "Six-month window relative to the shock month (k)"
	label var t       "First month of the window (g + 6k)"
	compress
	save "$mov/es_panel_`d'.dta", replace
}

* (g) Monthly panel: unit (pair x treated) x month m = -12..12 (m = 0 is g)
foreach d of global defs {
	use "$mov/matched_`d'${sfx_es}.dta", clear
	expand 25
	bysort pair_id treated: gen byte rel_m = _n - 13
	gen int mfecha = g + rel_m
	format mfecha %tm
	merge m:1 pers_identificador mfecha using "$mov/match/crc_mes.dta", keep(1 3) nogen
	gen byte enr = inrange(mfecha, $tmin, $tmax + 5)
	foreach v of varlist pos pos_B pos_E tot* {
		replace `v' = 0 if missing(`v') & enr
	}
	foreach i in B E {
		gen byte mal345_`i' = 100 * (ranking_max_`i' >= $cal_min3 & !missing(ranking_max_`i')) if enr
		gen byte mal5_`i'   = 100 * (ranking_max_`i' == $cal_5) if enr
	}
	drop enr
	merge m:1 pers_identificador mfecha using "$mov/match/ing_mes.dta", keep(1 3) nogen
	gen byte enr_i = (mfecha <= $gmax)
	replace ing_r = 0 if missing(ing_r) & enr_i
	gen byte emp_f = 100 * (ing_r > 0) if enr_i
	drop enr_i
	egen long unit  = group(pair_id treated)
	gen byte  em    = rel_m + 12                   // 0..24
	egen long pairm = group(pair_id em)
	label var rel_m "Month relative to the shock (m)"
	label var ing_r "Real monthly labor income (0 = no job)"
	label var emp_f "Formal job in the month (0/100)"
	compress
	save "$mov/es_mpanel_`d'.dta", replace
}

foreach f in need outcomes ing6 ipc pers_m ing_mes jobs crc_mes {
	capture erase "$mov/match/`f'.dta"
}
if $limpiar {
	forvalues t = $tmin/$tmax {
		local tl : display %tm `t'
		capture erase "$mov/y6/y6_`tl'.dta"
	}
}
