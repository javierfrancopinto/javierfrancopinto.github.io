/*==============================================================================
  0_Master.do

  Adverse labor shocks and household consumer credit in Uruguay.
  Sets paths, installs dependencies, defines the parameters and helper
  programs shared by the scripts, and runs the full pipeline.

  Data
    CRC   Central de Riesgos Crediticios (BCU): monthly debtor-institution
          records, 2001-2024
    MTSS  Social security contributions (cotizantes), monthly, 2010-2023

  Scripts
    1_1  Clean the annual CRC files
    1_2  Relationship duration; drop long-standing grade-5 relationships
    1_3  Quarterly CRC panels
    1_4  Semi-annual CRC panels
    2_1  CRC descriptive graphs
    2_2  Reporting institutions by year
    2_3  Debtor tables by credit rating (replicates Arnabal et al., 2023)
    3_1  CRC-MTSS merge, match diagnostics and monthly credit panel
    3_2  Firm shocks, worker events, characteristics and credit windows
    4_1  Two-stage matching and estimation panels
    4_2  Event studies, tables and graphs

  Sub-scripts rely on the globals and programs defined here, so run them
  through this file. They use -clear- rather than -clear all-, which would
  drop the programs.
==============================================================================*/

clear all
set more off
set graphics off

*------------------------------------------------------------------------------
* Paths
*------------------------------------------------------------------------------
global root "/grupos"
if "`c(username)'"=="jfranco" global scripts "$root/proyectos/financial-topics/Scripts"
else                          global scripts "`c(pwd)'"

global crc_raw   "$root/datos/bcu/central.de.riesgo/originales"
global crc       "$root/datos/bcu/central.de.riesgo/procesadas"
global crc_q     "$root/datos/bcu/central.de.riesgo/trimestrales"
global crc_s     "$root/datos/bcu/central.de.riesgo/semestrales"
global merged    "$root/datos/bcu/central.de.riesgo/merged"
global crcmes    "$merged/mensual"
global mtss      "$root/datos/mtss/procesadas/cotizantes"

global proj      "$root/proyectos/financial-topics"
global graphs    "$proj/Graficos"
global tables    "$proj/Tablas"
global layoffs   "$proj/Layoffs"
global es        "$layoffs/eventstudy"
global mov       "$es/movil"
global es_graphs "$layoffs/graphs"
global es_tables "$layoffs/tables"

*------------------------------------------------------------------------------
* Packages
*------------------------------------------------------------------------------
foreach pkg in estout texsave gtools ereplace asrol ftools require reghdfe {
	capture which `pkg'
	if _rc ssc install `pkg', replace
}

*------------------------------------------------------------------------------
* Event-study parameters (3_2, 4_1, 4_2)
*------------------------------------------------------------------------------
* g is the month of a worker's first mass-layoff exit. Window k covers months
* g+6k to g+6k+5, k = -4..8; k = -2 is the reference window. Controls get g
* as a placebo date.
global defs       "layoff empdrop"   // shock definitions: main and robustness
global gmin     = ym(2014, 1)        // first shock month (k=-4 must start after 2012m1)
global gmax     = ym(2022, 12)       // last month with labor data
global tmin     = ym(2012, 1)        // first window start in the monthly CRC
global tmax     = ym(2023, 7)        // last complete window in the CRC
global ipc_tmax = ym(2022, 7)        // last complete window in the labor data
global kref       7                  // covariates measured in k=-2 (last month g-7)
global kref5    = $kref + 5
global mref_m     -7                 // reference month of the monthly event study
global edad_min   18                 // age bounds over the whole window; the
global edad_max   65                 // CRC panel drops debtors over 65 (3_1)
global edad_lo  = $edad_min + 2      // age at g-1 so that age >= 18 at g-24
global edad_hi  = $edad_max - 5      // age at g-1 so that age <= 65 at g+53
global solo_crc   0                  // 1 = pools restricted to people ever in the CRC
global ceros      1                  // 1 = months without a CRC record count as zero debt
global cal_min3   5                  // recoded rating for grades 3-5 (5=3, 6=4, 7=5)
global cal_5      7                  // recoded rating for grade 5
global trim       99.5               // pre-shock debt percentile above which a pair is dropped
global trims      "99 99.5 99.9"     // cutoffs compared in the trimming diagnostic
global cs_frac    0.05               // share of candidate controls kept for the support graph
global limpiar    1                  // 1 = erase heavy intermediate files once used

* Matching specifications: ex = exact-match variables, nf = candidate control
* firms per treated firm, cal = caliper in SD of the logit index (Austin,
* 2011), rep = 1 for matching with replacement. Estimation uses mspec_es.
global mspecs     "base laxo"
global mspec_es   "base"
global ex_base    "sexo ten_bin"
global nf_base    5
global cal_base   0.2
global rep_base   0
global ex_laxo    "sexo"
global nf_laxo    10
global cal_laxo   0.2
global rep_laxo   0
global sfx_es   = cond("$mspec_es"=="base", "", "_$mspec_es")
global nfmax      0
foreach s of global mspecs {
	if ${nf_`s'} > $nfmax global nfmax ${nf_`s'}
}

* Shock definitions. A treated worker exits a firm (exit_) in a month in
* which the firm has a mass-layoff shock (flag_):
*   layoff  : exit by dismissal, and more than 1/3 of the workforce dismissed
*   empdrop : any exit, and firm employment falls by more than 1/3
global exit_layoff  "layoff"
global flag_layoff  "layoffs_geq_33"
global dlab_layoff  "layoff shock"
global exit_empdrop "any_exit"
global flag_empdrop "var_n_leq_33"
global dlab_empdrop "employment-drop shock"

* Variables in the matching descriptives; dbin lists the binary ones
global dvars edad mujer tenure tb_1 tb_2 tb_3 tb_4 pct_ing crc_m4 crc_m3 ///
	ldB_m4 ldB_m3 ldE_m4 ldE_m3 lvB_m4 lvB_m3 lvE_m4 lvE_m3 venc_m4 venc_m3 ///
	m345B_m4 m345B_m3 m345E_m4 m345E_m3 f_lnsize f_age fs_1 fs_2 fs_3 fs_4
global dbin mujer tb_1 tb_2 tb_3 tb_4 crc_m4 crc_m3 venc_m4 venc_m3 ///
	m345B_m4 m345B_m3 m345E_m4 m345E_m3 fs_1 fs_2 fs_3 fs_4
forvalues c = 0/20 {
	global dvars $dvars sec_`c'
	global dbin  $dbin sec_`c'
}

*------------------------------------------------------------------------------
* Helper programs
*------------------------------------------------------------------------------

* Keeps consumer credit only. tipo comes from a year-by-year -encode- (1_1),
* so its codes can shift across years; filtering on the label is robust.
capture program drop keep_consumer
program define keep_consumer
	tempvar lab
	decode tipo, gen(`lab')
	keep if strpos(lower(`lab'), "consumo") > 0
end

* ISIC rev. 4 section (1-20; 0 = missing) from the 2-digit division
capture program drop ciiu_section
program define ciiu_section
	args div newvar
	gen byte `newvar' = 0
	replace `newvar' = 1  if inrange(`div', 1, 3)      // A agriculture
	replace `newvar' = 2  if inrange(`div', 5, 9)      // B mining
	replace `newvar' = 3  if inrange(`div', 10, 33)    // C manufacturing
	replace `newvar' = 4  if `div'==35                 // D electricity
	replace `newvar' = 5  if inrange(`div', 36, 39)    // E water
	replace `newvar' = 6  if inrange(`div', 41, 43)    // F construction
	replace `newvar' = 7  if inrange(`div', 45, 47)    // G trade
	replace `newvar' = 8  if inrange(`div', 49, 53)    // H transport
	replace `newvar' = 9  if inrange(`div', 55, 56)    // I accommodation
	replace `newvar' = 10 if inrange(`div', 58, 63)    // J information
	replace `newvar' = 11 if inrange(`div', 64, 66)    // K finance
	replace `newvar' = 12 if `div'==68                 // L real estate
	replace `newvar' = 13 if inrange(`div', 69, 75)    // M professional
	replace `newvar' = 14 if inrange(`div', 77, 82)    // N support services
	replace `newvar' = 15 if `div'==84                 // O public administration
	replace `newvar' = 16 if `div'==85                 // P education
	replace `newvar' = 17 if inrange(`div', 86, 88)    // Q health
	replace `newvar' = 18 if inrange(`div', 90, 93)    // R arts
	replace `newvar' = 19 if inrange(`div', 94, 96)    // S other services
	replace `newvar' = 20 if inrange(`div', 97, 99)    // T-U households
end

* Dummies for the matching descriptives (needs sexo, ten_bin, f_size, sector).
* Women: sexo == 1.
capture program drop desc_prep
program define desc_prep
	capture drop mujer
	capture drop tb_*
	capture drop fs_*
	capture drop sec_*
	gen byte mujer = (sexo==1) if !missing(sexo)
	forvalues c = 1/4 {
		gen byte tb_`c' = (ten_bin==`c') if !missing(ten_bin)
		gen byte fs_`c' = (f_size==`c') if !missing(f_size)
	}
	forvalues c = 0/20 {
		gen byte sec_`c' = (sector==`c') if !missing(sector)
	}
end

* Collapses $dvars to counts (n_), sums (s_) and sums of squares (q_) by
* grp, so that means and variances can be pooled later. extra: additional
* collapse statistics.
capture program drop desc_sums
program define desc_sums
	args extra
	local cspec ""
	foreach v of global dvars {
		if strpos(" $dbin ", " `v' ") {
			local cspec `cspec' (count) n_`v'=`v' (sum) s_`v'=`v' (sum) q_`v'=`v'
		}
		else {
			qui gen double sq_`v' = `v'^2
			local cspec `cspec' (count) n_`v'=`v' (sum) s_`v'=`v' (sum) q_`v'=sq_`v'
		}
	}
	collapse `cspec' `extra', by(grp)
end

* Kaplan-Meier time to re-employment on the data in memory (dur = months,
* reemp = 1 if re-employed, 0 if censored). Returns r(F1)...r(F36), the
* share re-employed at 1, 3, 6, 12, 24 and 36 months, and r(med).
* Replaces the data in memory.
capture program drop km_at
program define km_at, rclass
	drop if dur <= 0 | missing(dur)
	if _N==0 exit
	gen byte one = 1
	collapse (sum) dfail=reemp (count) ntot=one, by(dur)
	gsort -dur
	gen double nrisk = sum(ntot)
	sort dur
	gen double S = 1 - dfail / nrisk
	replace S = S * S[_n-1] if _n > 1
	foreach h in 1 3 6 12 24 36 {
		qui sum S if dur <= `h'
		if r(N)==0 return scalar F`h' = 0
		else return scalar F`h' = 100 * (1 - r(min))
	}
	qui sum dur if S <= 0.5
	return scalar med = r(min)
end

* Treated x event-time dummies, omitting the reference period. Names use m
* for negative and p for non-negative periods (D_m4, D_p0, ...).
capture program drop es_dummies
program define es_dummies, rclass
	syntax, time(varname) from(integer) to(integer) ref(integer) prefix(name)
	local list ""
	forvalues k = `from'/`to' {
		if `k'==`ref' continue
		local nm = cond(`k' < 0, "m" + string(abs(`k')), "p" + string(`k'))
		gen byte `prefix'_`nm' = (treated==1 & `time'==`k')
		local list `list' `prefix'_`nm'
	}
	return local list `list'
end

* trim_<v> = 1 for pairs where the treated or the control is above the
* given percentile of pre-shock debt (maximum over k = -4..-2). Never trims
* on post-shock debt. Needs unit, pair_id, rel_sem and tagu (one per unit).
capture program drop trim_flags
program define trim_flags
	syntax varlist, pct(real)
	foreach v of local varlist {
		gen byte tr_`v' = 0
		if `pct' < 100 {
			tempvar pre tp
			bysort unit: egen double `pre' = max(cond(inrange(rel_sem, -4, -2), `v', .))
			qui _pctile `pre' if tagu, p(`pct')
			local cut = r(r1)
			bysort pair_id: egen byte `tp' = max(`pre' > `cut' & !missing(`pre'))
			replace tr_`v' = `tp'
			drop `pre' `tp'
		}
	}
end

* Event-study graph from a results file in memory (coef, se, lb, ub by
* event time). Adds the reference period at zero. note() and text() take
* full twoway arguments, e.g. note("N = 10.", size(small)).
capture program drop es_plot
program define es_plot
	syntax, time(varname) ref(integer) file(string) title(string) ///
		xtitle(string) ytitle(string) xlabel(string) ///
		[note(string asis) text(string asis) msize(string)]
	if "`msize'"=="" local msize "medium"
	local topt ""
	if `"`text'"' != "" local topt `"text(`text')"'
	local nopt ""
	if `"`note'"' != "" local nopt `"note(`note')"'

	local N = _N + 1
	set obs `N'
	replace `time' = `ref' in `N'
	foreach z in coef se lb ub {
		replace `z' = 0 in `N'
	}
	sort `time'
	tempvar post
	gen byte `post' = (`time' >= 0)

	twoway (rarea lb ub `time', color(navy%15) lwidth(none)) ///
	       (line coef `time', lcolor(navy) lwidth(medthick)) ///
	       (scatter coef `time' if `post'==0, mcolor(gs8) msymbol(circle) msize(`msize')) ///
	       (scatter coef `time' if `post'==1, mcolor(navy) msymbol(circle) msize(`msize')), ///
	       yline(0, lpattern(dash) lcolor(gs10)) xline(-0.5, lpattern(dash) lcolor(gs10)) ///
	       `topt' xtitle("`xtitle'") ytitle("`ytitle'") title("`title'", size(medium)) ///
	       xlabel(`xlabel') `nopt' legend(off) graphregion(color(white))
	graph export "`file'", replace
end

* Readable outcome names for graph titles
capture program drop outlab
program define outlab, rclass
	args v
	local l "`v'"
	if "`v'"=="totdeuda_B"   local l "Total active debt to banks"
	if "`v'"=="totdeuda_E"   local l "Total active debt to CMFs"
	if "`v'"=="totvencida_B" local l "Overdue debt to banks"
	if "`v'"=="totvencida_E" local l "Overdue debt to CMFs"
	if "`v'"=="totcast_B"    local l "Written-off debt to banks"
	if "`v'"=="totcast_E"    local l "Written-off debt to CMFs"
	if "`v'"=="ext"          local l "Has consumer debt"
	if "`v'"=="ext_B"        local l "Has consumer debt with banks"
	if "`v'"=="ext_E"        local l "Has consumer debt with CMFs"
	if "`v'"=="entry"        local l "Enters consumer credit (no debt at k=-2)"
	if "`v'"=="incr"         local l "Debt above k=-2 level (debt at k=-2)"
	if "`v'"=="mal345_B"     local l "Worst credit rating 3, 4 or 5 with banks"
	if "`v'"=="mal345_E"     local l "Worst credit rating 3, 4 or 5 with CMFs"
	if "`v'"=="mal5_B"       local l "Worst credit rating 5 with banks"
	if "`v'"=="mal5_E"       local l "Worst credit rating 5 with CMFs"
	if "`v'"=="ing_r"        local l "Real monthly labor income"
	if "`v'"=="emp_f"        local l "Formal employment"
	return local lab "`l'"
end

*------------------------------------------------------------------------------
* Pipeline
*------------------------------------------------------------------------------
cd "$scripts"

* CRC cleaning and panels
do 1_1_Process
do 1_2_Duration
do 1_3_Quarters
do 1_4_Semesters

* CRC descriptives
do 2_1_Descriptives
do 2_2_Institutions
do 2_3_Tables          // optional: replicates Arnabal et al. (2023)

* CRC-MTSS merge and event-study inputs
do 3_1_Merge
do 3_2_Merge

* Matching and results
do 4_1_Matching
do 4_2_Results
