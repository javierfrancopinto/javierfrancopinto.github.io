/*==============================================================================
  2_2_Institutions.do
  Table of the institutions that report to the CRC in each year, 2001-2024.
  Input : $crc/central_<year>.dta
  Output: $proj/Instituciones/<year>_instituciones.dta,
          $tables/tabla_instituciones.tex
==============================================================================*/

clear
cap mkdir "$proj/Instituciones"
cap mkdir "$tables"

* Institutions present in each year
forvalues y = 2001/2024 {
	use institucion year if year==`y' using "$crc/central_`y'.dta", clear
	duplicates drop
	gen byte presente = 1
	save "$proj/Instituciones/`y'_instituciones.dta", replace
}

clear
forvalues y = 2001/2024 {
	append using "$proj/Instituciones/`y'_instituciones.dta"
}
reshape wide presente, i(institucion) j(year)
foreach var of varlist presente* {
	replace `var' = 0 if missing(`var')
}
sort institucion

*------------------------------------------------------------------------------
* LaTeX table (landscape longtable)
*------------------------------------------------------------------------------
local years ""
forvalues y = 2001/2024 {
	local years "`years' & `y'"
}

file open latex using "$tables/tabla_instituciones.tex", write replace
file write latex "\begin{landscape}" _n
file write latex "\begin{longtable}{l*{24}{c}}" _n
file write latex "\caption{Institution presence by year} \label{tab:instituciones} \\" _n
file write latex "\toprule" _n
file write latex "Institution`years' \\" _n
file write latex "\midrule" _n
file write latex "\endfirsthead" _n
file write latex "\multicolumn{25}{c}{{\bfseries \tablename\ \thetable{} -- continued}} \\" _n
file write latex "\toprule" _n
file write latex "Institution`years' \\" _n
file write latex "\midrule" _n
file write latex "\endhead" _n
file write latex "\midrule \multicolumn{25}{r}{{...}} \\" _n
file write latex "\endfoot" _n
file write latex "\bottomrule" _n
file write latex "\endlastfoot" _n

forvalues i = 1/`=_N' {
	file write latex "`=institucion[`i']'"
	foreach var of varlist presente* {
		file write latex " & `=`var'[`i']'"
	}
	file write latex " \\" _n
}

file write latex "\midrule" _n
file write latex "\textbf{Total}"
foreach var of varlist presente* {
	qui sum `var'
	file write latex " & \textbf{`=r(sum)'}"
}
file write latex " \\" _n
file write latex "\end{longtable}" _n
file write latex "\end{landscape}" _n
file close latex
