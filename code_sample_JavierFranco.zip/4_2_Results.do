/*==============================================================================
  4_2_Results.do
  Descriptive graphs of the shocks, matching tables and event-study results.
    1. Firm shocks and seasonality
    2. Matching tables and common support
    3. Event study, debt levels (six-month windows)
    4. Trimming diagnostic
    5. Event study, extensive and intensive margins and ratings
    6. Event study, labor income and employment
    7. Event study, monthly
    8. Re-employment of the treated
    9. Shocks, treated workers and matched pairs by year
   10. Heterogeneous effects
   11. Anonymized estimation panel
  Design of every event study: unit (pair x treated) and pair x period fixed
  effects, so each coefficient compares a treated worker with their own
  control relative to k=-2; standard errors clustered by the event firm.
  Specification 2 adds k x covariates measured in k=-2 (age, sex, sector,
  firm size, income decile).
  Input : outputs of 3_2_Merge.do and 4_1_Matching.do
  Output: graphs in $es_graphs, tables in $es_tables, results in $mov/results
==============================================================================*/

clear
cap mkdir "$es_graphs"
cap mkdir "$es_tables"

local debt_vars totdeuda_B totdeuda_E totvencida_B totvencida_E totcast_B totcast_E
local xctrl_k "i.ek#c.edad i.ek#i.sexo i.ek#i.sector_k2 i.ek#i.fsz_k2 i.ek#i.dec_ing"
local gminl = strtrim(string($gmin, "%tm"))
local gmaxl = strtrim(string($gmax, "%tm"))

*------------------------------------------------------------------------------
* 1. Firm shocks and seasonality
*------------------------------------------------------------------------------
use "$layoffs/cotizantes2010_2022_hhll.dta", clear

* Closures: one row per firm, so that the closure year is kept even if the
* closure month itself was dropped by the firm-size filter
preserve
egen byte tag_firm = tag(j)
keep if tag_firm==1 & !missing(anio_desaparicion)
gen byte real_closure = 1
collapse (sum) real_closure, by(anio_desaparicion)
rename anio_desaparicion anio
tempfile closures
save `closures'
restore

preserve
collapse (sum) var_n_leq_33 layoffs_geq_33, by(anio)
merge 1:1 anio using `closures', nogen
recode real_closure (.=0)
tsset anio
tsline var_n_leq_33 layoffs_geq_33 real_closure, ///
	title("Firms with an adverse labor shock (monthly)") ///
	ytitle("Number of firms") xtitle("Year") ///
	legend(order(1 "Employment drop" 2 "Layoffs" 3 "Closures (non-phoenix)") rows(2))
graph export "$es_graphs/g1_monthly_criteria.pdf", replace
restore

* 12-month indicators stay on for consecutive months: count each firm once
* per year
preserve
collapse (max) var_n12_leq_33 layoffs12_geq_33, by(j anio)
collapse (sum) var_n12_leq_33 layoffs12_geq_33, by(anio)
tsset anio
tsline var_n12_leq_33 layoffs12_geq_33, ///
	title("Firms with an adverse labor shock (12-month moving average)") ///
	ytitle("Number of firms") xtitle("Year") ///
	legend(order(1 "Employment drop" 2 "Layoffs") rows(1))
graph export "$es_graphs/g2_12month_criteria.pdf", replace
restore

preserve
collapse (sum) layoffs_geq_33, by(anio firm_size)
drop if missing(firm_size)
reshape wide layoffs_geq_33, i(anio) j(firm_size)
tsset anio
tsline layoffs_geq_332 layoffs_geq_333 layoffs_geq_334 layoffs_geq_335, ///
	title("Firms with a layoff shock (monthly), by firm size") ///
	ytitle("Number of firm-months") xtitle("Year") ///
	legend(order(1 "5-9" 2 "10-19" 3 "20-99" 4 ">=100") rows(2))
graph export "$es_graphs/g3_layoffs_by_firmsize.pdf", replace
restore

* Top 8 ISIC divisions by number of layoff shocks
preserve
gen int CIIU2 = floor(CIIU4/100)
drop if missing(CIIU2)
bysort CIIU2: egen n_sector = total(layoffs_geq_33)
egen rank = group(n_sector CIIU2)
qui sum rank
keep if rank > r(max) - 8
collapse (sum) layoffs_geq_33, by(anio CIIU2)
reshape wide layoffs_geq_33, i(anio) j(CIIU2)
tsset anio
tsline layoffs_geq_33*, ///
	title("Firms with a layoff shock (monthly), by sector") ///
	subtitle("Top 8 sectors (2-digit CIIU) by layoff volume") ///
	ytitle("Number of firm-months") xtitle("Year")
graph export "$es_graphs/g4_layoffs_by_sector.pdf", replace
restore

* Seasonality: employment-drop firm-months by calendar month
qui count if !missing(var_n_leq_33)
local nfm = strtrim(string(r(N), "%15.0fc"))
graph bar (mean) var_n_leq_33, over(mescargo) ///
	ytitle("Share of firm-months with employment drop") ///
	title("Employment-drop shocks by calendar month", size(medium)) ///
	note("N = `nfm' firm-months.", size(small)) graphregion(color(white))
graph export "$es_graphs/season_empdrop_firms.pdf", replace

* Seasonality: treatment events by calendar month
foreach d of global defs {
	use mes_layoff using "$mov/first_event_m_`d'.dta", clear
	qui count if !missing(mes_layoff)
	local nev = strtrim(string(r(N), "%12.0fc"))
	histogram mes_layoff, discrete percent ///
		xlabel(1(1)12) xtitle("Calendar month of the event") ///
		title("Treatment events by calendar month, ${dlab_`d'}", size(medium)) ///
		note("N = `nev' treatment events.", size(small)) graphregion(color(white))
	graph export "$es_graphs/season_events_`d'.pdf", replace
}

* Seasonality: overdue debt by semester (S2 vs S1 net of year effects)
use year sem totvencida_B totvencida_E using "$merged/sem_merge3.dta", clear
tabstat totvencida_B totvencida_E, by(sem) stat(mean n)
local nds = strtrim(string(_N, "%15.0fc"))
collapse (mean) totvencida_B totvencida_E, by(year sem)
reg totvencida_B i.sem i.year
reg totvencida_E i.sem i.year
gen double tt = year + (sem - 1)/2
twoway (connected totvencida_B tt, msymbol(circle)) ///
       (connected totvencida_E tt, msymbol(triangle)), ///
	legend(order(1 "Banks" 2 "CMFs")) ///
	xtitle("Year (S1 / S2)") ytitle("Mean overdue debt") ///
	title("Overdue debt by semester", size(medium)) ///
	note("N = `nds' debtor-semesters.", size(small)) graphregion(color(white))
graph export "$es_graphs/season_overdue.pdf", replace

*------------------------------------------------------------------------------
* 2. Matching tables and common support
*------------------------------------------------------------------------------
* By definition and specification, in $es_tables:
*   matching_<def>.tex         means before and after matching, with
*                              standardized differences
*   matching_sector_<def>.tex  sector composition
*   matching_flow_<def>.tex    sample construction
* and common_support_<def>.pdf (score index before and after matching).
* Groups: 1 all treated, 2 control pool, 3 matched treated, 4 matched controls.
local sn0  "Missing"
local sn1  "Agriculture"
local sn2  "Mining"
local sn3  "Manufacturing"
local sn4  "Electricity and gas"
local sn5  "Water and waste"
local sn6  "Construction"
local sn7  "Wholesale and retail trade"
local sn8  "Transport and storage"
local sn9  "Accommodation and food"
local sn10 "Information and communication"
local sn11 "Finance and insurance"
local sn12 "Real estate"
local sn13 "Professional services"
local sn14 "Administrative and support services"
local sn15 "Public administration"
local sn16 "Education"
local sn17 "Health and social work"
local sn18 "Arts and recreation"
local sn19 "Other services"
local sn20 "Households and extraterritorial"

local lab_mujer    "Women (\%)"
local lab_edad     "Age (years)"
local lab_tenure   "Tenure at the firm (months)"
local lab_tb_1     "\quad Tenure \(<\) 1 year (\%)"
local lab_tb_2     "\quad Tenure 1--3 years (\%)"
local lab_tb_3     "\quad Tenure 3--5 years (\%)"
local lab_tb_4     "\quad Tenure 5+ years (\%)"
local lab_pct_ing  "Labor income percentile, \(k=-2\)"
foreach w in 4 3 {
	local lab_crc_m`w'   "In the credit registry, \(k=-`w'\) (\%)"
	local lab_ldB_m`w'   "log(1 + active debt), banks, \(k=-`w'\)"
	local lab_ldE_m`w'   "log(1 + active debt), CMFs, \(k=-`w'\)"
	local lab_lvB_m`w'   "log(1 + overdue debt), banks, \(k=-`w'\)"
	local lab_lvE_m`w'   "log(1 + overdue debt), CMFs, \(k=-`w'\)"
	local lab_venc_m`w'  "Any overdue debt, \(k=-`w'\) (\%)"
	local lab_m345B_m`w' "Worst rating 3, 4 or 5, banks, \(k=-`w'\) (\%)"
	local lab_m345E_m`w' "Worst rating 3, 4 or 5, CMFs, \(k=-`w'\) (\%)"
}
local lab_f_lnsize "Firm log employment (12-month average)"
local lab_f_age    "Firm age (months)"
local pctv "mujer tb_1 tb_2 tb_3 tb_4 crc_m4 crc_m3 venc_m4 venc_m3 m345B_m4 m345B_m3 m345E_m4 m345E_m3 fs_1 fs_2 fs_3 fs_4"

foreach d of global defs {
	capture confirm file "$mov/results/desc_pre_`d'.dta"
	if _rc {
		di as error "`d': pre-matching descriptives missing (run 4_1)"
		continue
	}
	local dlab "${dlab_`d'}"

	use "$mov/first_event_m_`d'.dta", clear
	qui count if inrange(mfecha_event, $gmin, $gmax) & multi_shock==0 & multi_job==0
	local n_all = r(N)

	foreach s of global mspecs {
		local sfx = cond("`s'"=="base", "", "_`s'")
		capture confirm file "$mov/matched_`d'`sfx'.dta"
		if _rc {
			di as error "`d': matched_`d'`sfx' missing (run 4_1)"
			continue
		}
		local slab = cond("`s'"=="base", "", ", relaxed matching")
		local exl ""
		if strpos(" ${ex_`s'} ", " sexo ")    local exl "sex"
		if strpos(" ${ex_`s'} ", " ten_bin ") local exl = cond("`exl'"=="", "tenure bracket", "`exl' and tenure bracket")
		if "`exl'"=="" local exl "none"
		local repl = cond(${rep_`s'}, "with", "without")

		* Treated with candidate control firms, and share off common support
		use "$mov/results/cs_`d'`sfx'.dta", clear
		qui count if treated==1
		local n_cs = r(N)
		qui sum offsup if treated==1
		local p_off = 100 * r(mean)

		* Groups 3 and 4
		use "$mov/matched_`d'`sfx'.dta", clear
		forvalues c = 1/4 {
			local fsl`c' : label (f_size) `c'
			local fsl`c' = subinstr("`fsl`c''", "<", "\(<\)", .)
			local fsl`c' = subinstr("`fsl`c''", ">", "\(>\)", .)
			local lab_fs_`c' "\quad Firm size: `fsl`c'' (\%)"
		}
		desc_prep
		gen byte grp = cond(treated==1, 3, 4)
		desc_sums
		tempfile postm
		save `postm'

		* Groups 1 and 2, pooled over shock months
		use "$mov/results/desc_pre_`d'.dta", clear
		collapse (sum) n_* s_* q_*, by(grp)
		append using `postm'
		sort grp
		assert _N==4
		foreach v of global dvars {
			gen double m_`v' = s_`v' / n_`v'
			gen double v_`v' = (q_`v' - s_`v'^2 / n_`v') / (n_`v' - 1)
		}
		local n_base = n_edad[1]
		local n_age  = n_age[1]
		local n_m    = n_edad[3]

		*--- Table 1: matching variables
		file open tex using "$es_tables/matching_`d'`sfx'.tex", write replace
		file write tex "\begin{table}[htbp]" _n "\centering" _n "\scriptsize" _n
		file write tex "\caption{Matching variables before and after matching, `dlab'`slab'}" _n
		file write tex "\label{tab:matching_`d'`sfx'}" _n
		file write tex "\resizebox{\textwidth}{!}{%" _n
		file write tex "\begin{tabular}{lcccccccc}" _n "\hline" _n
		file write tex " & \multicolumn{3}{c}{Before matching} & \multicolumn{3}{c}{After matching} & & \\" _n
		file write tex " & All treated & Control pool & Std. diff. & Treated & Controls & Std. diff. & Std. diff. & Use in \\" _n
		file write tex " & (1) & (2) & (3) & (4) & (5) & (6) & (7) & matching \\" _n
		file write tex "\hline" _n
		foreach panel in A B C {
			if "`panel'"=="A" {
				local rows "mujer edad tenure tb_1 tb_2 tb_3 tb_4 pct_ing"
				local ptit "Panel A. Worker"
			}
			if "`panel'"=="B" {
				local rows "crc_m4 crc_m3 ldB_m4 ldB_m3 ldE_m4 ldE_m3 lvB_m4 lvB_m3 lvE_m4 lvE_m3 venc_m4 venc_m3 m345B_m4 m345B_m3 m345E_m4 m345E_m3"
				local ptit "Panel B. Consumer credit before the shock"
			}
			if "`panel'"=="C" {
				local rows "f_lnsize f_age fs_1 fs_2 fs_3 fs_4"
				local ptit "Panel C. Firm, \(g-7\)"
			}
			file write tex "\multicolumn{9}{l}{\textit{`ptit'}} \\" _n
			foreach v of local rows {
				local sc  = cond(strpos(" `pctv' ", " `v' ") > 0, 100, 1)
				local fmt = cond(`sc'==100, "%9.1f", "%9.2f")
				forvalues r = 1/4 {
					local c`r' = strtrim(string(`sc' * m_`v'[`r'], "`fmt'"))
					if "`c`r''"=="." local c`r' "--"
				}
				local d12 = (m_`v'[1] - m_`v'[2]) / sqrt((v_`v'[1] + v_`v'[2])/2)
				local d45 = (m_`v'[3] - m_`v'[4]) / sqrt((v_`v'[3] + v_`v'[4])/2)
				local d41 = (m_`v'[3] - m_`v'[1]) / sqrt((v_`v'[3] + v_`v'[1])/2)
				foreach dd in d12 d45 d41 {
					local `dd' = strtrim(string(``dd'', "%6.3f"))
					if "``dd''"=="." local `dd' "--"
				}
				* Use: check = enters the score; cross = exact match; empty = descriptive
				local use "\(\checkmark\)"
				if "`v'"=="tenure" local use ""
				if "`v'"=="mujer" & strpos(" ${ex_`s'} ", " sexo ") local use "\(\times\)"
				if substr("`v'", 1, 3)=="tb_" & strpos(" ${ex_`s'} ", " ten_bin ") local use "\(\times\)"
				if substr("`v'", 1, 3)=="fs_" local use "\(\times\)"
				file write tex "`lab_`v''" " & `c1' & `c2' & `d12' & `c3' & `c4' & `d45' & `d41' & `use' \\" _n
			}
		}
		forvalues r = 1/4 {
			local nn`r' = strtrim(string(n_edad[`r'], "%15.0fc"))
		}
		* Columns (1) and (2): distinct people (pool means are over worker-months)
		preserve
		capture use "$mov/results/ids_pre_`d'.dta", clear
		if !_rc {
			forvalues r = 1/2 {
				qui count if grp==`r'
				local nn`r' = strtrim(string(r(N), "%15.0fc"))
			}
		}
		restore
		file write tex "\hline" _n
		file write tex "Individuals & `nn1' & `nn2' & & `nn3' & `nn4' & & & \\" _n
		file write tex "\hline" _n
		file write tex "\end{tabular}}" _n
		file write tex "\begin{minipage}{\textwidth}\vspace{3pt}\tiny" _n
		file write tex "Notes: (1) all treated workers in the matching base (employed at \(g-1\) in a firm with 5+ employees, no other concurrent job, all ages). (2) eligible controls (employed at \(g-1\) and \(g\) in the same firm, no exit in \(g\), no own shock before \(g+53\)), pooled over shock months \(g\): means are over worker-months, the last row counts distinct workers. (3) standardized difference between (1) and (2). (4)--(5) matched sample: workers aged $edad_lo--$edad_hi at \(g-1\); control firms: up to ${nf_`s'} firms per treated firm with the same ISIC division (section if none) and size, ranked by a firm logit on log employment and firm age; workers: exact match on `exl', nearest neighbor on the worker logit score within a caliper of ${cal_`s'} standard deviations, `repl' replacement. (6) standardized difference between (4) and (5); (7) between (4) and (1), a measure of how representative the matched treated are of all treated. Use in matching: \(\checkmark\) enters the propensity score (worker logit; firm logit for firm log employment and age), \(\times\) exact match; income enters the worker score as ventile dummies. Standardized difference: difference in means over the square root of the average of the two variances. Debt variables are log(1 + constant pesos) in the windows \(k=-4\) (months \(g-24\) to \(g-19\)) and \(k=-3\) (\(g-18\) to \(g-13\)). Income percentile: average over \(g-12\) to \(g-7\)." _n
		file write tex "\end{minipage}" _n
		file write tex "\end{table}" _n
		file close tex

		*--- Table 2: sector composition
		file open tex using "$es_tables/matching_sector_`d'`sfx'.tex", write replace
		file write tex "\begin{table}[htbp]" _n "\centering" _n "\scriptsize" _n
		file write tex "\caption{Sector composition before and after matching (\%), `dlab'`slab'}" _n
		file write tex "\label{tab:matching_sector_`d'`sfx'}" _n
		file write tex "\begin{tabular}{lcccc}" _n "\hline" _n
		file write tex " & All treated & Control pool & Matched treated & Matched controls \\" _n
		file write tex "\hline" _n
		foreach c in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 0 {
			forvalues r = 1/4 {
				local c`r' = strtrim(string(100 * m_sec_`c'[`r'], "%9.1f"))
				if "`c`r''"=="." local c`r' "--"
			}
			file write tex "`sn`c''" " & `c1' & `c2' & `c3' & `c4' \\" _n
		}
		file write tex "\hline" _n "\end{tabular}" _n
		file write tex "\begin{minipage}{0.8\textwidth}\vspace{3pt}\tiny" _n
		file write tex "Notes: ISIC rev. 4 section of the worker's firm at \(g-1\). Groups as in Table \ref{tab:matching_`d'`sfx'}." _n
		file write tex "\end{minipage}" _n
		file write tex "\end{table}" _n
		file close tex

		*--- Table 3: sample construction
		local fl1 "Treated with a first event in `gminl'--`gmaxl' (no multiple shocks or jobs)"
		local fl2 "Employed at \(g-1\) in a firm with 5+ employees"
		local fl3 "Aged $edad_lo--$edad_hi at \(g-1\)"
		local fl4 "With candidate control firms (same sector and size, no shock)"
		local fl5 "Matched (control within the caliper)"
		local fv1 = `n_all'
		local fv2 = `n_base'
		local fv3 = `n_age'
		local fv4 = `n_cs'
		local fv5 = `n_m'
		local poffs = strtrim(string(`p_off', "%5.1f"))
		file open tex using "$es_tables/matching_flow_`d'`sfx'.tex", write replace
		file write tex "\begin{table}[htbp]" _n "\centering" _n "\scriptsize" _n
		file write tex "\caption{Sample construction, `dlab'`slab'}" _n
		file write tex "\label{tab:matching_flow_`d'`sfx'}" _n
		file write tex "\begin{tabular}{lcc}" _n "\hline" _n
		file write tex " & Treated workers & \% of all treated \\" _n "\hline" _n
		forvalues r = 1/5 {
			local a = strtrim(string(`fv`r'', "%12.0fc"))
			local b = strtrim(string(100 * `fv`r'' / `n_all', "%5.1f"))
			file write tex "`fl`r''" " & `a' & `b' \\" _n
		}
		file write tex "\hline" _n
		file write tex "Off common support (\% of the treated with candidate firms) & `poffs' & \\" _n
		file write tex "\hline" _n "\end{tabular}" _n
		file write tex "\begin{minipage}{0.8\textwidth}\vspace{3pt}\tiny" _n
		file write tex "Notes: off common support = score index outside the range of the candidate controls of the same shock month. Matching is `repl' replacement within each shock month, with a caliper of ${cal_`s'} standard deviations of the score index; exact match on `exl'; up to ${nf_`s'} control firms per treated firm." _n
		file write tex "\end{minipage}" _n
		file write tex "\end{table}" _n
		file close tex

		*--- Common support. Axis: percentiles 1-99 of treated and controls
		* (a few controls have extreme indices that flatten the graph).
		use "$mov/results/cs_`d'`sfx'.dta", clear
		local ncs = strtrim(string(`n_cs', "%12.0fc"))
		qui _pctile xb_c if treated==1, p(1 99)
		local lo = r(r1)
		local hi = r(r2)
		qui _pctile xb_c if treated==0 [aweight=w_cs], p(1 99)
		local lo = min(`lo', r(r1))
		local hi = max(`hi', r(r2))
		twoway (kdensity xb_c if treated==1 & inrange(xb_c, `lo', `hi'), range(`lo' `hi') lcolor(navy) lwidth(medthick)) ///
		       (kdensity xb_c if treated==0 & inrange(xb_c, `lo', `hi') [aweight=w_cs], range(`lo' `hi') lcolor(maroon) lpattern(dash) lwidth(medthick)), ///
			title("Before matching", size(medium)) ///
			xtitle("Score index (centered by shock month)") ytitle("Density") ///
			legend(order(1 "Treated" 2 "Candidate controls") position(6) cols(2)) ///
			note("Treated: `ncs'. Off support: `poffs'%. Axis: 1st-99th percentiles.", size(small)) ///
			graphregion(color(white)) name(cs_pre, replace)
		use treated xb_c using "$mov/matched_`d'`sfx'.dta", clear
		local nmp = strtrim(string(`n_m', "%12.0fc"))
		twoway (kdensity xb_c if treated==1 & inrange(xb_c, `lo', `hi'), range(`lo' `hi') lcolor(navy) lwidth(medthick)) ///
		       (kdensity xb_c if treated==0 & inrange(xb_c, `lo', `hi'), range(`lo' `hi') lcolor(maroon) lpattern(dash) lwidth(medthick)), ///
			title("After matching", size(medium)) ///
			xtitle("Score index (centered by shock month)") ytitle("Density") ///
			legend(order(1 "Treated" 2 "Matched controls") position(6) cols(2)) ///
			note("Pairs: `nmp'.", size(small)) ///
			graphregion(color(white)) name(cs_post, replace)
		graph combine cs_pre cs_post, cols(2) graphregion(color(white)) ///
			title("Common support, `dlab'`slab'", size(medium)) xsize(10) ysize(4.5)
		graph export "$es_graphs/common_support_`d'`sfx'.pdf", replace
		graph drop cs_pre cs_post
	}
}

*------------------------------------------------------------------------------
* 3. Event study, debt levels
*------------------------------------------------------------------------------
* Samples: "all" = every pair; "pos" = pairs where both members had active
* debt with the outcome's institution type at k=-2 (suffix _pos).
* Pairs above the trim percentile of pre-shock debt are dropped, by outcome.
foreach combo in "1 all" "2 all" "1 pos" "2 pos" {
	local spec    : word 1 of `combo'
	local muestra : word 2 of `combo'
	local sname = cond(`spec'==1, "nocontrols", "controls")
	local slab  = cond(`spec'==1, "no controls", "with controls")
	local xctrl = cond(`spec'==2, "`xctrl_k'", "")
	if "`muestra'"=="pos" {
		local sname "`sname'_pos"
		local slab  "`slab', debtors at k=-2"
	}

	foreach d of global defs {
		use "$mov/es_panel_`d'.dta", clear
		egen byte tagu = tag(unit)
		foreach i in B E {
			bysort unit: egen byte p2_`i' = max(cond(rel_sem==-2, totdeuda_`i' > 0 & !missing(totdeuda_`i'), .))
			bysort pair_id: egen byte bpos_`i' = min(p2_`i')
		}
		trim_flags `debt_vars', pct($trim)
		es_dummies, time(rel_sem) from(-4) to(8) ref(-2) prefix(D)
		local dlist `r(list)'

		capture postutil clear
		local res_file "$mov/results/res_`d'_`sname'.dta"
		tempname results
		postfile `results' str20 outcome int k double(coef se lb ub) long(n_treat n_ctrl) ///
			double mean_ref long(n_trim n_pairs n_obs) using "`res_file'", replace

		foreach v of local debt_vars {
			qui count if tr_`v' & tagu & treated==1
			local ntrim = r(N)
			local inst = substr("`v'", -1, 1)
			local ifc "if tr_`v'==0"
			if "`muestra'"=="pos" local ifc "`ifc' & bpos_`inst'==1"

			capture noisily reghdfe `v' `dlist' `xctrl' `ifc', absorb(unit pairk) vce(cluster j_cluster)
			if _rc {
				di as error "`d' / `sname' / `v': reghdfe failed (rc=`=_rc')"
				continue
			}
			qui sum `v' if e(sample) & treated==1 & rel_sem==-2
			local mref = r(mean)
			tempvar tp
			qui egen byte `tp' = tag(pair_id) if e(sample)
			qui count if `tp'==1
			local npairs = r(N)
			local nobs = e(N)
			drop `tp'
			forvalues k = -4/8 {
				if `k'==-2 continue
				local nm = cond(`k' < 0, "m" + string(abs(`k')), "p" + string(`k'))
				local b = _b[D_`nm']
				local se = _se[D_`nm']
				if `se'==0 | missing(`se') {
					local b = .
					local se = .
				}
				qui count if e(sample) & treated==1 & rel_sem==`k'
				local n_t = r(N)
				qui count if e(sample) & treated==0 & rel_sem==`k'
				local n_c = r(N)
				post `results' ("`v'") (`k') (`b') (`se') (`b' - 1.96*`se') (`b' + 1.96*`se') ///
					(`n_t') (`n_c') (`mref') (`ntrim') (`npairs') (`nobs')
			}
		}
		postclose `results'

		use "`res_file'", clear
		sort outcome k
		di as text "=== Results `d' / `sname' ==="
		list, sepby(outcome) noobs

		local tnote = cond($trim < 100, " Pairs above p$trim of pre-shock debt dropped.", "")
		levelsof outcome, local(outcomes)
		foreach v of local outcomes {
			preserve
			keep if outcome=="`v'"
			outlab `v'
			local vlab "`r(lab)'"
			qui sum mean_ref
			local mref = strtrim(string(r(mean), "%15.0fc"))
			qui sum n_pairs
			local np = strtrim(string(r(mean), "%12.0fc"))
			qui sum n_obs
			local no = strtrim(string(r(mean), "%12.0fc"))
			es_plot, time(k) ref(-2) xlabel(-4(2)8) ///
				title("`vlab', ${dlab_`d'} and `slab'") ///
				xtitle("Semesters since layoff") ytitle("`vlab'") ///
				text(0 8 "Treated mean at k=-2: `mref'", place(nw) size(small) color(gs6)) ///
				note("Pairs: `np'. Observations: `no'.`tnote'", size(small)) ///
				file("$es_graphs/`v'_`d'_`sname'_movil.pdf")
			restore
		}
	}
}

*------------------------------------------------------------------------------
* 4. Trimming diagnostic
*------------------------------------------------------------------------------
* (a) Tail of pre-shock debt (one row per unit): p95, p99, p99.5, p99.9 and
*     maximum, with the % jump from each percentile to the previous one.
* (b) Coefficients at k = 0, 2, 4, 8 (with controls) under each cutoff.
foreach d of global defs {
	use "$mov/es_panel_`d'.dta", clear
	egen byte tagu = tag(unit)
	es_dummies, time(rel_sem) from(-4) to(8) ref(-2) prefix(D)
	local dlist `r(list)'

	capture postutil clear
	tempname pdiag pcmp
	postfile `pdiag' str20 outcome double(p95 p99 p995 p999 pmax) ///
		using "$mov/results/trimdiag_`d'.dta", replace
	postfile `pcmp' str20 outcome str6 corte int k double(coef se) long n_trim ///
		using "$mov/results/trimcmp_`d'.dta", replace

	foreach v of local debt_vars {
		tempvar pre
		bysort unit: egen double `pre' = max(cond(inrange(rel_sem, -4, -2), `v', .))
		qui _pctile `pre' if tagu, p(95 99 99.5 99.9)
		local q95  = r(r1)
		local q99  = r(r2)
		local q995 = r(r3)
		local q999 = r(r4)
		qui sum `pre' if tagu
		post `pdiag' ("`v'") (`q95') (`q99') (`q995') (`q999') (r(max))
		drop `pre'

		foreach tc of global trims {
			capture drop tr_`v'
			trim_flags `v', pct(`tc')
			qui count if tr_`v' & tagu & treated==1
			local ntrim = r(N)
			capture reghdfe `v' `dlist' `xctrl_k' if tr_`v'==0, absorb(unit pairk) vce(cluster j_cluster)
			if _rc continue
			foreach k in 0 2 4 8 {
				post `pcmp' ("`v'") ("p`tc'") (`k') (_b[D_p`k']) (_se[D_p`k']) (`ntrim')
			}
		}
		capture drop tr_`v'
	}
	postclose `pdiag'
	postclose `pcmp'

	use "$mov/results/trimdiag_`d'.dta", clear
	gen salto_99  = 100 * (p99  / p95  - 1)
	gen salto_995 = 100 * (p995 / p99  - 1)
	gen salto_999 = 100 * (p999 / p995 - 1)
	gen salto_max = 100 * (pmax / p999 - 1)
	format p95-pmax %15.0fc
	format salto_* %8.1f
	save "$mov/results/trimdiag_`d'.dta", replace
	di as text "=== `d': tail of pre-shock debt (% jump over the previous percentile) ==="
	list outcome p95 p99 p995 p999 pmax, noobs clean
	list outcome salto_99 salto_995 salto_999 salto_max, noobs clean

	use "$mov/results/trimcmp_`d'.dta", clear
	sort outcome k corte
	di as text "=== `d': coefficients by trimming cutoff (with controls) ==="
	list, sepby(outcome k) noobs clean
}

*------------------------------------------------------------------------------
* 5. Event study, extensive and intensive margins and ratings
*------------------------------------------------------------------------------
* Linear probability models, outcomes in 0/100 (coefficients in percentage
* points), no trimming.
*   ext, ext_B, ext_E  consumer debt in the window (total, banks, CMFs)
*   entry              ext, pairs where neither member had debt at k=-2
*   incr               total debt above its k=-2 level, pairs where both had
*                      debt at k=-2 (conditions on pre-shock debt only)
*   mal345_*, mal5_*   worst rating 3-5 and 5, by institution type
* Specification 2 adds a cross-section probit at k = 0, 2, 4 (marginal
* effect of treatment, in pp).
local prob_vars ext ext_B ext_E entry incr mal345_B mal345_E mal5_B mal5_E

forvalues spec = 1/2 {
	local sname = cond(`spec'==1, "nocontrols", "controls")
	local slab  = cond(`spec'==1, "no controls", "with controls")
	local xctrl = cond(`spec'==2, "`xctrl_k'", "")

	foreach d of global defs {
		use "$mov/es_panel_`d'.dta", clear
		gen int gy = year(dofm(g))
		gen byte ext   = 100 * pos   if !missing(pos)
		gen byte ext_B = 100 * pos_B if !missing(pos_B)
		gen byte ext_E = 100 * pos_E if !missing(pos_E)

		bysort unit: egen double td_m2 = max(cond(rel_sem==-2, tdeuda, .))
		bysort pair_id: egen byte n_pos_m2 = total(rel_sem==-2 & pos==1)
		bysort pair_id: egen byte n_neg_m2 = total(rel_sem==-2 & pos==0)
		gen byte entry = ext if n_neg_m2==2
		gen byte incr  = 100 * (tdeuda > td_m2) if n_pos_m2==2 & !missing(tdeuda, td_m2)

		es_dummies, time(rel_sem) from(-4) to(8) ref(-2) prefix(D)
		local dlist `r(list)'

		capture postutil clear
		local res_file "$mov/results/res_prob_`d'_`sname'.dta"
		tempname results
		postfile `results' str20 outcome int k double(coef se lb ub) long(n_treat n_ctrl) ///
			double mean_ctrl long(n_pairs n_obs) using "`res_file'", replace

		foreach v of local prob_vars {
			capture noisily reghdfe `v' `dlist' `xctrl', absorb(unit pairk) vce(cluster j_cluster)
			if _rc {
				di as error "`d' / `sname' / `v': reghdfe failed (rc=`=_rc')"
				continue
			}
			* Reference: controls at k>=0 (what happens without the shock)
			qui sum `v' if e(sample) & treated==0 & rel_sem>=0
			local mref = r(mean)
			tempvar tp
			qui egen byte `tp' = tag(pair_id) if e(sample)
			qui count if `tp'==1
			local npairs = r(N)
			local nobs = e(N)
			drop `tp'
			forvalues k = -4/8 {
				if `k'==-2 continue
				local nm = cond(`k' < 0, "m" + string(abs(`k')), "p" + string(`k'))
				local b = _b[D_`nm']
				local se = _se[D_`nm']
				if `se'==0 | missing(`se') {
					local b = .
					local se = .
				}
				qui count if e(sample) & treated==1 & rel_sem==`k'
				local n_t = r(N)
				qui count if e(sample) & treated==0 & rel_sem==`k'
				local n_c = r(N)
				post `results' ("`v'") (`k') (`b') (`se') (`b' - 1.96*`se') (`b' + 1.96*`se') ///
					(`n_t') (`n_c') (`mref') (`npairs') (`nobs')
			}
		}
		postclose `results'

		if `spec'==2 {
			capture postutil clear
			tempname pres
			postfile `pres' str20 outcome int k double(ame se) long N ///
				using "$mov/results/res_probit_`d'.dta", replace
			foreach v of local prob_vars {
				foreach kk in 0 2 4 {
					capture noisily probit `v' i.treated c.edad##c.edad i.sexo i.dec_ing ///
						i.sector_k2 i.fsz_k2 i.gy if rel_sem==`kk', vce(cluster j_cluster)
					if _rc {
						di as error "`d' / probit / `v' / k=`kk': failed (rc=`=_rc')"
						continue
					}
					local nobs = e(N)
					capture noisily margins, dydx(treated) post
					if _rc continue
					post `pres' ("`v'") (`kk') (100*_b[1.treated]) (100*_se[1.treated]) (`nobs')
				}
			}
			postclose `pres'
			preserve
			use "$mov/results/res_probit_`d'.dta", clear
			di as text "=== Probit `d': marginal effect of treatment (pp) ==="
			list, sepby(outcome) noobs
			restore
		}

		use "`res_file'", clear
		sort outcome k
		di as text "=== LPM results `d' / `sname' (pp) ==="
		list, sepby(outcome) noobs

		levelsof outcome, local(outcomes)
		foreach v of local outcomes {
			preserve
			keep if outcome=="`v'"
			outlab `v'
			local vlab "`r(lab)'"
			qui sum mean_ctrl
			local mref = strtrim(string(r(mean), "%4.1f"))
			qui sum n_pairs
			local np = strtrim(string(r(mean), "%12.0fc"))
			qui sum n_obs
			local no = strtrim(string(r(mean), "%12.0fc"))
			es_plot, time(k) ref(-2) xlabel(-4(2)8) ///
				title("`vlab', ${dlab_`d'} and `slab'") ///
				xtitle("Semesters since layoff") ytitle("Percentage points") ///
				text(0 8 "Control mean, k>=0: `mref'%", place(nw) size(small) color(gs6)) ///
				note("Pairs: `np'. Observations: `no'.", size(small)) ///
				file("$es_graphs/`v'_`d'_`sname'_movil.pdf")
			restore
		}
	}
}

*------------------------------------------------------------------------------
* 6. Event study, labor income and employment
*------------------------------------------------------------------------------
* First stage of the shock, no trimming.
*   ing_r  average real monthly labor income in the window (0 = no job)
*   emp_f  % of months in the window with a formal job
* Controls are employed at g by construction, so part of the drop at k=0 is
* mechanical. Labor data end in 2022m12: later windows are missing.
local inc_vars ing_r emp_f

forvalues spec = 1/2 {
	local sname = cond(`spec'==1, "nocontrols", "controls")
	local slab  = cond(`spec'==1, "no controls", "with controls")
	local xctrl = cond(`spec'==2, "`xctrl_k'", "")

	foreach d of global defs {
		use "$mov/es_panel_`d'.dta", clear
		es_dummies, time(rel_sem) from(-4) to(8) ref(-2) prefix(D)
		local dlist `r(list)'

		capture postutil clear
		local res_file "$mov/results/res_ing_`d'_`sname'.dta"
		tempname results
		postfile `results' str20 outcome int k double(coef se lb ub) long(n_treat n_ctrl) ///
			double mean_ref long(n_pairs n_obs) using "`res_file'", replace

		foreach v of local inc_vars {
			capture noisily reghdfe `v' `dlist' `xctrl', absorb(unit pairk) vce(cluster j_cluster)
			if _rc {
				di as error "`d' / `sname' / `v': reghdfe failed (rc=`=_rc')"
				continue
			}
			qui sum `v' if e(sample) & treated==1 & rel_sem==-2
			local mref = r(mean)
			tempvar tp
			qui egen byte `tp' = tag(pair_id) if e(sample)
			qui count if `tp'==1
			local npairs = r(N)
			local nobs = e(N)
			drop `tp'
			forvalues k = -4/8 {
				if `k'==-2 continue
				local nm = cond(`k' < 0, "m" + string(abs(`k')), "p" + string(`k'))
				local b = _b[D_`nm']
				local se = _se[D_`nm']
				if `se'==0 | missing(`se') {
					local b = .
					local se = .
				}
				qui count if e(sample) & treated==1 & rel_sem==`k'
				local n_t = r(N)
				qui count if e(sample) & treated==0 & rel_sem==`k'
				local n_c = r(N)
				post `results' ("`v'") (`k') (`b') (`se') (`b' - 1.96*`se') (`b' + 1.96*`se') ///
					(`n_t') (`n_c') (`mref') (`npairs') (`nobs')
			}
		}
		postclose `results'

		use "`res_file'", clear
		sort outcome k
		di as text "=== Income results `d' / `sname' ==="
		list, sepby(outcome) noobs

		levelsof outcome, local(outcomes)
		foreach v of local outcomes {
			preserve
			keep if outcome=="`v'"
			outlab `v'
			local vlab "`r(lab)'"
			local ytit = cond("`v'"=="ing_r", "Constant pesos", "Percentage points")
			local fmt  = cond("`v'"=="ing_r", "%15.0fc", "%4.1f")
			qui sum mean_ref
			local mref = strtrim(string(r(mean), "`fmt'"))
			qui sum n_pairs
			local np = strtrim(string(r(mean), "%12.0fc"))
			qui sum n_obs
			local no = strtrim(string(r(mean), "%12.0fc"))
			es_plot, time(k) ref(-2) xlabel(-4(2)8) ///
				title("`vlab', ${dlab_`d'} and `slab'") ///
				xtitle("Semesters since layoff") ytitle("`ytit'") ///
				text(0 8 "Treated mean at k=-2: `mref'", place(nw) size(small) color(gs6)) ///
				note("Pairs: `np'. Observations: `no'.", size(small)) ///
				file("$es_graphs/`v'_`d'_`sname'_movil.pdf")
			restore
		}
	}
}

*------------------------------------------------------------------------------
* 7. Event study, monthly
*------------------------------------------------------------------------------
* m = -12..12 around the shock month (m = 0), reference m = mref_m (g-7,
* last month of k=-2). Debt levels use the same trimmed pairs as section 3;
* probabilities, income and employment are not trimmed. Covariates interact
* with six-month blocks rather than with each month: with 25 months the
* clustered variance matrix becomes singular.
local m_vars `debt_vars' ext ext_B ext_E mal345_B mal345_E mal5_B mal5_E ing_r emp_f
local xctrl_m "i.es6#c.edad i.es6#i.sexo i.es6#i.sector_k2 i.es6#i.fsz_k2 i.es6#i.dec_ing"

forvalues spec = 1/2 {
	local sname = cond(`spec'==1, "nocontrols", "controls")
	local slab  = cond(`spec'==1, "no controls", "with controls")
	local xctrl = cond(`spec'==2, "`xctrl_m'", "")

	foreach d of global defs {
		* Trimmed pairs, from the semi-annual panel
		use "$mov/es_panel_`d'.dta", clear
		egen byte tagu = tag(unit)
		trim_flags `debt_vars', pct($trim)
		keep pair_id tr_*
		bysort pair_id: keep if _n==1
		tempfile trd
		save `trd'

		use "$mov/es_mpanel_`d'.dta", clear
		merge m:1 pair_id using `trd', keep(1 3) nogen
		foreach v of local debt_vars {
			replace tr_`v' = 0 if missing(tr_`v')
		}
		gen byte ext   = 100 * pos   if !missing(pos)
		gen byte ext_B = 100 * pos_B if !missing(pos_B)
		gen byte ext_E = 100 * pos_E if !missing(pos_E)
		gen byte es6 = floor((rel_m + 12)/6)            // 0..4 (m=12 falls in 4)
		es_dummies, time(rel_m) from(-12) to(12) ref($mref_m) prefix(M)
		local dlist `r(list)'

		capture postutil clear
		local res_file "$mov/results/res_mes_`d'_`sname'.dta"
		tempname results
		postfile `results' str20 outcome int m double(coef se lb ub) long(n_treat n_ctrl) ///
			double mean_ref long(n_pairs n_obs) using "`res_file'", replace

		foreach v of local m_vars {
			local ifc ""
			capture confirm variable tr_`v', exact
			if !_rc local ifc "if tr_`v'==0"
			capture noisily reghdfe `v' `dlist' `xctrl' `ifc', absorb(unit pairm) vce(cluster j_cluster)
			if _rc {
				di as error "`d' / `sname' / `v' (monthly): reghdfe failed (rc=`=_rc')"
				continue
			}
			qui sum `v' if e(sample) & treated==1 & rel_m==$mref_m
			local mref = r(mean)
			tempvar tp
			qui egen byte `tp' = tag(pair_id) if e(sample)
			qui count if `tp'==1
			local npairs = r(N)
			local nobs = e(N)
			drop `tp'
			forvalues m = -12/12 {
				if `m'==$mref_m continue
				local nm = cond(`m' < 0, "m" + string(abs(`m')), "p" + string(`m'))
				local b = _b[M_`nm']
				local se = _se[M_`nm']
				if `se'==0 | missing(`se') {
					local b = .
					local se = .
				}
				qui count if e(sample) & treated==1 & rel_m==`m'
				local n_t = r(N)
				qui count if e(sample) & treated==0 & rel_m==`m'
				local n_c = r(N)
				post `results' ("`v'") (`m') (`b') (`se') (`b' - 1.96*`se') (`b' + 1.96*`se') ///
					(`n_t') (`n_c') (`mref') (`npairs') (`nobs')
			}
		}
		postclose `results'

		use "`res_file'", clear
		sort outcome m
		di as text "=== Monthly results `d' / `sname' ==="
		list, sepby(outcome) noobs

		levelsof outcome, local(outcomes)
		foreach v of local outcomes {
			preserve
			keep if outcome=="`v'"
			outlab `v'
			local vlab "`r(lab)'"
			local ytit "`vlab'"
			local fmt  "%15.0fc"
			if inlist("`v'", "ext", "ext_B", "ext_E", "emp_f") | substr("`v'", 1, 3)=="mal" {
				local ytit "Percentage points"
				local fmt  "%4.1f"
			}
			if "`v'"=="ing_r" local ytit "Constant pesos"
			local tnote ""
			if strpos(" `debt_vars' ", " `v' ") & $trim < 100 local tnote " Pairs above p$trim of pre-shock debt dropped."
			qui sum mean_ref
			local mref = strtrim(string(r(mean), "`fmt'"))
			qui sum n_pairs
			local np = strtrim(string(r(mean), "%12.0fc"))
			qui sum n_obs
			local no = strtrim(string(r(mean), "%12.0fc"))
			es_plot, time(m) ref($mref_m) xlabel(-12(2)12) msize(small) ///
				title("`vlab', ${dlab_`d'} and `slab'") ///
				xtitle("Months since layoff") ytitle("`ytit'") ///
				text(0 12 "Treated mean at m=$mref_m: `mref'", place(nw) size(small) color(gs6)) ///
				note("Pairs: `np'. Observations: `no'. Reference month: m=$mref_m.`tnote'", size(small)) ///
				file("$es_graphs/`v'_`d'_`sname'_mensual.pdf")
			restore
		}
	}
}

*------------------------------------------------------------------------------
* 8. Re-employment of the treated
*------------------------------------------------------------------------------
* Kaplan-Meier time to a formal job in a firm other than the layoff firm,
* censored at gmax.
*   reemployment_km.pdf  cumulative share re-employed, by definition
*   reemployment.tex     % re-employed at 1-36 months and median, total and
*                        by sex, age and tenure; % back at the layoff firm
clear
tempfile kmall
save `kmall', emptyok
foreach d of global defs {
	use "$mov/results/reemp_`d'.dta", clear
	drop if dur <= 0 | missing(dur)
	local nkm_`d' = strtrim(string(_N, "%12.0fc"))
	gen byte one = 1
	collapse (sum) dfail=reemp (count) ntot=one, by(dur)
	gsort -dur
	gen double nrisk = sum(ntot)
	sort dur
	gen double S = 1 - dfail / nrisk
	replace S = S * S[_n-1] if _n > 1
	gen double F = 100 * (1 - S)
	set obs `=_N + 1'
	replace dur = 0 in `=_N'
	replace F   = 0 in `=_N'
	sort dur
	gen str10 def = "`d'"
	append using `kmall'
	save `kmall', replace
}
twoway (line F dur if def=="layoff"  & dur <= 48, connect(stairstep) lcolor(navy) lwidth(medthick)) ///
       (line F dur if def=="empdrop" & dur <= 48, connect(stairstep) lcolor(maroon) lpattern(dash) lwidth(medthick)), ///
	xtitle("Months since layoff") ytitle("Re-employed in a new firm (%)") ///
	title("Time to re-employment (Kaplan-Meier)", size(medium)) ///
	xlabel(0(6)48) ylabel(0(20)100) ///
	legend(order(1 "Layoff" 2 "Employment drop") position(6) cols(2)) ///
	note("Matched treated workers. N: layoff `nkm_layoff', employment drop `nkm_empdrop'. Spells censored at `gmaxl'.", size(small)) ///
	graphregion(color(white))
graph export "$es_graphs/reemployment_km.pdf", replace

* Groups: condition and row label
local grps all fem men a1 a2 a3 t1 t2 t3
local gc_all "1"
local gc_fem "sexo==1"
local gc_men "sexo==0"
local gc_a1  "edad < 30"
local gc_a2  "inrange(edad, 30, 44)"
local gc_a3  "edad >= 45 & !missing(edad)"
local gc_t1  "tenure < 12"
local gc_t2  "inrange(tenure, 12, 35)"
local gc_t3  "tenure >= 36 & !missing(tenure)"
local gl_all "All"
local gl_fem "\quad Women"
local gl_men "\quad Men"
local gl_a1  "\quad Age \(<\) 30"
local gl_a2  "\quad Age 30--44"
local gl_a3  "\quad Age 45+"
local gl_t1  "\quad Tenure \(<\) 1 year"
local gl_t2  "\quad Tenure 1--3 years"
local gl_t3  "\quad Tenure 3+ years"

file open tex using "$es_tables/reemployment.tex", write replace
file write tex "\begin{table}[htbp]" _n "\centering" _n "\scriptsize" _n
file write tex "\caption{Time to re-employment of the treated workers}" _n
file write tex "\label{tab:reemployment}" _n
file write tex "\begin{tabular}{lccccccccc}" _n "\hline" _n
file write tex " & & \multicolumn{6}{c}{Re-employed in a new firm within (\%)} & Median & Back to the \\" _n
file write tex " & N & 1 m & 3 m & 6 m & 12 m & 24 m & 36 m & (months) & layoff firm (\%) \\" _n
file write tex "\hline" _n
foreach d of global defs {
	local dl = strupper(substr("${dlab_`d'}", 1, 1)) + substr("${dlab_`d'}", 2, .)
	file write tex "\multicolumn{10}{l}{\textit{`dl'}} \\" _n
	foreach grp of local grps {
		use "$mov/results/reemp_`d'.dta", clear
		keep if `gc_`grp''
		qui count if dur > 0 & !missing(dur)
		local nn = strtrim(string(r(N), "%12.0fc"))
		qui sum recall12 if dur > 0 & !missing(dur)
		local rc = strtrim(string(100 * r(mean), "%5.1f"))
		km_at
		foreach h in 1 3 6 12 24 36 {
			local f`h' = strtrim(string(r(F`h'), "%5.1f"))
		}
		local med = cond(missing(r(med)), "--", string(r(med)))
		file write tex "`gl_`grp''" " & `nn' & `f1' & `f3' & `f6' & `f12' & `f24' & `f36' & `med' & `rc' \\" _n
	}
}
file write tex "\hline" _n "\end{tabular}" _n
file write tex "\begin{minipage}{0.9\textwidth}\vspace{3pt}\tiny" _n
file write tex "Notes: Kaplan-Meier estimates for the matched treated workers. Re-employment: first month after the shock month \(g\) with formal employment in a firm other than the layoff firm. Spells censored at `gmaxl'. Back to the layoff firm: formal employment in the layoff firm between \(g+2\) and \(g+12\). Age and tenure at \(g-1\)." _n
file write tex "\end{minipage}" _n
file write tex "\end{table}" _n
file close tex

*------------------------------------------------------------------------------
* 9. Shocks, treated workers and matched pairs by year
*------------------------------------------------------------------------------
* One panel per definition:
*   (1) firm-month shocks (firms with 5+ employees)
*   (2) firms with at least one shock in the year
*   (3) treated workers: first event in the year, single shock and job
*   (4) matched pairs, by year of the shock month
*   (5) firms of the matched treated
* The Total row counts distinct firms over the period, not the sum.
local y0 = year(dofm($gmin))
local y1 = year(dofm($gmax))

file open tex using "$es_tables/layoffs_by_year.tex", write replace
file write tex "\begin{table}[htbp]" _n "\centering" _n "\scriptsize" _n
file write tex "\caption{Mass-layoff shocks, firms and treated workers by year}" _n
file write tex "\label{tab:layoffs_by_year}" _n
file write tex "\begin{tabular}{lccccc}" _n "\hline" _n
file write tex " & Firm-month & Firms with & Treated & Matched & Firms of matched \\" _n
file write tex "Year & shocks & a shock & workers & pairs & treated \\" _n
file write tex " & (1) & (2) & (3) & (4) & (5) \\" _n
file write tex "\hline" _n
foreach d of global defs {
	local fl ${flag_`d'}
	local dl = strupper(substr("${dlab_`d'}", 1, 1)) + substr("${dlab_`d'}", 2, .)

	* (1) and (2)
	use j mfecha `fl' if `fl'==1 using "$layoffs/cotizantes2010_2022_hhll.dta", clear
	gen int year = year(dofm(mfecha))
	keep if inrange(year, `y0', `y1')
	bysort j mfecha: keep if _n==1
	local T1 = _N
	bysort j: gen byte fj = (_n==1)
	qui count if fj
	local T2 = r(N)
	bysort year j: gen byte fyj = (_n==1)
	gen byte one = 1
	collapse (sum) c1=one c2=fyj, by(year)
	tempfile yr
	save `yr'

	* (3)
	use mfecha_event multi_shock multi_job if inrange(mfecha_event, $gmin, $gmax) ///
		& multi_shock==0 & multi_job==0 using "$mov/first_event_m_`d'.dta", clear
	local T3 = _N
	gen int year = year(dofm(mfecha_event))
	gen byte one = 1
	collapse (sum) c3=one, by(year)
	merge 1:1 year using `yr', nogen
	save `yr', replace

	* (4) and (5)
	use g j_cluster treated if treated==1 using "$mov/matched_`d'${sfx_es}.dta", clear
	local T4 = _N
	bysort j_cluster: gen byte fj = (_n==1)
	qui count if fj
	local T5 = r(N)
	gen int year = year(dofm(g))
	bysort year j_cluster: gen byte fyj = (_n==1)
	gen byte one = 1
	collapse (sum) c4=one c5=fyj, by(year)
	merge 1:1 year using `yr', nogen
	sort year
	foreach c in c1 c2 c3 c4 c5 {
		replace `c' = 0 if missing(`c')
	}
	list year c1 c2 c3 c4 c5, noobs clean

	file write tex "\multicolumn{6}{l}{\textit{`dl'}} \\" _n
	forvalues r = 1/`=_N' {
		local line "`=year[`r']'"
		foreach c in c1 c2 c3 c4 c5 {
			local x = strtrim(string(`c'[`r'], "%12.0fc"))
			local line "`line' & `x'"
		}
		file write tex "`line' \\" _n
	}
	local line "Total"
	forvalues c = 1/5 {
		local x = strtrim(string(`T`c'', "%12.0fc"))
		local line "`line' & `x'"
	}
	file write tex "`line' \\" _n "\hline" _n
}
file write tex "\end{tabular}" _n
file write tex "\begin{minipage}{0.9\textwidth}\vspace{3pt}\tiny" _n
file write tex "Notes: (1) firm-months with a mass-layoff shock in the panel of firms with 5+ employees; (2) firms with at least one shock in the year; (3) workers whose first qualifying exit is in the year (no other shock outside the event window, single job); (4) treated workers matched to a control, by year of the shock month; (5) distinct layoff firms of the matched treated. Totals in (2) and (5) count distinct firms over `y0'--`y1'." _n
file write tex "\end{minipage}" _n
file write tex "\end{table}" _n
file close tex

*------------------------------------------------------------------------------
* 10. Heterogeneous effects
*------------------------------------------------------------------------------
* Same semi-annual design (with controls) on subsamples of pairs defined by
* the treated worker:
*   noemp1, noemp6     no formal job in another firm at g+1 / by g+6 (defined
*                      on a post-shock outcome: descriptive, not causal)
*   dec12, dec910      income deciles 1-2 and 9-10 in k=-2
*   ter1, ter2, ter3   income terciles in k=-2
* Deciles and terciles come from the population income percentile (3_2), not
* from the sample; workers without income in k=-2 are in no income group.
* Debt and income are graphed as % of the treated mean at k=-2 of each group,
* probabilities and employment in pp.
local het_vars `debt_vars' ext ext_B ext_E mal345_B mal345_E mal5_B mal5_E ing_r emp_f
local pct_vars `debt_vars' ing_r
local hets "noemp1 noemp6 dec12 dec910 ter1 ter2 ter3"
local gs_noemp1 "Not re-employed at g+1"
local gs_noemp6 "Not re-employed by g+6"
local gs_dec12  "Deciles 1-2"
local gs_dec910 "Deciles 9-10"
local gs_ter1   "Tercile 1 (bottom)"
local gs_ter2   "Tercile 2"
local gs_ter3   "Tercile 3 (top)"
local cols "navy maroon forest_green"
local syms "circle triangle square"
local pats "solid dash shortdash"

foreach d of global defs {
	use pers_identificador reemp dur using "$mov/results/reemp_`d'.dta", clear
	gen byte emp1 = (reemp==1 & dur==1)
	gen byte emp6 = (reemp==1 & dur<=6)
	keep pers_identificador emp1 emp6
	tempfile e1
	save `e1'

	use "$mov/es_panel_`d'.dta", clear
	merge m:1 pers_identificador using `e1', keep(1 3) nogen
	bysort pair_id: egen byte h_noemp1 = max(cond(treated==1, emp1==0, .))
	bysort pair_id: egen byte h_noemp6 = max(cond(treated==1, emp6==0, .))
	bysort pair_id: egen byte dec_t    = max(cond(treated==1, dec_ing, .))
	bysort pair_id: egen double pct_t  = max(cond(treated==1, pct_ing, .))
	gen byte h_dec12  = inrange(dec_t, 1, 2)
	gen byte h_dec910 = inrange(dec_t, 9, 10)
	gen byte h_ter1   = (pct_t > 0 & pct_t <= 100/3)
	gen byte h_ter2   = (pct_t > 100/3 & pct_t <= 200/3)
	gen byte h_ter3   = (pct_t > 200/3 & !missing(pct_t))
	egen byte tagu = tag(unit)
	gen byte ext   = 100 * pos   if !missing(pos)
	gen byte ext_B = 100 * pos_B if !missing(pos_B)
	gen byte ext_E = 100 * pos_E if !missing(pos_E)
	trim_flags `debt_vars', pct($trim)
	es_dummies, time(rel_sem) from(-4) to(8) ref(-2) prefix(D)
	local dlist `r(list)'
	tempfile hp
	save `hp'

	foreach h of local hets {
		use `hp', clear
		capture postutil clear
		local res_file "$mov/results/res_het_`d'_`h'.dta"
		tempname results
		postfile `results' str20 outcome int k double(coef se lb ub mean_ref) ///
			long(n_pairs n_obs) using "`res_file'", replace
		foreach v of local het_vars {
			local ifc "if h_`h'==1"
			capture confirm variable tr_`v', exact
			if !_rc local ifc "`ifc' & tr_`v'==0"
			capture noisily reghdfe `v' `dlist' `xctrl_k' `ifc', absorb(unit pairk) vce(cluster j_cluster)
			if _rc {
				di as error "`d' / het `h' / `v': reghdfe failed (rc=`=_rc')"
				continue
			}
			qui sum `v' if e(sample) & treated==1 & rel_sem==-2
			local mref = r(mean)
			tempvar tp
			qui egen byte `tp' = tag(pair_id) if e(sample)
			qui count if `tp'==1
			local npairs = r(N)
			local nobs = e(N)
			drop `tp'
			forvalues k = -4/8 {
				if `k'==-2 continue
				local nm = cond(`k' < 0, "m" + string(abs(`k')), "p" + string(`k'))
				local b = _b[D_`nm']
				local se = _se[D_`nm']
				if `se'==0 | missing(`se') {
					local b = .
					local se = .
				}
				post `results' ("`v'") (`k') (`b') (`se') (`b' - 1.96*`se') (`b' + 1.96*`se') ///
					(`mref') (`npairs') (`nobs')
			}
		}
		postclose `results'
		preserve
		use "`res_file'", clear
		di as text "=== Heterogeneity `d' / `h' ==="
		list outcome k coef se mean_ref n_pairs if inlist(k, -4, 0, 2, 4, 8), sepby(outcome) noobs clean
		restore
	}

	* Graphs: noemp1 and noemp6 alone; deciles 1-2 vs 9-10; the three terciles
	foreach h in noemp1 noemp6 deciles terciles {
		if "`h'"=="deciles" {
			local grps "dec12 dec910"
			local hlab "income deciles 1-2 vs 9-10"
		}
		else if "`h'"=="terciles" {
			local grps "ter1 ter2 ter3"
			local hlab "income terciles"
		}
		else {
			local grps "`h'"
			local hlab = lower("`gs_`h''")
		}
		clear
		local gg = 0
		foreach x of local grps {
			local ++gg
			append using "$mov/results/res_het_`d'_`x'.dta"
			capture gen byte grupo = .
			replace grupo = `gg' if missing(grupo)
			local gn`gg' "`gs_`x''"
		}
		local ng = `gg'
		tempfile hres
		save `hres'

		levelsof outcome, local(outcomes)
		foreach v of local outcomes {
			use if outcome=="`v'" using `hres', clear
			outlab `v'
			local vlab "`r(lab)'"
			local inpct = strpos(" `pct_vars' ", " `v' ") > 0
			local ytit = cond(`inpct', "% of the treated mean at k=-2", "Percentage points")
			local mfmt = cond(`inpct', "%15.0fc", "%5.1f")

			* Treated mean at k=-2 and pairs by group; debt and income
			* rescaled to % of that mean
			local mnote ""
			forvalues gg = 1/`ng' {
				qui sum mean_ref if grupo==`gg'
				local mr = r(mean)
				local mrs = strtrim(string(`mr', "`mfmt'"))
				qui sum n_pairs if grupo==`gg'
				local np = strtrim(string(r(mean), "%12.0fc"))
				local mnote `"`mnote' "`gn`gg'': treated mean at k=-2 = `mrs'; pairs = `np'.""'
				if `inpct' & !missing(`mr') & `mr' != 0 {
					foreach z in coef lb ub {
						replace `z' = 100 * `z' / `mr' if grupo==`gg'
					}
				}
			}
			if strpos(" `debt_vars' ", " `v' ") & $trim < 100 {
				local mnote `"`mnote' "Pairs above p$trim of pre-shock debt dropped.""'
			}

			local ttl "`vlab', ${dlab_`d'}, `hlab'"
			local gfile "$es_graphs/`v'_`d'_het_`h'_movil.pdf"
			if `ng'==1 {
				es_plot, time(k) ref(-2) xlabel(-4(2)8) title("`ttl'") ///
					xtitle("Semesters since layoff") ytitle("`ytit'") ///
					note(`mnote', size(small)) file("`gfile'")
			}
			else {
				* Reference point k=-2 for each group
				forvalues gg = 1/`ng' {
					set obs `=_N + 1'
					replace outcome = "`v'" in `=_N'
					replace grupo = `gg' in `=_N'
					replace k = -2 in `=_N'
					foreach z in coef se lb ub {
						replace `z' = 0 in `=_N'
					}
				}
				sort grupo k
				local plots ""
				local leg ""
				forvalues gg = 1/`ng' {
					local cl : word `gg' of `cols'
					local plots `"`plots' (rarea lb ub k if grupo==`gg', color(`cl'%12) lwidth(none))"'
				}
				forvalues gg = 1/`ng' {
					local cl : word `gg' of `cols'
					local sy : word `gg' of `syms'
					local pt : word `gg' of `pats'
					local plots `"`plots' (connected coef k if grupo==`gg', lcolor(`cl') mcolor(`cl') msymbol(`sy') lpattern(`pt'))"'
					local leg `"`leg' `=`ng' + `gg'' "`gn`gg''""'
				}
				twoway `plots', ///
					yline(0, lpattern(dash) lcolor(gs10)) xline(-0.5, lpattern(dash) lcolor(gs10)) ///
					xtitle("Semesters since layoff") ytitle("`ytit'") ///
					title("`ttl'", size(medium)) xlabel(-4(2)8) ///
					legend(order(`leg') position(6) cols(`ng')) ///
					note(`mnote', size(small)) graphregion(color(white))
				graph export "`gfile'", replace
			}
		}
	}
}

*------------------------------------------------------------------------------
* 11. Anonymized estimation panel
*------------------------------------------------------------------------------
* $mov/share/es_share_<def>.dta: the semi-annual panel without original
* identifiers (people, firms and pairs renumbered 1..N). Enough to replicate
* sections 3, 5, 6 and 10 with reghdfe. Check the data-use agreement before
* sharing it.
cap mkdir "$mov/share"
foreach d of global defs {
	use "$mov/es_panel_`d'.dta", clear
	egen long pid = group(pers_identificador)
	egen long fid = group(j_cluster)
	egen long par = group(pair_id)
	keep par pid fid treated g rel_sem ek unit pairk ///
		edad sexo tenure pct_ing dec_ing sector_k2 fsz_k2 ///
		totdeuda_B totdeuda_E totvencida_B totvencida_E totcast_B totcast_E ///
		pos pos_B pos_E mal345_B mal345_E mal5_B mal5_E ing_r emp_f
	rename (par pid fid) (pair_id person_id j_cluster)
	label var pair_id   "Treated-control pair (renumbered)"
	label var person_id "Person (renumbered)"
	label var j_cluster "Event firm of the pair, cluster (renumbered)"
	order pair_id treated person_id j_cluster g rel_sem ek unit pairk
	sort pair_id treated rel_sem
	compress
	save "$mov/share/es_share_`d'.dta", replace
	di as text "`d': shareable panel saved (`=_N' rows)"
}
