/*==============================================================================
  3_1_Merge.do
  Links the CRC and the MTSS records at the person level and describes match
  quality by year, age and sex. Then builds the consumer-credit panels used
  in the event study: semi-annual debtor panels (matched and CRC-only) and
  monthly files for the matched sample.
  Input : $crc/central_<year>.dta, $mtss/cotizantes<year>_hhll.dta
  Output: $merged/UniversoMerge.dta, merge_summary.dta, merged_<year>.dta,
          mergeuniv_table.tex, merge_table.tex, sem_merge1.dta,
          sem_merge3.dta, diccionario.xlsx; $crcmes/mes_merge3_<YYYYmM>.dta;
          graphs in $graphs
==============================================================================*/

clear
cap mkdir "$merged"
cap mkdir "$crcmes"
cap mkdir "$graphs"

* Offset between the MTSS person id (i) and the CRC key (pers_identificador)
local id_offset 5004138

*------------------------------------------------------------------------------
* 1. Person-level merge, 2011-2023
*------------------------------------------------------------------------------
clear
save "$merged/CRCglobal.dta", emptyok replace
forvalues y = 2011/2023 {
	use pers_identificador using "$crc/central_`y'.dta", clear
	duplicates drop
	append using "$merged/CRCglobal.dta"
	save "$merged/CRCglobal.dta", replace
}
duplicates drop pers_identificador, force
save "$merged/CRCglobal.dta", replace

clear
save "$merged/MTSSglobal.dta", emptyok replace
forvalues y = 2011/2023 {
	use i sexo using "$mtss/cotizantes`y'_hhll.dta", clear
	gen long pers_identificador = i - `id_offset'
	keep pers_identificador sexo
	append using "$merged/MTSSglobal.dta"
	save "$merged/MTSSglobal.dta", replace
}
duplicates drop pers_identificador, force
save "$merged/MTSSglobal.dta", replace

merge 1:1 pers_identificador using "$merged/CRCglobal.dta"

forvalues s = 1/3 {
	qui count if _merge==`s'
	local n`s' : display %15.0fc r(N)
	local n`s' = strtrim("`n`s''")
}

file open tex using "$merged/mergeuniv_table.tex", write replace
file write tex "\begin{table}[htbp]" _n "\centering" _n
file write tex "\caption{Merge results between MTSS and CRC}" _n
file write tex "\label{tab:merge_results}" _n
file write tex "\begin{tabular}{lr}" _n "\hline" _n
file write tex "Status & Observations \\" _n "\hline" _n
file write tex "MTSS only & `n1' \\" _n
file write tex "CRC only & `n2' \\" _n
file write tex "Matched & `n3' \\" _n
file write tex "\hline" _n "\end{tabular}" _n "\end{table}" _n
file close tex

keep if _merge==3
drop _merge
save "$merged/UniversoMerge.dta", replace

*------------------------------------------------------------------------------
* 2. Annual merge and match statistics
*------------------------------------------------------------------------------
* Counts of people by match status, age bracket and sex. Age comes from the
* CRC (age) for matched and CRC-only people and from the MTSS (edad) for
* MTSS-only people. Women: gender==1 in the CRC, sexo==1 in the MTSS.
local ages 1824 2534 3549 5064 o65
local lo1824 18
local hi1824 24
local lo2534 25
local hi2534 34
local lo3549 35
local hi3549 49
local lo5064 50
local hi5064 64
local loo65  65
local hio65  200

clear
tempfile results
save `results', emptyok
forvalues y = 2011/2023 {
	use i anio edad sexo if anio==`y' using "$mtss/cotizantes`y'_hhll.dta", clear
	gen long pers_identificador = i - `id_offset'
	rename anio year
	drop i

	* One row per person, with age and sex harmonized within person
	bysort pers_identificador year (sexo): replace sexo = sexo[1] if !missing(sexo[1])
	bysort pers_identificador year (edad): replace edad = edad[1] if !missing(edad[1])
	duplicates drop pers_identificador year, force

	merge 1:m pers_identificador year using "$crc/central_`y'.dta"
	* central_<y> also holds December of y-1, which cannot match here
	drop if year != `y'
	save "$merged/merged_`y'.dta", replace

	bysort pers_identificador _merge: keep if _n==1

	gen byte n_master_only = (_merge==1)
	gen byte n_using_only  = (_merge==2)
	gen byte n_merged      = (_merge==3)
	foreach a of local ages {
		gen byte n_age_`a'    = _merge==3 & age >=`lo`a'' & age <=`hi`a'' & !missing(age)
		gen byte n_master_`a' = _merge==1 & edad>=`lo`a'' & edad<=`hi`a'' & !missing(edad)
		gen byte n_using_`a'  = _merge==2 & age >=`lo`a'' & age <=`hi`a'' & !missing(age)
	}
	gen byte n_women        = _merge==3 & gender==1
	gen byte n_men          = _merge==3 & gender==0
	gen byte n_master_women = _merge==1 & sexo==1
	gen byte n_master_men   = _merge==1 & sexo==0
	gen byte n_using_women  = _merge==2 & gender==1
	gen byte n_using_men    = _merge==2 & gender==0
	foreach a in 2534 3549 5064 {
		gen byte n_master_`a'_women = n_master_`a' & sexo==1
		gen byte n_master_`a'_men   = n_master_`a' & sexo==0
		gen byte n_using_`a'_women  = n_using_`a'  & gender==1
		gen byte n_using_`a'_men    = n_using_`a'  & gender==0
	}

	keep n_*
	collapse (sum) n_*
	gen int year = `y'
	append using `results'
	save `results', replace
}

use `results', clear
sort year
order year
label variable year          "Year"
label variable n_master_only "Master only (MTSS)"
label variable n_using_only  "Using only (CRC)"
label variable n_merged      "Merged"
label variable n_women       "Merged: women"
label variable n_men         "Merged: men"
foreach s in women men {
	label variable n_master_`s' "MTSS unmatched: `s'"
	label variable n_using_`s'  "CRC unmatched: `s'"
}
foreach a of local ages {
	local al = cond("`a'"=="o65", "65+", substr("`a'", 1, 2) + "-" + substr("`a'", 3, 2))
	label variable n_age_`a'    "Merged: age `al'"
	label variable n_master_`a' "MTSS unmatched: age `al'"
	label variable n_using_`a'  "CRC unmatched: age `al'"
	if inlist("`a'", "2534", "3549", "5064") {
		foreach s in women men {
			label variable n_master_`a'_`s' "MTSS unmatched: age `al', `s'"
			label variable n_using_`a'_`s'  "CRC unmatched: age `al', `s'"
		}
	}
}
list, separator(0) noobs
save "$merged/merge_summary.dta", replace

file open tex using "$merged/merge_table.tex", write replace
file write tex "\begin{table}[htbp]" _n "\centering" _n
file write tex "\caption{Evolution of match status by year}" _n
file write tex "\label{tab:merge_status}" _n
file write tex "\begin{tabular}{lrrr}" _n "\hline" _n
file write tex "Year & MTSS only & CRC only & Matched \\" _n "\hline" _n
forvalues i = 1/`=_N' {
	foreach v in n_master_only n_using_only n_merged {
		local c_`v' : display %15.0fc `v'[`i']
		local c_`v' = strtrim("`c_`v''")
	}
	file write tex "`=year[`i']' & `c_n_master_only' & `c_n_using_only' & `c_n_merged' \\" _n
}
file write tex "\hline" _n "\end{tabular}" _n "\end{table}" _n
file close tex

*------------------------------------------------------------------------------
* 3. Match-quality graphs
*------------------------------------------------------------------------------
local pink4  #c51b7d
local pink3  #de77ae
local pink2  #f1b6da
local green3 #7fbc41
local green4 #4d9221

* MTSS = master in the merge, CRC = using
local pre_mtss master
local pre_crc  using
local lab_mtss MTSS
local lab_crc  CRC

use "$merged/merge_summary.dta", clear

* Matched and unmatched over time
gen pct_master = 100 * n_master_only / (n_master_only + n_merged)
gen pct_using  = 100 * n_using_only  / (n_using_only  + n_merged)

twoway (line n_master_only year, lcolor(`pink3')  lwidth(medium)) ///
       (line n_using_only  year, lcolor(`green3') lwidth(medium)) ///
       (line n_merged      year, lcolor(`pink4')  lwidth(medium)), ///
	title("Number of individuals per matched status per year") xtitle("Year") ///
	xlabel(2011(1)2023, angle(45)) ylabel(100000(250000)1200000, format(%9.0fc)) ///
	legend(order(1 "MTSS not matched" 2 "CRC not matched" 3 "Merged") position(6) cols(3)) ///
	graphregion(color(white)) name(m1, replace)

twoway (line pct_master year, lcolor(`pink3')  lwidth(medium)) ///
       (line pct_using  year, lcolor(`green3') lwidth(medium)), ///
	title("Percentage of individuals not matched per year") ///
	ytitle("% not matched") xtitle("") xlabel(2011(1)2023, angle(45)) ///
	legend(off) graphregion(color(white)) name(m2, replace)

graph combine m2 m1, rows(2) xsize(10) ysize(10)
graph export "$graphs/mergedmain.pdf", replace
graph drop m1 m2

* The remaining graphs average over three-year periods, 2012-2023
drop if year==2011
gen grupo = ceil((year - 2011)/3)
label define grupo_lbl 1 "2012-2014" 2 "2015-2017" 3 "2018-2020" 4 "2021-2023"
label values grupo grupo_lbl

* Age distribution: all individuals (background) vs matched (front)
preserve
foreach a of local ages {
	gen total_`a' = n_age_`a' + n_master_`a' + n_using_`a'
}
collapse (mean) n_age_* total_*, by(grupo)
reshape long n_age_ total_, i(grupo) j(agegroup) string
rename (n_age_ total_) (n_merged n_total)
gen age_order = 1 + (agegroup=="2534") + 2*(agegroup=="3549") + 3*(agegroup=="5064") + 4*(agegroup=="o65")
sort grupo age_order
* Five bars per period with a gap of two between periods (centers 3, 10, 17, 24)
gen x = (grupo - 1)*7 + age_order

twoway (bar n_total  x, fcolor(`pink2'%50) lcolor(none) barwidth(0.85)) ///
       (bar n_merged x, fcolor(`pink4')    lcolor(none) barwidth(0.85)), ///
	title("Number of individuals by age group per period") ///
	ytitle("Avg. number of individuals") xtitle("") ///
	xlabel(3 "2012-2014" 10 "2015-2017" 17 "2018-2020" 24 "2021-2023", noticks nogrid) ///
	ylabel(, format(%9.0fc)) ///
	legend(order(1 "Total" 2 "Merged") position(6) cols(2)) ///
	note("Age groups within each period (left to right):" "18-24  25-34  35-49  50-64  65+") ///
	graphregion(color(white))
graph export "$graphs/merged_edad.pdf", replace
restore

* Sex composition of the matched
gen pct_women = 100 * n_women / n_merged
gen pct_men   = 100 * n_men   / n_merged
graph bar pct_women pct_men, over(grupo) ///
	title("Percentage of matched in merge by gender") ytitle("% matched") ///
	legend(order(1 "Women" 2 "Men") position(6) cols(2)) ///
	bar(1, color(`pink4')) bar(2, color(`green4'))
graph export "$graphs/merged_mujeres.pdf", replace

* Age and sex composition of the unmatched, by source
foreach src in mtss crc {
	local p `pre_`src''
	local L `lab_`src''

	foreach a of local ages {
		gen pct_`src'_nm_`a' = 100 * n_`p'_`a' / n_`p'_only
	}
	graph bar pct_`src'_nm_*, over(grupo) ///
		title("Age composition of `L' unmatched per year") ///
		ytitle("% of `L' not matched") ///
		legend(order(1 "Age 18-24" 2 "Age 25-34" 3 "Age 35-49" 4 "Age 50-64" 5 "Age 65+") ///
		position(6) cols(5)) ///
		bar(1, color(`pink4')) bar(2, color(`pink3')) bar(3, color(`pink2')) ///
		bar(4, color(`green3')) bar(5, color(`green4'))
	graph export "$graphs/merged_`src'_nm_edad.pdf", replace

	gen pct_`src'_nm_women = 100 * n_`p'_women / n_`p'_only
	gen pct_`src'_nm_men   = 100 * n_`p'_men   / n_`p'_only
	graph bar pct_`src'_nm_women pct_`src'_nm_men, over(grupo) ///
		title("`L' not matched by gender per year") ///
		ytitle("% not matched (`L')") ///
		legend(order(1 "Women" 2 "Men") position(6) cols(2)) ///
		bar(1, color(`pink4')) bar(2, color(`green4'))
	graph export "$graphs/merged_`src'_nm_gender.pdf", replace
}

* Match rate by age group, from each source's perspective (stacked bars)
foreach src in mtss crc {
	local p `pre_`src''
	local L `lab_`src''
	preserve
	foreach a of local ages {
		gen m_`a' = 100 * n_age_`a' / (n_age_`a' + n_`p'_`a')
		gen u_`a' = 100 - m_`a'
	}
	collapse (mean) m_* u_*, by(grupo)
	reshape long m_ u_, i(grupo) j(agegroup) string
	gen age_order = 1 + (agegroup=="2534") + 2*(agegroup=="3549") + 3*(agegroup=="5064") + 4*(agegroup=="o65")
	label define age_lbl 1 "18-24" 2 "25-34" 3 "35-49" 4 "50-64" 5 "65+", replace
	label values age_order age_lbl
	sort grupo age_order

	graph bar m_ u_, over(age_order, label(angle(45))) over(grupo) stack ///
		title("Match rate by age group for `L'") ///
		ytitle("% of `L' individuals") ///
		legend(order(1 "Matched" 2 "`L' unmatched") position(6) cols(2)) ///
		bar(1, color(`pink4')) bar(2, color(`green4')) graphregion(color(white))
	graph export "$graphs/stacked_`src'_age.pdf", replace
	restore
}

* Sex composition by age group among the unmatched (stacked bars)
foreach src in mtss crc {
	local p `pre_`src''
	local L `lab_`src''
	preserve
	foreach a in 2534 3549 5064 {
		gen w_`a' = 100 * n_`p'_`a'_women / (n_`p'_`a'_women + n_`p'_`a'_men)
		gen m_`a' = 100 * n_`p'_`a'_men   / (n_`p'_`a'_women + n_`p'_`a'_men)
	}
	collapse (mean) w_* m_*, by(grupo)
	reshape long w_ m_, i(grupo) j(agegroup) string
	gen age_order = 1 + (agegroup=="3549") + 2*(agegroup=="5064")
	label define age_lbl3 1 "25-34" 2 "35-49" 3 "50-64", replace
	label values age_order age_lbl3
	sort grupo age_order

	graph bar w_ m_, over(age_order, label(angle(45))) over(grupo) stack ///
		title("Gender composition by age group, `L' unmatched") ///
		ytitle("% of `L' unmatched") ///
		legend(order(1 "Women" 2 "Men") position(6) cols(2)) ///
		bar(1, color(`pink4')) bar(2, color(`green4')) graphregion(color(white))
	graph export "$graphs/gender_age_`src'_unmatched.pdf", replace
	restore
}

*------------------------------------------------------------------------------
* 4. Consumer-credit panels, 2012-2023
*------------------------------------------------------------------------------
* sem_merge<x>: debtor x semester, amounts by institution type (_B banks,
* _E CMFs). x = 1: debtors not in the MTSS (CRC only); x = 3: matched.
* For the matched sample, a debtor-month file per year feeds section 5.
foreach x in 1 3 {
	clear
	save "$merged/sem_merge`x'.dta", replace emptyok

	forvalues y = 2012/2023 {
		use if year==`y' using "$crc/central_`y'.dta", clear
		merge m:1 pers_identificador using "$merged/UniversoMerge.dta", keep(1 3)
		keep if _merge==`x'
		drop _merge

		keep_consumer                  // excludes housing and vehicle loans
		drop if age > 65

		gen month = periodo - year*100
		gen sem   = ceil(month/6)

		* Banks (1-246) and CMFs (803-860); other institutions dropped
		gen inst = 1 if institucion<=246
		replace inst = 2 if inrange(institucion, 803, 860)
		drop if missing(inst)
		label define inst_lbl 1 "Bank" 2 "CMF", replace
		label values inst inst_lbl

		* Repeated debtor-institution-month rows: exact copies are dropped;
		* rows with different amounts are separate loans and are summed below
		duplicates drop deudor institucion periodo tot*, force
		qui duplicates tag deudor institucion periodo, gen(dupk)
		qui count if dupk > 0
		di as text "`y' (sample `x'): `r(N)' repeated debtor-institution-months with different amounts"
		drop dupk

		gen totpapf = totpa + totpf
		egen double totdeuda2 = rowtotal(totdeuda totcast), missing    // active + written off
		drop totpa totpf *_k *_d deudainst deudaindi totsobregiros totperformingdebt

		* Ratings recoded from best (1) to worst (7); 5, 6 and 7 are grades 3, 4 and 5
		recode ranking (0 2 = 1) (3 = 2) (5 = 3) (6 = 4) (7 = 5) (8 = 6) (9 = 7)

		* Monthly file (matched sample): totals across institutions of each
		* type, worst rating of the month
		if `x'==3 {
			preserve
			keep deudor pers_identificador inst year month ///
				totdeuda totdeuda2 totvencida totcast ranking
			gen int mfecha = ym(year, month)
			collapse (sum) totdeuda totdeuda2 totvencida totcast ///
				(max) ranking_max=ranking (first) pers_identificador, by(deudor inst mfecha)
			gen itype = cond(inst==1, "_B", "_E")
			drop inst
			qui reshape wide totdeuda totdeuda2 totvencida totcast ranking_max, ///
				i(deudor mfecha pers_identificador) j(itype) string
			recast float tot*, force
			format mfecha %tm
			compress
			save "$crcmes/tmpanio_`y'.dta", replace
			restore
		}

		* Semester panel: monthly totals across institutions of each type,
		* then the average over the months of the semester with a record
		collapse (sum) tot* (max) numrela ranking_max=ranking duracion* ///
			(mean) ranking_avg=ranking ///
			(first) sem gender year pers_identificador identificacion, ///
			by(deudor inst periodo)
		collapse (mean) tot* ranking_avg (max) numrela ranking_max duracion* ///
			(first) gender year pers_identificador identificacion, ///
			by(deudor inst sem)

		gen itype = cond(inst==1, "_B", "_E")
		drop inst
		qui reshape wide tot* numrela duracion* ranking_max ranking_avg, ///
			i(deudor sem year gender pers_identificador identificacion) j(itype) string

		append using "$merged/sem_merge`x'.dta"
		save "$merged/sem_merge`x'.dta", replace
	}

	foreach v of varlist _all {
		label var `v' ""
	}
	label var deudor             "Debtor ID"
	label var sem                "Semester"
	label var year               "Year"
	label var gender             "Gender"
	label var pers_identificador "Person identifier (merge key with MTSS)"
	label var identificacion     "Person identification variable (BCU)"

	foreach i in B E {
		label var totrees_venc_`i'     "Expired overdue debt (semester monthly mean)"
		label var totvencida_`i'       "Overdue debt (semester monthly mean)"
		label var totcast_`i'          "Written-off debt (semester monthly mean)"
		label var totcontingencias_`i' "Contingencies (semester monthly mean)"
		label var totdeuda_`i'         "Active debt (semester monthly mean)"
		label var totdeuda2_`i'        "Active and written-off debt (semester monthly mean)"
		label var tottarjetas_`i'      "Credit card debt (semester monthly mean)"
		label var totreestruct_`i'     "Restructured debt (semester monthly mean)"
		label var totpapf_`i'          "Fixed and repayment term debt (semester monthly mean)"
		label var numrela_`i'          "Number of financial relationships"
		label var duracion_consec_`i'  "Uninterrupted duration"
		label var duracion_total_`i'   "Interrupted duration"
		label var ranking_max_`i'      "Maximum debt ranking"
		label var ranking_avg_`i'      "Average debt ranking"
	}
	foreach v of varlist *_B {
		local lbl : variable label `v'
		label variable `v' "`lbl' with banks"
	}
	foreach v of varlist *_E {
		local lbl : variable label `v'
		label variable `v' "`lbl' with CMFs"
	}
	format tot* %15.0fc
	save "$merged/sem_merge`x'.dta", replace

	if `x'==3 {
		preserve
		describe, replace clear
		keep name varlab
		rename (name varlab) (Variable Definition)
		export excel using "$merged/diccionario.xlsx", firstrow(variables) replace
		restore
	}
}

*------------------------------------------------------------------------------
* 5. Monthly files, matched sample
*------------------------------------------------------------------------------
* mes_merge3_<YYYYmM>: one row per debtor with a CRC record in the month;
* totals across institutions by type (_B banks, _E CMFs). Input of 3_2.
forvalues y = 2012/2023 {
	use "$crcmes/tmpanio_`y'.dta", clear
	label var deudor             "Debtor ID"
	label var pers_identificador "Person identifier (merge key with MTSS)"
	label var mfecha             "Year-month"
	foreach i in B E {
		label var totdeuda_`i'    "Active debt (total across institutions)"
		label var totdeuda2_`i'   "Active and written-off debt (total across institutions)"
		label var totvencida_`i'  "Overdue debt (total across institutions)"
		label var totcast_`i'     "Written-off debt (total across institutions)"
		label var ranking_max_`i' "Worst credit rating in the month (recoded 1-7)"
	}
	forvalues mm = 1/12 {
		local t = ym(`y', `mm')
		local tl : display %tm `t'
		preserve
		keep if mfecha==`t'
		save "$crcmes/mes_merge3_`tl'.dta", replace
		restore
	}
	erase "$crcmes/tmpanio_`y'.dta"
}

*------------------------------------------------------------------------------
* 6. Debt graphs, merged sample
*------------------------------------------------------------------------------
local pink4  #c51b7d
local green4 #4d9221

use "$merged/sem_merge3.dta", clear

* Bubble plots of amounts vs worst rating, 2023, by institution type.
* Bubble size: square root of the number of debtors in the amount bin.
preserve
keep if year==2023
gen ldc_B = tottarjetas_B + totcontingencias_B
gen ldc_E = tottarjetas_E + totcontingencias_E
tempfile base
save `base'

* Per amount: variable, cap, bin width, x-axis max (millions), label step, title, file
local v1 totvencida
local c1 10000000
local w1 200000
local x1 4
local s1 1
local t1 "Overdue debt by institution type"
local f1 vencidaxranking

local v2 totcast
local c2 100000000
local w2 2000000
local x2 15
local s2 3
local t2 "Written-off debt by institution type"
local f2 castxranking

local v3 ldc
local c3 50000000
local w3 1000000
local x3 10
local s3 2
local t3 "Line of credit by institution type"
local f3 lineaxranking

forvalues i = 1/3 {
	local v "`v`i''"

	* Three versions: full range, zoom up to 1 million, positive amounts only
	forvalues mode = 1/3 {
		local mcap  `c`i''
		local mbw   `w`i''
		local mxmax `x`i''
		local mstep `s`i''
		local mdiv  1e6
		local munit "millions"
		local pos   0
		local mfile "`f`i''"
		local mtit  "`t`i''"
		if `mode'==2 {
			local mcap  1000000
			local mbw   100000
			local mxmax 1000
			local mstep 200
			local mdiv  1e3
			local munit "thousands"
			local mfile "`f`i''_zoom"
			local mtit  "`t`i'' (zoom <= 1M)"
		}
		if `mode'==3 {
			local pos   1
			local mfile "`f`i''_pos"
			local mtit  "`t`i'' (positive amounts)"
		}

		clear
		tempfile parts
		save `parts', emptyok
		foreach inst in B E {
			use ranking_max_`inst' `v'_`inst' using `base', clear
			keep if `v'_`inst' <= `mcap' & !missing(`v'_`inst')
			if `pos' keep if `v'_`inst' > 0
			rename (ranking_max_`inst' `v'_`inst') (rank amount)
			gen tipo = cond("`inst'"=="B", 1, 2)
			append using `parts'
			save `parts', replace
		}

		gen mbin = floor(amount/`mbw')*`mbw' + `mbw'/2
		gen one  = 1
		collapse (sum) freq=one, by(tipo rank mbin)
		gen xval = mbin/`mdiv'
		keep if xval <= `mxmax'
		gen ry = rank + cond(tipo==1, -0.15, 0.15)
		gen wt = sqrt(freq)
		twoway (scatter ry xval if tipo==1 [aweight=wt], msymbol(Oh) mlcolor("`pink4'")) ///
		       (scatter ry xval if tipo==2 [aweight=wt], msymbol(Oh) mlcolor("`green4'")), ///
			title("`mtit'") ///
			legend(order(1 "Banks" 2 "CMFs") position(6) cols(2)) ///
			ytitle("Max ranking by institution type") ///
			xtitle("`t`i'' (`munit')") ///
			xscale(range(0 `mxmax')) xlabel(0(`mstep')`mxmax') ///
			yscale(range(1 7)) ylabel(1(1)7)
		graph export "$graphs/`mfile'.pdf", replace
	}
}
restore

* Average debt per semester, banks vs CMFs
preserve
gen date = yh(year, sem)
format date %th
collapse tot*, by(date)
foreach v in deuda deuda2 vencida cast {
	if "`v'"=="deuda"   local yt "Average active debt by institution"
	if "`v'"=="deuda2"  local yt "Average active and written-off debt by institution"
	if "`v'"=="vencida" local yt "Average outdated debt by institution"
	if "`v'"=="cast"    local yt "Average written-off debt by institution"
	twoway (line tot`v'_B date) (line tot`v'_E date), ///
		legend(order(1 "Banks" 2 "CMFs") position(6) cols(2)) ///
		xtitle("Date") ytitle("`yt'")
	graph export "$graphs/line_`v'.pdf", replace
}
restore

* Total debt per year (replicates Figure 1 of the CRC descriptives)
preserve
egen totdeuda_T = rowtotal(totdeuda_B totdeuda_E)
collapse (sum) totdeuda_T totdeuda_B, by(year)
twoway (line totdeuda_T year) (line totdeuda_B year), ///
	xtitle("Year") ytitle("Debt in millions of current pesos") ///
	title("Total debt per year") legend(order(1 "Total" 2 "Banks"))
graph export "$graphs/rfigure1.pdf", replace
restore

* Comparison sample: CRC-only debtors
use "$merged/sem_merge1.dta", clear
gen date = yh(year, sem)
format date %th
collapse tot*, by(date)
twoway (line totdeuda_B date) (line totdeuda_E date), ///
	legend(order(1 "Banks" 2 "CMFs") position(6) cols(2)) ///
	xtitle("Date") ytitle("Average active debt by institution")
graph export "$graphs/line_deuda_par.pdf", replace
