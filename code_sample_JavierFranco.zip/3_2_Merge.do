/*==============================================================================
  3_2_Merge.do
  Builds the inputs of the event study from the MTSS records and links them
  to the monthly CRC panel:
    1. Firm-month variables, year by year (stable jobs, exits, headcount)
    2. Firm-month panel with the mass-layoff shock definitions
    3. Worker exits and multiple-job flag
    4. Worker-month characteristics (tenure, income percentile, sector, size)
    5. First monthly shock of each worker, by definition
    6. Six-month windows of consumer credit from the CRC
  Input : $mtss/cotizantes<year>_hhll.dta, $crcmes/mes_merge3_<YYYYmM>.dta,
          $layoffs/correspondencia_fenix_reaperturas.dta
  Output: $layoffs/cotizantes2010_2022_hhll.dta, $es/tmp/all_exits.dta,
          $es/multijob_allyears.dta, $mov/chars_m/chars_<YYYYmM>.dta,
          $mov/first_event_m_<def>.dta, $mov/y6/y6_<YYYYmM>.dta
==============================================================================*/

clear
foreach d in "$layoffs" "$layoffs/carryforward" "$es" "$es/chars" "$es/tmp" ///
	"$mov" "$mov/chars_m" "$mov/y6" {
	cap mkdir "`d'"
}

*------------------------------------------------------------------------------
* 1. Firm-month variables, 2010-2022
*------------------------------------------------------------------------------
* Sample: private-sector jobs (vinculos 12 and 15) with positive pay.
* A stable job is at least 3 consecutive months in the same firm; for day
* laborers (tipo_remuneracion 2), every month of the spell must also have
* 13+ days, 104+ monthly hours or 25+ weekly hours.
forvalues anio = 2010/2022 {
	use i j mescargo fecha_ing cod_aportacion CIIU4 anio remtotal ///
		cod_vinculo_funcional tipo_remuneracion dias_trabajados horas_mensuales ///
		horas_semanales cod_causal_egreso1 cod_causal_egreso2 id_pers_mtss sexo edad ///
		using "$mtss/cotizantes`anio'_hhll.dta", clear
	rename (cod_causal_egreso1 cod_causal_egreso2) (causal_egreso_1 causal_egreso_2)
	sort i j mescargo

	* Spell state in December of the previous year, so that a spell running
	* across the Dec/Jan boundary is not restarted
	local prev = `anio' - 1
	capture confirm file "$layoffs/carryforward/carry_`prev'.dta"
	if !_rc & `anio' > 2010 {
		merge m:1 i j using "$layoffs/carryforward/carry_`prev'.dta", keep(1 3) gen(carry_active)
		replace carry_active = (carry_active==3)
	}
	else {
		gen byte   carry_active = 0
		gen long   carry_length = .
		gen double carry_min_dias = .
		gen double carry_min_horas_mens = .
		gen double carry_min_horas_sem = .
		gen byte   carry_was_estable = .
	}

	* Positive pay first, so that the public-sector and stable-job flags
	* below only use paid workers
	drop if remtotal==0 | missing(remtotal)
	keep if inlist(cod_vinculo_funcional, 12, 15)

	* Public firms: more than 90% of the firm's workers in the public
	* contribution regime (cod_aportacion 2), averaged over the year
	gen byte publico_aux = (cod_aportacion==2)
	egen publico_mes  = mean(publico_aux), by(j mescargo)
	egen publico_anio = mean(publico_mes), by(j anio)
	drop if publico_anio > 0.9 & !missing(publico_anio)
	drop publico_aux publico_mes publico_anio

	* Stable jobs
	bysort i j (mescargo): gen byte new_spell = (_n==1) | (mescargo != mescargo[_n-1] + 1)
	bysort i j (mescargo): replace new_spell = 0 if _n==1 & carry_active==1
	bysort i j (mescargo): gen long spell_id = sum(new_spell)
	bysort i j spell_id (mescargo): gen long spell_length = _N
	replace spell_length = spell_length + carry_length if carry_active==1 & spell_id==0

	bysort i j spell_id: egen double min_dias_trab_spell  = min(dias_trabajados)
	bysort i j spell_id: egen double min_horas_mens_spell = min(horas_mensuales)
	bysort i j spell_id: egen double min_horas_sem_spell  = min(horas_semanales)
	replace min_dias_trab_spell  = min(min_dias_trab_spell,  carry_min_dias)       if carry_active==1 & spell_id==0
	replace min_horas_mens_spell = min(min_horas_mens_spell, carry_min_horas_mens) if carry_active==1 & spell_id==0
	replace min_horas_sem_spell  = min(min_horas_sem_spell,  carry_min_horas_sem)  if carry_active==1 & spell_id==0

	gen byte cumple_jornalero = (min_dias_trab_spell>=13   & !missing(min_dias_trab_spell))  | ///
	                            (min_horas_mens_spell>=104 & !missing(min_horas_mens_spell)) | ///
	                            (min_horas_sem_spell>=25   & !missing(min_horas_sem_spell))
	gen byte vinculo_estable = (spell_length>=3) & (tipo_remuneracion!=2 | cumple_jornalero==1)

	* First month of the first stable spell of each worker-firm pair, unless
	* the pair was already stable at the end of the previous year
	bysort i j (mescargo): gen byte tag_vinculo_estable = vinculo_estable==1 & ///
		sum(vinculo_estable)==1 & !(carry_active==1 & carry_was_estable==1)

	egen n_vinculos_estables        = sum(vinculo_estable), by(j mescargo)
	egen n_vinculos_estables_nuevos = sum(tag_vinculo_estable), by(j mescargo)

	* Exits. Dismissals have exit cause 2; no exit is coded as missing.
	gen byte layoff   = inlist(2, causal_egreso_1, causal_egreso_2)
	gen byte any_exit = !missing(causal_egreso_1) | !missing(causal_egreso_2)
	egen n_layoffs = sum(layoff), by(j mescargo)

	* Paid workers in the firm-month
	egen n_month = count(remtotal), by(j mescargo)

	* December spell state for the next year
	preserve
	keep if mescargo==12
	keep i j spell_length min_dias_trab_spell min_horas_mens_spell min_horas_sem_spell vinculo_estable
	rename (spell_length min_dias_trab_spell min_horas_mens_spell min_horas_sem_spell vinculo_estable) ///
		(carry_length carry_min_dias carry_min_horas_mens carry_min_horas_sem carry_was_estable)
	save "$layoffs/carryforward/carry_`anio'.dta", replace
	restore

	* Worker files: all exits, and characteristics of every worker-month
	* (controls need characteristics too)
	preserve
	keep if any_exit==1
	keep i j anio mescargo id_pers_mtss layoff any_exit
	save "$es/exits_`anio'.dta", replace
	restore

	preserve
	gen int CIIU2 = floor(CIIU4/100)
	keep i id_pers_mtss j anio mescargo CIIU2 sexo edad
	save "$es/chars/chars_`anio'.dta", replace
	restore

	* Workers with more than one job in some month of the year
	bysort i mescargo: gen int n_jobs = _N
	bysort i: egen byte multi_job = max(n_jobs > 1)
	preserve
	keep i multi_job
	duplicates drop i, force
	save "$es/multijob_`anio'.dta", replace
	restore

	* Firm-month level; CIIU4 is the last one observed in the year
	keep j mescargo anio CIIU4 n_layoffs n_month n_vinculos_estables n_vinculos_estables_nuevos
	duplicates drop
	egen max_mescargo = max(mescargo), by(j anio)
	egen CIIU4_last = max(cond(mescargo==max_mescargo, CIIU4, .)), by(j anio)
	drop CIIU4 max_mescargo
	rename CIIU4_last CIIU4
	duplicates drop j mescargo, force
	sort j mescargo

	label var j                          "Firm ID"
	label var mescargo                   "Month"
	label var anio                       "Year"
	label var CIIU4                      "CIIU4 (last observed in the year)"
	label var n_layoffs                  "Number of layoffs in the firm-month"
	label var n_month                    "Number of paid workers in the firm-month"
	label var n_vinculos_estables        "Number of stable jobs in the firm-month"
	label var n_vinculos_estables_nuevos "Number of new stable jobs in the firm-month"
	compress
	save "$layoffs/firms`anio'_hhll_month_v2.dta", replace
}

*------------------------------------------------------------------------------
* 2. Firm-month panel and shock definitions, 2010-2022
*------------------------------------------------------------------------------
clear
forvalues anio = 2010/2022 {
	append using "$layoffs/firms`anio'_hhll_month_v2.dta"
}
gen mfecha = ym(anio, mescargo)
format mfecha %tm
label var mfecha "Year-month"

* Fill months in which a firm is temporarily absent; months before entry
* and after exit are dropped
egen min_cot = min(mfecha), by(j)
egen max_cot = max(mfecha), by(j)
fillin j mfecha
rename _fillin interrupcion
ereplace min_cot = min(min_cot), by(j)
ereplace max_cot = max(max_cot), by(j)
drop if interrupcion==1 & (mfecha > max_cot | mfecha < min_cot)

* Closure: last month observed, except at the end of the panel (2022m12)
gen byte full_closure = (mfecha==max_cot) & (mfecha != ym(2022, 12))
label var full_closure "Firm closure"

* Phoenix firms close and reopen under a new id with at least 80% of the
* previous workforce; they are not real closures
preserve
use "$layoffs/correspondencia_fenix_reaperturas", clear
rename (id_anterior id_nuevo) (j id_nuevo_fenix)
tempfile fenix
save `fenix'
restore
merge m:1 j using `fenix', keep(1 3) gen(mer_fenix)
gen byte fenix = (mer_fenix==3)
drop mer_fenix
label var fenix          "Firm is the closing side of a phoenix pair"
label var id_nuevo_fenix "New firm id of the phoenix firm"

gen int anio_desaparicion = anio if full_closure==1 & fenix==0
ereplace anio_desaparicion = max(anio_desaparicion), by(j)
label var anio_desaparicion "Year the firm disappears (missing for phoenix firms)"

* Monthly change in headcount
sort j mfecha
by j: gen var_n  = (n_month - n_month[_n-1]) / n_month[_n-1]
by j: gen diff_n =  n_month - n_month[_n-1]

* Monthly shocks: more than 1/3 of the workers dismissed, or headcount down
* by more than 1/3. Shares above 100% (repeated dismissals) are capped.
gen perc_layoffs = min(n_layoffs/n_month, 1) if !missing(n_layoffs/n_month)
gen byte var_n_leq_33   = (var_n < -0.33)
gen byte layoffs_geq_33 = (perc_layoffs > 0.33 & !missing(perc_layoffs))
label var var_n_leq_33   "Headcount change below -33% in the month"
label var layoffs_geq_33 "More than 33% of workers laid off in the month"

* 12-month versions: rolling sums of layoffs and of headcount changes over
* the 12-month average headcount
bys j: asrol n_layoffs, stat(sum)  add(1) window(mfecha 12) gen(sum_n_layoffs)
bys j: asrol diff_n,    stat(sum)  add(1) window(mfecha 12) gen(sum_diff_n12)
bys j: asrol n_month,   stat(mean) add(1) window(mfecha 12) gen(avg_n_month)
gen var_n12 = sum_diff_n12 / avg_n_month
gen perc_layoffs12 = min(sum_n_layoffs/avg_n_month, 1) if !missing(sum_n_layoffs/avg_n_month)
gen byte var_n12_leq_33   = (var_n12 < -1/3)
gen byte layoffs12_geq_33 = (perc_layoffs12 > 0.33 & !missing(perc_layoffs12))
label var var_n12          "12-month headcount change over 12-month average headcount"
label var var_n12_leq_33   "12-month headcount change below -1/3"
label var layoffs12_geq_33 "More than 33% of workers laid off in the last 12 months"

* Firm size (12-month average headcount); firms with 4 or fewer workers dropped
gen byte firm_size = .
replace firm_size = 1 if avg_n_month<=4
replace firm_size = 2 if avg_n_month>4   & avg_n_month<10
replace firm_size = 3 if avg_n_month>=10 & avg_n_month<20
replace firm_size = 4 if avg_n_month>=20 & avg_n_month<99
replace firm_size = 5 if avg_n_month>99  & !missing(avg_n_month)
label define firm_size 1 "<=4" 2 "5-9" 3 "10-19" 4 "20-99" 5 ">=100"
label values firm_size firm_size
label var firm_size "Firm size (number of employees)"
drop if firm_size==1

keep j mescargo mfecha anio CIIU4 avg_n_month firm_size ///
	n_vinculos_estables n_vinculos_estables_nuevos ///
	full_closure fenix anio_desaparicion id_nuevo_fenix ///
	var_n_leq_33 layoffs_geq_33 var_n12 var_n12_leq_33 sum_n_layoffs layoffs12_geq_33
order j mescargo mfecha anio
compress
save "$layoffs/cotizantes2010_2022_hhll.dta", replace

*------------------------------------------------------------------------------
* 3. Worker exits and multiple jobs
*------------------------------------------------------------------------------
* Multiple jobs: ever held more than one concurrent job in 2010-2022
clear
forvalues anio = 2010/2022 {
	append using "$es/multijob_`anio'.dta"
}
collapse (max) multi_job, by(i)
label var multi_job "Ever held more than one concurrent job, 2010-2022"
save "$es/multijob_allyears.dta", replace

* All exits with the shock flags of the firm in the month of exit
clear
forvalues anio = 2010/2022 {
	append using "$es/exits_`anio'.dta"
}
gen long mfecha = ym(anio, mescargo)
merge m:1 j mfecha using "$layoffs/cotizantes2010_2022_hhll.dta", ///
	keepusing(var_n_leq_33 layoffs_geq_33) keep(1 3) nogen
recode var_n_leq_33 layoffs_geq_33 (.=0)
keep i id_pers_mtss j mescargo mfecha layoff any_exit var_n_leq_33 layoffs_geq_33
compress
save "$es/tmp/all_exits.dta", replace

*------------------------------------------------------------------------------
* 4. Worker-month characteristics
*------------------------------------------------------------------------------
* One file per month, one row per worker: firm, sector, size, sex, age,
* tenure and income percentile. Only the months the matching uses (g-kref-5
* to g, g in [gmin, gmax]). Firms with 4 or fewer workers have no firm_size
* and do not enter the matching.

* People with any record in the monthly CRC (used if solo_crc==1)
forvalues y = 2012/2023 {
	clear
	forvalues mm = 1/12 {
		local tl : display %tm ym(`y', `mm')
		append using "$crcmes/mes_merge3_`tl'.dta", keep(pers_identificador)
	}
	duplicates drop
	if `y' > 2012 append using "$mov/personas_crc.dta"
	duplicates drop
	save "$mov/personas_crc.dta", replace
}

* The loop starts in 2010 to count tenure (censored at 2010m1); years before
* ymin only update the tenure counter.
local ymin = year(dofm($gmin - $kref5))
capture erase "$mov/chars_m/carry_ten.dta"
forvalues anio = 2010/2022 {

	* Tenure: consecutive months of the worker in firm j
	use i id_pers_mtss j anio mescargo CIIU2 sexo edad ///
		using "$es/chars/chars_`anio'.dta", clear
	gen int mfecha = ym(anio, mescargo)
	bysort i j mfecha: keep if _n==1
	capture confirm file "$mov/chars_m/carry_ten.dta"
	if !_rc merge m:1 i j using "$mov/chars_m/carry_ten.dta", keep(1 3) nogen
	else    gen int ten_dec = .
	sort i j mfecha
	by i j: gen byte newsp = (_n==1) | (mfecha != mfecha[_n-1] + 1)
	by i j: replace newsp = 0 if _n==1 & mescargo==1 & !missing(ten_dec)
	by i j: gen int spell = sum(newsp)
	bysort i j spell (mfecha): gen int tenure = _n + cond(spell==0, ten_dec, 0)
	drop newsp spell ten_dec

	* December tenure for the next year
	capture frame drop fcarry
	frame put i j tenure if mescargo==12, into(fcarry)
	frame fcarry {
		rename tenure ten_dec
		save "$mov/chars_m/carry_ten.dta", replace
	}
	frame drop fcarry
	if `anio' < `ymin' continue
	keep if mfecha >= $gmin - $kref5
	compress
	save "$mov/chars_m/tmp_chars.dta", replace

	* Income percentile in the month among all contributors with positive
	* pay (labor income summed over jobs). A within-month rank needs no
	* deflation and is not distorted by the June and December bonus.
	use i id_pers_mtss anio mescargo remC1 using "$mtss/cotizantes`anio'_hhll.dta", clear
	keep if remC1 > 0 & !missing(remC1)
	collapse (sum) ing=remC1 (first) id_pers_mtss, by(i anio mescargo)
	bysort anio mescargo: egen double rk = rank(ing)
	by anio mescargo: gen double nn = _N
	gen byte pct_ing = ceil(100 * rk / nn)
	rename id_pers_mtss pers_identificador
	if $solo_crc merge m:1 pers_identificador using "$mov/personas_crc.dta", keep(3) nogen
	keep i anio mescargo pct_ing
	compress
	save "$mov/chars_m/tmp_ing.dta", replace

	use "$mov/chars_m/tmp_chars.dta", clear
	rename id_pers_mtss pers_identificador
	if $solo_crc merge m:1 pers_identificador using "$mov/personas_crc.dta", keep(3) nogen
	bysort i mfecha (j): keep if _n==1      // multiple-job workers are excluded in 4_1
	merge 1:1 i anio mescargo using "$mov/chars_m/tmp_ing.dta", keep(1 3) nogen
	merge m:1 j mfecha using "$layoffs/cotizantes2010_2022_hhll.dta", ///
		keepusing(firm_size) keep(1 3) nogen
	ciiu_section CIIU2 sector
	label var pct_ing "Labor income percentile in the month (1-100)"
	label var tenure  "Tenure: consecutive months in the firm (censored at 2010m1)"
	label var sector  "ISIC rev. 4 section (0 = missing)"
	drop CIIU2 anio mescargo

	* Split by month reading from disk; preserve/restore would copy the
	* whole year to the temporary directory every month
	compress
	save "$mov/chars_m/tmp_anio.dta", replace
	levelsof mfecha, local(meses)
	foreach t of local meses {
		local tl : display %tm `t'
		use if mfecha==`t' using "$mov/chars_m/tmp_anio.dta", clear
		drop mfecha
		save "$mov/chars_m/chars_`tl'.dta", replace
	}
}
foreach f in tmp_anio tmp_ing tmp_chars carry_ten {
	capture erase "$mov/chars_m/`f'.dta"
}

*------------------------------------------------------------------------------
* 5. First monthly shock of each worker
*------------------------------------------------------------------------------
* mfecha_event: first month with a qualifying exit (defines g)
* j_event    : firm of the event (lowest id if more than one that month)
* multi_shock: another qualifying exit after g+5, outside window k=0
foreach d of global defs {
	use "$es/tmp/all_exits.dta", clear
	keep if ${exit_`d'}==1 & ${flag_`d'}==1

	bysort i: egen long mfecha_event = min(mfecha)
	bysort i: egen byte multi_shock = max(mfecha > mfecha_event + 5)
	keep if mfecha==mfecha_event
	bysort i (j): keep if _n==1

	keep i id_pers_mtss j mfecha_event multi_shock
	rename (j id_pers_mtss) (j_event pers_identificador)
	format mfecha_event %tm
	gen byte mes_layoff = month(dofm(mfecha_event))

	merge 1:1 i using "$es/multijob_allyears.dta", keep(1 3) nogen
	recode multi_job (.=0)

	* One row per CRC key; if two MTSS ids share it, the earliest event
	bysort pers_identificador (mfecha_event i): keep if _n==1

	label var mfecha_event "Month of the first mass-layoff exit (`d')"
	label var j_event      "Firm of the treatment event"
	label var multi_shock  "Another event after window k=0 (g+5)"
	label var mes_layoff   "Calendar month of the event (1-12)"
	label var multi_job    "Ever held more than one concurrent job, 2010-2022"

	count
	di as text "Definition `d': `r(N)' workers with an event"
	compress
	save "$mov/first_event_m_`d'.dta", replace
}

*------------------------------------------------------------------------------
* 6. Six-month windows of consumer credit
*------------------------------------------------------------------------------
* y6_<t>: one row per person with a CRC record in months t..t+5. Used for
* the pre-shock covariates of the score (t = g-24, g-18) and the outcomes
* (t = g+6k).
*   ceros==1: monthly mean over the 6 months, zero in months without record
*   ceros==0: mean over the months with a record
*   pos, pos_B, pos_E: positive consumer debt in some month (total, banks,
*   CMFs), for the extensive margin
forvalues t = $tmin/$tmax {
	local tl : display %tm `t'
	clear
	forvalues s = 0/5 {
		local ts : display %tm (`t' + `s')
		append using "$crcmes/mes_merge3_`ts'.dta"
	}
	* totdeuda2: active plus written-off debt
	foreach i in B E {
		egen double td2_`i' = rowtotal(totdeuda_`i' totcast_`i'), missing
		replace totdeuda2_`i' = td2_`i'
		drop td2_`i'
	}
	gen byte pos_B = totdeuda_B > 0 & !missing(totdeuda_B)
	gen byte pos_E = totdeuda_E > 0 & !missing(totdeuda_E)
	gen byte pos   = pos_B | pos_E
	if $ceros {
		foreach v of varlist tot* {
			replace `v' = 0 if missing(`v')
		}
		collapse (sum) tot* (max) pos pos_B pos_E ranking_max_B ranking_max_E, by(pers_identificador)
		foreach v of varlist tot* {
			replace `v' = `v' / 6
		}
	}
	else {
		collapse (mean) tot* (max) pos pos_B pos_E ranking_max_B ranking_max_E, by(pers_identificador)
	}
	compress
	save "$mov/y6/y6_`tl'.dta", replace
}
