/*==============================================================================
  1_1_Process.do
  Cleans the annual CRC files: keeps the variables of interest, drops minors
  and non-relevant institutions, adds amounts in constant pesos and in USD,
  and labels. Each file then gets December of the previous year appended.
  Input : $crc_raw/personas_trabajo_<year>.dta, $crc/ipc.dta, $crc/tc.dta
  Output: $crc/central_<year>.dta, 2001-2024
==============================================================================*/

clear

local keepvars age CapInland descripc deudaindi deudainst dur_rela gender id ///
	institucion year nonper_ratio numrela ranking share totcast ///
	totcontingencias totdeuda totpa totpf totreeestruct totsobregiros ///
	tottarjetas totvencida deudor periodo totperformingdebt totrees_venc ///
	pers_identificador identificacion

* Amounts that get a constant-peso (_k) and a USD (_d) version
local amounts totdeuda deudainst deudaindi totrees_venc totvencida totcast ///
	totcontingencias tottarjetas totpf linea totpa totsobregiros ///
	totperformingdebt totreestruct

forvalues y = 2001/2024 {
	use "$crc_raw/personas_trabajo_`y'.dta", clear

	* Guarantee variables exist only up to 2019
	if `y' <= 2019 {
		keep `keepvars' GI GL GML
		label variable GI  "Illiquid guarantee"
		label variable GL  "Liquid guarantee"
		label variable GML "Medium liquid guarantee"
	}
	else keep `keepvars'
	rename totreeestruct totreestruct

	* Non-relevant institutions and minors
	drop if inlist(institucion, 321, 323, 356, 361, 375, 431, 911, 1025, 1026, ///
		1028, 1029, 1030, 1031, 1032, 1033, 1034, 1035, 1101, 1102, 1103) | age < 18

	encode descripc, gen(tipo)
	drop descripc

	gen linea = tottarjetas + totcontingencias
	gen rtarjetalinea = (tottarjetas / linea) * 100

	* CPI (base Oct. 2022) and exchange rate
	merge m:1 periodo using "$crc/ipc.dta", keep(1 3) nogen
	merge m:1 periodo using "$crc/tc.dta",  keep(1 3) nogen

	drop if year < 2001 | year > 2024

	label variable age                "Age"
	label variable CapInland          "Montevideo"
	label variable deudaindi          "Total individual debt"
	label variable deudainst          "Total debt to institution"
	label variable dur_rela           "Relationship duration"
	label variable gender             "Gender"
	label variable id                 "ID of debtor, institution and if from Montevideo"
	label variable institucion        "Institution ID"
	label variable year               "Year"
	label variable nonper_ratio       "% of non-performing debt"
	label variable numrela            "Number of relationships"
	label variable ranking            "Debt qualification"
	label variable share              "% of institutional debt in total debt"
	label variable totcast            "Written off debt"
	label variable totcontingencias   "Total contingencies"
	label variable totdeuda           "Total individual debt"
	label variable totpa              "Total repayment term debt"
	label variable totpf              "Total fixed term debt"
	label variable totreestruct       "Total restructured debt"
	label variable totsobregiros      "Total bank overdrafts"
	label variable tottarjetas        "Total credit card debt"
	label variable totvencida         "Total overdue debt"
	label variable deudor             "Debtor ID"
	label variable periodo            "Date yyyymm"
	label variable totperformingdebt  "Total performing debt"
	label variable totrees_venc       "Total overdue restructured debt"
	label variable tipo               "Type of credit"
	label variable linea              "Line of credit"
	label variable rtarjetalinea      "% of line of credit used"

	foreach var of local amounts {
		local lab : variable label `var'
		gen `var'_k = `var' / ipc
		gen `var'_d = `var' / tc
		label variable `var'_k "`lab' in constant Oct. 2022 pesos"
		label variable `var'_d "`lab' in USD"
	}

	save "$crc/central_`y'.dta", replace
}

*------------------------------------------------------------------------------
* Append December of the previous year to each annual file (2002-2024)
*------------------------------------------------------------------------------
forvalues y = 2001/2023 {
	use "$crc/central_`y'.dta", clear
	keep if mod(periodo, 100)==12 & year==`y'
	tempfile dic
	save `dic'

	local ynext = `y' + 1
	use "$crc/central_`ynext'.dta", clear
	append using `dic'
	save "$crc/central_`ynext'.dta", replace
}
