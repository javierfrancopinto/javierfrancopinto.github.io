# Code sample: job loss and household consumer credit in Uruguay

Javier Franco (javierfrancopinto@gmail.com, javierfrancopinto.github.io)

This is Stata code from "Interest over Interests: Analysis of Uruguayan Household Debt", a CSIC-funded project at the Instituto de Economía (FCEA, Universidad de la República) where I work as a research assistant. The pipeline estimates what happens to a worker's consumer debt, overdue and written-off debt, and credit rating after they lose their job in a mass layoff.

## Data

The code links two confidential administrative sources at the person level:

- CRC (Central de Riesgos Crediticios, Banco Central del Uruguay): monthly debtor-by-institution credit records, 2001-2024.
- MTSS social security contributions: monthly worker-by-firm records, 2010-2023.

The data are not included and can only be used on the institute's server, so the code will not run elsewhere. The paths in `0_Master.do` point to that server.

## Design

A treated worker leaves a firm in a month when the firm has a mass-layoff shock: more than a third of its workforce is dismissed (main definition), or its employment falls by more than a third (robustness). Shock months run from 2014 to 2022.

Each treated worker gets a control with a placebo shock date, matched in two stages. First, firms: exact match on ISIC division and size, with candidate firms ranked by a logit on log employment and firm age. Second, workers: the closest worker in the best-ranked control firm, within a caliper of 0.2 SD of a worker logit, with exact match on sex and tenure.

The event study uses six-month windows from k = -4 to k = 8, with k = -2 as the reference, unit and pair-by-period fixed effects, and standard errors clustered by the event firm. There is also a monthly version.

## How to run

Run `0_Master.do` only. It sets the paths, installs the SSC packages it needs (estout, texsave, gtools, ereplace, asrol, ftools, require, reghdfe), defines the parameters and helper programs the other files use, and runs them in order. The other scripts depend on those globals and programs and will fail if run on their own.

## Files

| File | What it does |
|---|---|
| `0_Master.do` | Paths, packages, parameters, helper programs, and the pipeline |
| `1_1_Process.do` | Cleans the annual CRC files |
| `1_2_Duration.do` | Debtor-institution relationship duration; drops long-standing grade-5 relationships |
| `1_3_Quarters.do` | Quarterly CRC panels |
| `1_4_Semesters.do` | Semi-annual CRC panels |
| `2_1_Descriptives.do` | CRC descriptive graphs |
| `2_2_Institutions.do` | Reporting institutions by year |
| `2_3_Tables.do` | Debtors by credit rating (replicates Arnabal et al., 2023) |
| `3_1_Merge.do` | CRC-MTSS merge, match diagnostics, monthly credit panel |
| `3_2_Merge.do` | Firm shocks, worker exits, characteristics, credit windows |
| `4_1_Matching.do` | Two-stage matching and estimation panels |
| `4_2_Results.do` | Event studies, balance tables, heterogeneity, re-employment |

## If you only have a few minutes

- `0_Master.do`, the helper programs: event-study dummies, trimming on pre-shock debt only, Kaplan-Meier re-employment rates, and the event-study graph.
- `4_1_Matching.do`: the two-stage matching.
- `4_2_Results.do`, sections 3 and 5: the main event studies.
