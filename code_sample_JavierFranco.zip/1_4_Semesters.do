/*==============================================================================
  1_4_Semesters.do
  Collapses the monthly CRC files to debtor-institution-semester panels, in
  three blocks of years.
  Input : $crc/central_<year>.dta
  Output: $crc_s/2010a2015.dta, 2015a2020.dta, 2020a2024.dta
==============================================================================*/

foreach block in "2010 2015" "2015 2020" "2020 2024" {
	local y0 : word 1 of `block'
	local y1 : word 2 of `block'
	local out "$crc_s/`y0'a`y1'.dta"

	clear
	save "`out'", emptyok replace
	forvalues y = `y0'/`y1' {
		use "$crc/central_`y'.dta", clear
		keep if year==`y'                       // drops December of y-1

		gen month = periodo - year*100
		gen sem   = ceil(month/6)

		* Months with a record within the semester
		egen meses = tag(deudor institucion year sem month)

		collapse (sum) tot* deuda* meses (max) ranking duracion_total duracion_consec ///
			(mean) linea* ipc tc, by(deudor institucion sem year)

		append using "`out'"
		save "`out'", replace
	}
}
