/*==============================================================================
  2_1_Descriptives.do
  Descriptive graphs of the CRC, 2001-2024: debtors, consumer debt,
  financial relationships and credit ratings, plus cross-sections for May
  2023. Yearly series use December of each year.
  Input : $crc/central_<year>.dta
  Output: graphs in $graphs, $tables/tabla_relaciones_genero.tex
==============================================================================*/

clear
cap mkdir "$graphs"
cap mkdir "$tables"

* Banks: institutions 1-246. Credit management firms (CMFs): 803-860.

*------------------------------------------------------------------------------
* 1. Cross-section, May 2023
*------------------------------------------------------------------------------
use "$crc/central_2023.dta", clear
keep if periodo==202305 & age>=18 & !inlist(ranking, 0, 2)
duplicates drop

twoway (kdensity age if gender==0) (kdensity age if gender==1), ///
	title("Age distribution of debtors with CRC records") ///
	legend(order(1 "Men" 2 "Women") position(6)) xlabel(18(20)120)
graph export "$graphs/densidad_edad.pdf", replace

keep_consumer
kdensity deudainst if deudainst>0 & deudainst<=1000000, ///
	title("Consumption debt density by institution") ///
	subtitle("Positive and less than or equal to one million pesos") ///
	xtitle("Pesos") ytitle("Density")
graph export "$graphs/densidad_deudainst.pdf", replace

kdensity deudaindi if deudaindi>0 & deudaindi<=1000000, ///
	title("Individual consumption debt density") ///
	subtitle("Positive and less than or equal to one million pesos") ///
	xtitle("Pesos") ytitle("Density")
graph export "$graphs/densidad_deudaindi.pdf", replace

*------------------------------------------------------------------------------
* 2. Financial relationships by year and quartile
*------------------------------------------------------------------------------
* One row per debtor-year with yearly averages, and quartiles within year
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use deudor year numrela deudaindi if year==`y' using "$crc/central_`y'.dta", clear
	if _N==0 continue
	collapse numrela deudaindi, by(deudor year)
	xtile q_numrela   = numrela, nq(4)
	xtile q_deudaindi = deudaindi, nq(4)
	append using `panel'
	save `panel', replace
}

use `panel', clear
preserve
collapse (mean) numrela, by(year)
twoway line numrela year, xtitle("Year") ///
	ytitle("Average financial relationships") ///
	title("Evolution of average financial relationships")
graph export "$graphs/numrelaxaño.pdf", replace
restore

foreach q in numrela deudaindi {
	if "`q'"=="numrela"   local tq "quartiles"
	if "`q'"=="deudaindi" local tq "debt quartiles"
	preserve
	collapse (mean) numrela, by(year q_`q')
	twoway (line numrela year if q_`q'==1, lcolor(blue))   ///
	       (line numrela year if q_`q'==2, lcolor(green))  ///
	       (line numrela year if q_`q'==3, lcolor(orange)) ///
	       (line numrela year if q_`q'==4, lcolor(red)),   ///
	       legend(label(1 "Q1") label(2 "Q2") label(3 "Q3") label(4 "Q4")) ///
	       title("Evolution of financial relationships per `tq'") ///
	       ytitle("Number of relationships") xtitle("Year")
	graph export "$graphs/numrelaxcuartil`q'.pdf", replace
	restore
}

*------------------------------------------------------------------------------
* 3. Total consumer debt by institution type and gender
*------------------------------------------------------------------------------
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 using "$crc/central_`y'.dta", clear
	keep_consumer

	gen deudabancos      = deudainst   if institucion<=246
	gen deudabancos_k    = deudainst_k if institucion<=246
	gen deudah           = deudaindi   if gender==0
	gen deudam           = deudaindi   if gender==1
	gen deudah_k         = deudaindi_k if gender==0
	gen deudam_k         = deudaindi_k if gender==1
	gen deudahbancos_k   = deudah_k    if institucion<=246
	gen deudambancos_k   = deudam_k    if institucion<=246
	gen deudaheacs_k     = deudah_k    if inrange(institucion, 803, 860)
	gen deudameacs_k     = deudam_k    if inrange(institucion, 803, 860)

	local dv deudaindi deudaindi_k deudabancos deudabancos_k deudah deudah_k ///
		deudam deudam_k deudahbancos_k deudambancos_k deudaheacs_k deudameacs_k
	collapse `dv', by(deudor year)
	collapse (sum) `dv', by(year)
	foreach var of local dv {
		replace `var' = `var' / 1000000
	}
	append using `panel'
	save `panel', replace
}

twoway (line deudaindi year) (line deudabancos year), ///
	xtitle("Year") ytitle("Debt in millions of current pesos") ///
	legend(order(1 "Total debt" 2 "Debt to banks")) ///
	title("Total debt per year") xline(2011.5, lpattern(dash))
graph export "$graphs/totdeudaxano.pdf", replace

twoway (line deudaindi_k year) (line deudabancos_k year), ///
	xtitle("Year") ytitle("Debt in millions of constant pesos") ///
	legend(order(1 "Total debt" 2 "Debt to banks")) ///
	title("Total debt per year") xline(2011.5, lpattern(dash))
graph export "$graphs/totdeuda_kxano.pdf", replace

twoway (line deudah year) (line deudam year), xtitle("Year") ///
	ytitle("Debt in millions of current pesos") ///
	title("Total debt per year and gender") ///
	legend(order(1 "Men" 2 "Women")) xline(2011.5, lpattern(dash))
graph export "$graphs/totdeudagenderxano.pdf", replace

twoway (line deudah_k year) (line deudam_k year), xtitle("Year") ///
	ytitle("Debt in millions of constant pesos") ///
	title("Total debt per year and gender") ///
	legend(order(1 "Men" 2 "Women")) xline(2011.5, lpattern(dash))
graph export "$graphs/totdeudagender_kxano.pdf", replace

twoway (line deudahbancos_k year) (line deudambancos_k year) ///
	(line deudaheacs_k year) (line deudameacs_k year), xtitle("Year") ///
	ytitle("Debt in millions of constant pesos") ///
	title("Total debt per year, gender and institution") ///
	legend(order(1 "Men to banks" 2 "Women to banks" 3 "Men to CMFs" 4 "Women to CMFs")) ///
	xline(2011.5, lpattern(dash))
graph export "$graphs/totdeudagenderbancosyeacs_kxano.pdf", replace

*------------------------------------------------------------------------------
* 4. Consumer debt to banks and gender shares
*------------------------------------------------------------------------------
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 & institucion<=246 ///
		using "$crc/central_`y'.dta", clear
	keep_consumer
	collapse deudainst gender, by(deudor year)
	gen deudah = deudainst if gender==0
	gen deudam = deudainst if gender==1
	collapse (sum) deudainst deudah deudam, by(year)
	gen rdeudah = (deudah/deudainst)*100
	gen rdeudam = (deudam/deudainst)*100
	append using `panel'
	save `panel', replace
}

twoway line deudainst year, xtitle("Year") ytitle("Debt") ///
	title("Total debt to banks per year") yscale(range(0 450000000000)) ///
	xline(2011.5, lpattern(dash))
graph export "$graphs/totdeudabancosxano.pdf", replace

twoway (line rdeudah year) (line rdeudam year), xtitle("Year") ///
	ytitle("% of total debt") title("Debt to banks per year") ///
	legend(order(1 "Men" 2 "Women")) xline(2011.5, lpattern(dash))
graph export "$graphs/totdeudabancosgenderxano.pdf", replace

*------------------------------------------------------------------------------
* 5. Reporting institutions per year
*------------------------------------------------------------------------------
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use institucion year if year==`y' using "$crc/central_`y'.dta", clear
	gcollapse (nunique) institucion, by(year)
	append using `panel'
	save `panel', replace
}

twoway line institucion year, ///
	title("Number of institutions reporting to CCR per year") xtitle("Year") ///
	ytitle("Institutions") xline(2011.5, lpattern(dash))
graph export "$graphs/numinstxano.pdf", replace

*------------------------------------------------------------------------------
* 6. Individual consumer debt: mean and quartiles
*------------------------------------------------------------------------------
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 using "$crc/central_`y'.dta", clear
	keep_consumer
	drop if inrange(institucion, 1025, 1035)
	collapse deudaindi, by(deudor year)
	qui summarize deudaindi, detail
	foreach s in mean p25 p50 p75 {
		local `s' = r(`s')
	}
	clear
	set obs 1
	gen year = `y'
	foreach s in mean p25 p50 p75 {
		gen `s' = ``s''
	}
	append using `panel'
	save `panel', replace
}

sort year
twoway (line p25 year) (line p50 year) (line p75 year) (line mean year), ///
	xtitle("Year") ytitle("Total debt") title("Individual debt per quartile") ///
	legend(order(1 "p25" 2 "p50" 3 "p75" 4 "Average"))
graph export "$graphs/q_deudaindixano.pdf", replace

*------------------------------------------------------------------------------
* 7. Consumer debt shares: banks vs CMFs
*------------------------------------------------------------------------------
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 using "$crc/central_`y'.dta", clear
	keep_consumer
	gen byte banco = (institucion<=246)
	gen byte eac   = (institucion>800 & institucion<900)
	drop if banco + eac==0
	gen deudabancos = cond(banco==1, deudainst, 0)
	gen deudaeacs   = cond(eac==1, deudainst, 0)
	gen bancosyeacs = deudabancos + deudaeacs
	gen rdeudabancos = (deudabancos/bancosyeacs)*100
	gen rdeudaeacs   = (deudaeacs/bancosyeacs)*100
	collapse deudabancos deudaeacs bancosyeacs rdeudabancos rdeudaeacs, by(deudor year)
	collapse deudabancos deudaeacs bancosyeacs rdeudabancos rdeudaeacs, by(year)
	append using `panel'
	save `panel', replace
}

twoway (line rdeudabancos year) (line rdeudaeacs year), ///
	xtitle("Year") ytitle("% of total debt") yscale(range(0 100)) ///
	legend(order(1 "Banks" 2 "CMFs")) title("Total debt per institution") ///
	xline(2011.5, lpattern(dash))
graph export "$graphs/deudabancosyeacs.pdf", replace

*------------------------------------------------------------------------------
* 8. Financial relationships by age group
*------------------------------------------------------------------------------
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 using "$crc/central_`y'.dta", clear
	keep_consumer
	drop if inrange(institucion, 1025, 1035)
	collapse numrela age, by(deudor year)
	gen numrela1 = numrela if age>=18 & age<30
	gen numrela2 = numrela if age>=30 & age<50
	gen numrela3 = numrela if age>=50 & age<70
	gen numrela4 = numrela if age>=70
	collapse numrela1 numrela2 numrela3 numrela4, by(year)
	append using `panel'
	save `panel', replace
}

twoway (line numrela1 year) (line numrela2 year) (line numrela3 year) ///
	(line numrela4 year), xtitle("Year") ytitle("Number of relations") ///
	title("Average number of relations per age group") xline(2011.5, lpattern(dash)) ///
	legend(order(1 "Between 18 and 29" 2 "Between 30 and 49" ///
	3 "Between 50 and 69" 4 "Over 70") position(6) cols(2) rows(2))
graph export "$graphs/numrelaxage.pdf", replace

*------------------------------------------------------------------------------
* 9. Debtors, relationships and grade 5 by gender (table and graphs)
*------------------------------------------------------------------------------
* tiene5: at least one relationship in grade 5 (ranking 9). Women: gender==1.
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 using "$crc/central_`y'.dta", clear
	keep_consumer
	drop if inrange(institucion, 1025, 1035)

	gen r5 = 1 if ranking==9
	bysort deudor: egen tiene5 = max(r5)
	collapse deudaindi gender numrela tiene5, by(deudor year)

	gen numrelah  = numrela if gender==0
	gen numrelam  = numrela if gender==1
	gen deudaposh = 1 if deudaindi>0 & gender==0
	gen deudaposm = 1 if deudaindi>0 & gender==1
	gen tiene5h   = 1 if tiene5==1 & gender==0
	gen tiene5m   = 1 if tiene5==1 & gender==1
	gcollapse (nunique) deudor (sum) gender deudaposh deudaposm tiene5 tiene5h tiene5m ///
		(mean) deudaindi numrelah numrelam numrela, by(year)
	append using `panel'
	save `panel', replace
}

gen hombres  = deudor - gender
gen deudapos = deudaposh + deudaposm
gen tiene5p  = (tiene5/deudor)*100
sort year
format deudor hombres gender deudapos deudaposh deudaposm tiene5 tiene5h tiene5m %9.0gc
format numrela numrelah numrelam tiene5p %9.2f

label var year      "Year"
label var deudor    "Debtors"
label var hombres   "Male debtors"
label var gender    "Female debtors"
label var deudapos  "Debtors with positive debt"
label var deudaposh "Male debtors with positive debt"
label var deudaposm "Female debtors with positive debt"
label var numrela   "Average number of relations"
label var numrelah  "Average number of relations for men"
label var numrelam  "Average number of relations for women"
label var tiene5    "Has at least one grade 5 qualification"
label var tiene5p   "% of total debtors with at least one grade 5 qualification"
label var tiene5h   "Has at least one grade 5 qualification and is a man"
label var tiene5m   "Has at least one grade 5 qualification and is a woman"

texsave year deudor hombres gender deudapos deudaposh deudaposm numrela numrelah ///
	numrelam tiene5 tiene5p tiene5h tiene5m ///
	using "$tables/tabla_relaciones_genero.tex", replace frag varlabels

twoway (line numrela year) (line numrelah year) (line numrelam year), ///
	xtitle("Year") ytitle("Average number of relations") ///
	title("Average number of relations per year") ///
	legend(order(1 "Overall" 2 "Men" 3 "Women")) xline(2011.5, lpattern(dash))
graph export "$graphs/numrelaxgender.pdf", replace

twoway line tiene5 year, xtitle("Year") ytitle("Number of debtors") ///
	title("Number of debtors with at least one grade 5 qualification") ///
	xline(2011.5, lpattern(dash))
graph export "$graphs/tiene5xaño.pdf", replace

twoway line tiene5p year, xtitle("Year") ytitle("% of total debtors") ///
	title("% of total debtors with at least one grade 5 qualification") ///
	xline(2011.5, lpattern(dash))
graph export "$graphs/tiene5pxaño.pdf", replace

twoway (line tiene5h year) (line tiene5m year), xtitle("Year") ///
	ytitle("Number of debtors") legend(order(1 "Men" 2 "Women")) ///
	title("Number of debtors with at least one grade 5 qualification per gender") ///
	xline(2011.5, lpattern(dash))
graph export "$graphs/tiene5xañogender.pdf", replace

twoway line deudor year, xtitle("Year") ytitle("Number of total debtors") ///
	title("Number of total debtors") xline(2011.5, lpattern(dash))
graph export "$graphs/deudoresxaño.pdf", replace

twoway (line hombres year) (line gender year), xtitle("Year") ///
	ytitle("Number of debtors") legend(order(1 "Men" 2 "Women")) ///
	title("Number of debtors per gender") xline(2011.5, lpattern(dash))
graph export "$graphs/genderxaño.pdf", replace

twoway line deudapos year, xtitle("Year") ytitle("Number of total debtors") ///
	title("Number of total debtors with positive debt") xline(2011.5, lpattern(dash))
graph export "$graphs/deudaposxaño.pdf", replace

twoway (line deudaposh year) (line deudaposm year), xtitle("Year") ///
	ytitle("Number of debtors") legend(order(1 "Men" 2 "Women")) ///
	title("Number of debtors with positive debt per gender") ///
	xline(2011.5, lpattern(dash))
graph export "$graphs/deudaposgenderxaño.pdf", replace

*------------------------------------------------------------------------------
* 10. Individual consumer debt densities, May 2023
*------------------------------------------------------------------------------
use "$crc/central_2023.dta", clear
keep if periodo==202305
keep_consumer
drop if inrange(institucion, 1025, 1035)
keep if deudaindi>0 & deudaindi<=500000

kdensity deudaindi, xtitle("Individual debt") title("Individual debt density")
graph export "$graphs/densdeuda.pdf", replace

twoway (kdensity deudaindi if gender==0) (kdensity deudaindi if gender==1), ///
	xtitle("Individual debt") title("Individual debt density per gender") ///
	legend(order(1 "Men" 2 "Women"))
graph export "$graphs/densdeudaxgender.pdf", replace

*------------------------------------------------------------------------------
* 11. Debtors by size of consumer debt (constant pesos)
*------------------------------------------------------------------------------
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 using "$crc/central_`y'.dta", clear
	keep_consumer
	drop if inrange(institucion, 1025, 1035)

	gen chico   = 1 if deudaindi_k<5000
	gen mediano = 1 if deudaindi_k>=5000 & deudaindi_k<50000
	gen grande  = 1 if deudaindi_k>=50000

	collapse chico mediano grande, by(deudor year)
	gcollapse (nunique) deudor (sum) chico mediano grande, by(year)
	foreach var of varlist chico mediano grande {
		gen r`var' = (`var'/deudor)*100
	}
	append using `panel'
	save `panel', replace
}

local leg legend(order(1 "Less than 5.000" 2 "Between 5.000 and 50.000" ///
	3 "More than 50.000") cols(3) position(6))

twoway (line chico year) (line mediano year) (line grande year), ///
	xtitle("Year") ytitle("Number of debtors") xline(2011.5, lpattern(dash)) ///
	title("Number of debtors per debt category") `leg'
graph export "$graphs/categorias.pdf", replace

twoway (line rchico year) (line rmediano year) (line rgrande year), ///
	xtitle("Year") ytitle("Percent of total debtors") xline(2011.5, lpattern(dash)) ///
	title("Percent of total debtors per debt category") `leg'
graph export "$graphs/rcategorias.pdf", replace

*------------------------------------------------------------------------------
* 12. Consumer debt by instrument
*------------------------------------------------------------------------------
* Densities, May 2023
use "$crc/central_2023.dta", clear
keep if periodo==202305
keep_consumer

kdensity tottarjetas_k if tottarjetas_k>0 & tottarjetas_k<100000, xtitle("Debt") ///
	title("Credit card debt density")
graph export "$graphs/densidadtarjeta.pdf", replace

kdensity totpa_k if totpa_k>0 & totpa_k<200000, xtitle("Debt") ///
	title("Loan term debt density")
graph export "$graphs/densidadpa.pdf", replace

kdensity totpf_k if totpf_k>0 & totpf_k<200000, xtitle("Debt") ///
	title("Fixed term debt density")
graph export "$graphs/densidadpf.pdf", replace

twoway (kdensity tottarjetas_k if tottarjetas_k>0 & tottarjetas_k<200000) ///
	(kdensity totpa_k if totpa_k>0 & totpa_k<200000) ///
	(kdensity totpf_k if totpf_k>0 & totpf_k<200000), xtitle("Debt") ///
	title("Debt density per instrument") ///
	legend(order(1 "Credit card" 2 "Loan term" 3 "Fixed term") cols(3) position(6))
graph export "$graphs/densidadtres.pdf", replace

* Average debt by instrument per year
clear
tempfile panel
save `panel', emptyok
forvalues y = 2001/2024 {
	use if year==`y' & mod(periodo, 100)==12 using "$crc/central_`y'.dta", clear
	keep_consumer
	collapse tottarjetas_k totpa_k totpf_k, by(deudor year)
	collapse tottarjetas_k totpa_k totpf_k, by(year)
	append using `panel'
	save `panel', replace
}

foreach v in tottarjetas totpa totpf {
	if "`v'"=="tottarjetas" local t "credit card"
	if "`v'"=="tottarjetas" local f "deudatarjeta"
	if "`v'"=="totpa"       local t "loan term"
	if "`v'"=="totpa"       local f "deudapa"
	if "`v'"=="totpf"       local t "fixed term"
	if "`v'"=="totpf"       local f "deudapf"
	twoway line `v'_k year if `v'_k>0, xtitle("Year") ytitle("Debt") ///
		title("Average `t' debt") xline(2011.5, lpattern(dash))
	graph export "$graphs/`f'.pdf", replace
}
