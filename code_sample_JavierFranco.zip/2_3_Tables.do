/*==============================================================================
  2_3_Tables.do
  Optional. Replicates Table 5.3 of Arnabal et al. (2023): debtors by
  combination of credit ratings in the CRC, May 2023. Also tabulates the
  duration of debtor-institution relationships.
  Input : $crc/central_2023.dta, $crc/base_auxiliar_duracion.dta
  Output: $tables/tabla_crc.tex, $tables/descriptivas_duracion.tex
==============================================================================*/

clear
cap mkdir "$tables"

*------------------------------------------------------------------------------
* 1. Debtors by combination of ratings
*------------------------------------------------------------------------------
* ranking codes: 3 = 1C, 5 = 2A, 6 = 2B, 7 = 3, 8 = 4, 9 = 5
use "$crc/central_2023.dta", clear
keep if periodo==202305 & age>=18 & !inlist(ranking, 0, 2)
duplicates drop

gen byte ind_1C  = (ranking==3)
gen byte ind_2AB = inlist(ranking, 5, 6)
gen byte ind_34  = inlist(ranking, 7, 8)
gen byte ind_5   = (ranking==9)

bysort deudor: egen tiene_1C  = max(ind_1C)
bysort deudor: egen tiene_2AB = max(ind_2AB)
bysort deudor: egen tiene_34  = max(ind_34)
bysort deudor: egen tiene_5   = max(ind_5)
bysort deudor: egen nro_5     = total(ind_5)

* Categories with a 5 first, then only 5s, then no 5
gen categoria = .
replace categoria = 5 if (tiene_1C | tiene_2AB) &  tiene_34 & tiene_5
replace categoria = 4 if (tiene_1C | tiene_2AB) & !tiene_34 & tiene_5 & missing(categoria)
replace categoria = 6 if tiene_34 & !tiene_1C & !tiene_2AB & tiene_5 & missing(categoria)
replace categoria = 8 if nro_5 > 1  & missing(categoria)
replace categoria = 7 if nro_5 == 1 & missing(categoria)
replace categoria = 1 if  tiene_1C & !tiene_2AB & !tiene_34 & !tiene_5 & missing(categoria)
replace categoria = 2 if  tiene_2AB & !tiene_1C & !tiene_34 & !tiene_5 & missing(categoria)
replace categoria = 3 if  tiene_34 & !tiene_1C & !tiene_2AB & !tiene_5 & missing(categoria)

label define cat 1 "1C" 2 "2A-2B" 3 "3-4" 4 "1C-2B and at least one 5" ///
	5 "1C-2B, 3-5 and at least one 5" 6 "3-5 and at least one 5" ///
	7 "One 5" 8 "More than one 5"
label values categoria cat
tab categoria

* Statistics by category (debtor level)
collapse (max) deudaindi numrela categoria, by(deudor)
collapse (count) personas=deudor (sum) total_deuda=deudaindi ///
	(median) monto_mediano=deudaindi (mean) relaciones_promedio=numrela, by(categoria)
keep if inrange(categoria, 1, 8)

egen total_personas = total(personas)
egen total_deuda_all = total(total_deuda)
gen part_personas = (personas / total_personas) * 100
gen part_deuda    = (total_deuda / total_deuda_all) * 100

sort categoria
gen part_acum_personas = sum(part_personas)
gen part_acum_deuda    = sum(part_deuda)

* Rows of the table: label, display format and suffix
local rows personas part_personas part_acum_personas part_deuda ///
	part_acum_deuda monto_mediano relaciones_promedio
local lab_personas            "Individuals"
local lab_part_personas       "Share of individuals"
local lab_part_acum_personas  "Cumulative share of individuals"
local lab_part_deuda          "Share of total debt"
local lab_part_acum_deuda     "Cumulative share of total debt"
local lab_monto_mediano       "Median debt (pesos)"
local lab_relaciones_promedio "Average number of relationships"
foreach v of local rows {
	local fmt_`v' "%4.1f"
	local suf_`v' "\%"
}
foreach v in personas monto_mediano {
	local fmt_`v' "%12.0fc"
	local suf_`v' ""
}
local fmt_relaciones_promedio "%4.2f"
local suf_relaciones_promedio ""

file open latex using "$tables/tabla_crc.tex", write replace
file write latex "\begin{table}[htbp]" _n
file write latex "\centering" _n
file write latex "\caption{Debtors by credit ratings in the CRC}" _n
file write latex "\label{tab:crc_deudores}" _n
file write latex "\begin{tabular}{lcccccccc}" _n
file write latex "\hline" _n
file write latex " & \multicolumn{3}{c}{} & \multicolumn{5}{c}{Debtors with at least one grade 5} \\" _n
file write latex " & 1C & 2A-2B & 3-4 & 1C-2B & 1C-2B and 3-5 & 3-5 & One 5 & More than one 5 \\" _n
file write latex "\hline" _n
foreach v of local rows {
	file write latex "`lab_`v''"
	forvalues i = 1/8 {
		qui sum `v' if categoria==`i'
		if r(N) > 0 file write latex " & " `fmt_`v'' (r(mean)) "`suf_`v''"
		else        file write latex " & -"
	}
	file write latex " \\" _n
}
file write latex "\hline" _n
file write latex "\end{tabular}" _n
file write latex "\\" _n
file write latex "\footnotesize{Source: CRC (BCU), May 2023.}" _n
file write latex "\end{table}" _n
file close latex

*------------------------------------------------------------------------------
* 2. Duration of debtor-institution relationships
*------------------------------------------------------------------------------
use "$crc/base_auxiliar_duracion.dta", clear

estpost tabstat duracion_total duracion_consec, ///
	statistics(mean sd min p25 p50 p75 max n) columns(statistics)

esttab using "$tables/descriptivas_duracion.tex", replace ///
	cells("mean(fmt(%9.2f) label(Mean)) sd(fmt(%9.2f) label(Std. Dev.)) min(fmt(%9.2f) label(Min.)) p25(fmt(%9.2f) label(P25)) p50(fmt(%9.2f) label(Median)) p75(fmt(%9.2f) label(P75)) max(fmt(%9.2f) label(Max.)) count(fmt(%9.0f) label(N))") ///
	varlabels(duracion_total "Duration with gaps" duracion_consec "Consecutive duration") ///
	title("Duration descriptives (in years)") ///
	booktabs nomtitle nonumber noobs label
