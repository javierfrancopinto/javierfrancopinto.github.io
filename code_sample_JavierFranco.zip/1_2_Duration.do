/*==============================================================================
  1_2_Duration.do
  Computes the duration of each debtor-institution relationship (years with
  a record, total and consecutive) and drops relationships that stay in
  grade 5 (ranking 9) for 15 or more consecutive years: from the 15th year
  on they are inactive written-off debt, not credit use.
  Input : $crc/central_<year>.dta
  Output: $crc/central_<year>.dta (with duration), $crc/base_auxiliar_duracion.dta
==============================================================================*/

clear

*------------------------------------------------------------------------------
* Debtor-institution-year lists
*------------------------------------------------------------------------------
* aparece: relationship observed in the year
* es9    : every record of the relationship in the year has ranking 9
* Only rows of year y are used from central_<y>: the appended December of
* y-1 is covered by central_<y-1>.
foreach f in listadeudores lista_ranking9 {
	clear
	save "$crc/`f'.dta", emptyok replace
}

forvalues y = 2001/2024 {
	use deudor institucion year if year==`y' using "$crc/central_`y'.dta", clear
	gen byte aparece = 1
	collapse (max) aparece, by(deudor institucion year)
	append using "$crc/listadeudores.dta"
	save "$crc/listadeudores.dta", replace

	use deudor institucion year ranking if year==`y' using "$crc/central_`y'.dta", clear
	gen byte es9 = (ranking==9)
	collapse (min) es9, by(deudor institucion year)
	append using "$crc/lista_ranking9.dta"
	save "$crc/lista_ranking9.dta", replace
}

*------------------------------------------------------------------------------
* Duration: total years and current consecutive streak
*------------------------------------------------------------------------------
use "$crc/listadeudores.dta", clear
sort deudor institucion year
by deudor institucion: gen duracion_total = sum(aparece)

* Fill the gap years so that streaks restart after an absence
egen di = group(deudor institucion)
xtset di year
tsfill
foreach v of varlist deudor institucion {
	bysort di (`v'): replace `v' = `v'[1] if missing(`v')
}
replace aparece = 0 if missing(aparece)

gen rompe = (aparece==0)
bysort di (year): gen grupo_racha = sum(rompe)
bysort di grupo_racha (year): gen duracion_consec = sum(aparece)
bysort di (year): gen duracion_total2 = sum(aparece)
save "$crc/base_auxiliar_duracion.dta", replace

*------------------------------------------------------------------------------
* Years from the 15th consecutive grade-5 year on
*------------------------------------------------------------------------------
use "$crc/lista_ranking9.dta", clear
egen di9 = group(deudor institucion)
xtset di9 year
tsfill
foreach v of varlist deudor institucion {
	bysort di9 (`v'): replace `v' = `v'[1] if missing(`v')
}
replace es9 = 0 if missing(es9)

bysort deudor institucion (year): gen rompe9 = (es9==0)
bysort deudor institucion (year): gen grupo9 = sum(rompe9)
bysort deudor institucion grupo9 (year): gen dur_consec9 = sum(es9)

keep if dur_consec9 >= 15
keep deudor institucion year
duplicates drop
gen byte eliminar = 1
save "$crc/eliminar_ranking9.dta", replace

*------------------------------------------------------------------------------
* Add duration to the monthly files and drop the flagged relationship-years
*------------------------------------------------------------------------------
forvalues y = 2001/2024 {
	use "$crc/central_`y'.dta", clear

	merge m:1 deudor institucion year using "$crc/base_auxiliar_duracion.dta", ///
		keepusing(duracion_total duracion_consec) keep(3) nogen

	merge m:1 deudor institucion year using "$crc/eliminar_ranking9.dta", ///
		keepusing(eliminar) keep(1) nogen
	drop eliminar

	save "$crc/central_`y'.dta", replace
}
